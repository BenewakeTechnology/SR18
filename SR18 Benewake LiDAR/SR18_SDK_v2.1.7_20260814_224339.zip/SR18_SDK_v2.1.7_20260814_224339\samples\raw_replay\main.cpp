// samples/raw_replay — offline replay of a raw RX recording.
//
// Usage:  raw_replay <recording.raw> [frame_index] [--csv out.csv]
//
// Mirrors the reference Benewake SDK's tools/parse_pcap sample flow:
// scan the file for frame offsets, pick one frame, print its stats,
// optionally export the points as CSV.
#include "sr18_parse_raw.h"
#include "sr18_common.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>

int main(int argc, char** argv) {
    if (argc < 2) {
        std::printf("Usage: %s <recording.raw> [frame_index] [--csv out.csv]\n", argv[0]);
        return 1;
    }
    std::string file = argv[1];
    size_t frame_id = 1;                    // reference sample also defaults to 1
    std::string csv_path;
    for (int i = 2; i < argc; ++i) {
        if (std::strcmp(argv[i], "--csv") == 0 && i + 1 < argc) csv_path = argv[++i];
        else if (std::strcmp(argv[i], "--csv") == 0) { std::printf("--csv requires a path\n"); return 1; }
        else frame_id = (size_t)std::strtoull(argv[i], nullptr, 10);
    }

    benewake::ParseRaw parser;
    parser.raw_frame_find(file);
    std::printf("frame size: %zu\n", parser.frame_offset_list_.size());
    if (parser.frame_offset_list_.empty()) return 0;
    if (frame_id >= parser.frame_offset_list_.size()) frame_id = 0;

    benewake::BwPointCloud::Ptr cloud;
    parser.parseFrameByOffset(parser.frame_offset_list_.at(frame_id), cloud);
    if (!cloud) { std::printf("frame %zu: parse failed\n", frame_id); return 1; }

    size_t n = cloud->points.size();
    std::printf("frame %zu:\n  size %zu\n", frame_id, n);
    if (n > 0) {
        const auto& a = cloud->points.front();
        const auto& b = cloud->points.back();
        std::printf("  begin at %llu.%09u s\n",
                    static_cast<unsigned long long>(a.timestamp_s), a.timestamp_ns);
        std::printf("  end   at %llu.%09u s\n",
                    static_cast<unsigned long long>(b.timestamp_s), b.timestamp_ns);
        for (size_t i = 0; i < n && i < 5; ++i) {
            const auto& p = cloud->points[i];
            std::printf("  [%zu] x=%.3f y=%.3f z=%.3f dist_cm=%u ch=%u echo=0x%02X contam=0x%02X\n",
                        i, p.x, p.y, p.z, static_cast<unsigned>(p.distance),
                        static_cast<unsigned>(p.channel), static_cast<unsigned>(p.echo),
                        static_cast<unsigned>(p.contamination));
        }
    }
    std::printf("frame interval: %.6f s\n", parser.getIntervalFromRaw());

    if (!csv_path.empty()) {
        std::ofstream csv(csv_path);
        if (!csv) { std::printf("cannot open %s\n", csv_path.c_str()); return 1; }
        // contamination: 0..2 = 优/中/差, 3 = reserved, 255 = 本模式无该字段（解距）
        csv << "x,y,z,distance_cm,intensity,channel,azimuth,echo,contamination,"
               "timestamp_s,timestamp_ns\n";
        for (const auto& p : cloud->points)
            csv << p.x << ',' << p.y << ',' << p.z << ',' << p.distance << ','
                << static_cast<int>(p.intensity) << ',' << static_cast<int>(p.channel)
                << ',' << p.azimuth << ','
                << static_cast<int>(p.echo) << ',' << static_cast<int>(p.contamination)
                << ',' << p.timestamp_s << ',' << p.timestamp_ns << '\n';
        std::printf("CSV written: %s (%zu points)\n", csv_path.c_str(), n);
    }
    parser.closeFile();
    return 0;
}
