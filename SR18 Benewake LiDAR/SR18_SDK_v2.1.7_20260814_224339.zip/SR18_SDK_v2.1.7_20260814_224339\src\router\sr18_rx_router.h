// src/router/sr18_rx_router.h
#pragma once
#include "../transport/sr18_serial.h"
#include "../codec/sr18_decoder.h"
#include "../../include/sr18_protocol.h"
#include "sr18_device_state.h"
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <vector>
#include <memory>

namespace sr18 {

class AdcMonitor;
class CalibrationCollector;
class AsciiAckMatcher;
class AsciiAngleMatcher;
class PcdInfoMonitor;

// Plain consumer callback: invoked from Rx thread. Must not block.
using FrameConsumer = std::function<void(const DecodedFrame&)>;

class RxRouter {
public:
    explicit RxRouter(ISerial* serial);
    ~RxRouter();

    void start();          // spawn rx thread
    void stop();           // stop and join

    // Subscribe one consumer per D_TYPE family. Pass nullptr to unsubscribe.
    //
    // Threading: consumer is invoked SYNCHRONOUSLY on the rx thread. Consumer
    // must not block. MDOPProtocol implements its consumer as a fast push-only
    // function (memcpy frame bytes into MDOP's internal input_queue, return);
    // actual decoding happens on a separate mdop_decode_thread. IDOP and DSOP
    // currently keep synchronous decode in their consumer (lightweight; their
    // frames are small and infrequent — see CLAUDE.md threading note).
    void setMDOPConsumer(FrameConsumer cb);   // D_TYPE 0x00 + 0x0B (origin_dist)
    void setIDOPConsumer(FrameConsumer cb);   // D_TYPE 0x01
    void setDSOPConsumer(FrameConsumer cb);   // D_TYPE 0x0C

    // Single-slot borrow pointer; pass nullptr to detach. Lifetime is the
    // caller's responsibility (must outlive the router or be cleared first).
    void setAdcMonitor(AdcMonitor* m);

    // Borrowed pointer (nullptr to detach). Fed the tail fields (contamination /
    // lidar state / TDM) of every CRC-valid b1 PCD frame on the rx thread.
    void setPcdInfoMonitor(PcdInfoMonitor* m);

    // Calibration mode switch + collector borrow pointer. When calib_active_
    // is false (normal operation) the calibration decode path in onFrame is
    // skipped entirely (one relaxed atomic load). Lifetime of the collector is
    // the caller's responsibility (must outlive the router or be cleared).
    void setCalibCollector(CalibrationCollector* c);
    void setCalibActive(bool active);

    // Borrowed pointer (nullptr to detach). When set, CRC-valid $LDACK frames
    // decoded on the rx thread are forwarded to the matcher. Lifetime is the
    // caller's responsibility (must outlive the router or be cleared first).
    void setAsciiAckMatcher(AsciiAckMatcher* m);

    // Borrowed pointer (nullptr to detach). When set, CRC-valid read-angle-file
    // ACKs (Len 0x50) decoded on the rx thread are forwarded to this matcher.
    void setAsciiAngleMatcher(AsciiAngleMatcher* m);

    // Consumer for CRC-valid EE DD fault frames, invoked on the rx thread.
    // Available in both two-port and receive-only modes (faults are RX-side
    // telemetry). Set to nullptr to detach.
    using FaultConsumer = std::function<void(const FaultFrame&)>;
    void setFaultConsumer(FaultConsumer cb);

    // Registers a chk_st observer that will be called for every decoded
    // upstream frame EXCEPT b1 PCD (its byte 4 is Reserved — no ACK/CHK_ST is
    // carried, so PCD is excluded at source to keep residue values from faking
    // edges), in registration order, within a single onFrame dispatch under
    // obs_mu_.
    //
    // ⚠ Order-sensitive: when both `ChkStRdRegSampler` and
    // `EdgeDetectingMonitor` are registered, sampler MUST come first.
    // Reason: monitor's onChkSt fires cv.notify_all on DONE, which can
    // wake the main thread in dcsp_read_register's collect() before
    // sampler.onChkSt runs for the same frame, causing collect() to
    // observe a stale last_value_. Registering sampler first ensures
    // last_value_ is updated before the monitor's CV fires.
    // See `src/sr18_lidar_driver.cpp::Impl::setupTransport` for the
    // canonical registration order, and `src/sr18_dcsp.cpp::
    // dcsp_read_register` for the consumer that depends on it.
    void addChkStObserver(IChkStObserver* obs);
    void removeChkStObserver(IChkStObserver* obs);

    // Stats
    size_t framesEmitted() const { return decoder_.framesEmitted(); }
    size_t framesDropped() const { return decoder_.framesDropped(); }

private:
    ISerial*       serial_;
    UpstreamDecoder decoder_;
    std::thread     rx_thread_;
    std::atomic<bool> running_{false};

    std::mutex     consumer_mu_;
    FrameConsumer  mdop_, idop_, dsop_;
    AdcMonitor* adc_monitor_ = nullptr;
    PcdInfoMonitor* pcd_info_monitor_ = nullptr;  // guarded by consumer_mu_
    CalibrationCollector* calib_collector_ = nullptr;  // guarded by consumer_mu_
    std::atomic<bool>     calib_active_{false};
    AsciiAckMatcher* ascii_matcher_ = nullptr;  // guarded by consumer_mu_
    AsciiAngleMatcher* angle_matcher_ = nullptr;  // guarded by consumer_mu_
    FaultConsumer fault_;  // guarded by consumer_mu_

    std::mutex                          obs_mu_;
    std::vector<IChkStObserver*>        chkst_observers_;

    void run();
    void onFrame(const DecodedFrame& df);
    void onAsciiAck(const AsciiAck& ack);
    void onAsciiAngle(const AsciiAngleFile& file);
    void onFault(const FaultFrame& fault);
};

}  // namespace sr18
