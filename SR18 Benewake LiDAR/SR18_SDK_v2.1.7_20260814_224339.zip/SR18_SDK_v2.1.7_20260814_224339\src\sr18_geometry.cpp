// src/sr18_geometry.cpp
// ChannelGeometry 的可配置覆盖存储与公开配置接口的定义。声明见
// include/sr18_geometry.h。本 TU 编进 sr18_sdk（DLL），保证进程内单一实例——
// host 写入与 SDK(assembler) 读取的是同一份（Windows DLL 跨模块也正确）。
//
// 优先级：用户配置(USER) > 设备角度文件(DEVICE) > 内置出厂标定(DEFAULT)。
// 三个来源与世代计数由 g_mu 保护；assembler 读侧走 channelGeometryGeneration()
// 的原子快照，实现运行中实时切换、无需重构 assembler。
#include "../include/sr18_geometry.h"
#include <atomic>
#include <cmath>
#include <cstdint>
#include <mutex>

namespace benewake {
namespace {
    constexpr float kD2R = 0.017453292519943295f;
    constexpr float kR2D = 57.29577951308232f;

    std::mutex      g_mu;
    bool            g_user_set = false;
    ChannelGeometry g_user{};
    bool            g_dev_set  = false;
    ChannelGeometry g_dev{};
    std::atomic<uint64_t> g_gen{0};

    bool allFinite(const float* a, int n) {
        for (int i = 0; i < n; ++i) if (!std::isfinite(a[i])) return false;
        return true;
    }
    ChannelGeometry toGeom(const float* v_deg, const float* h_deg) {
        ChannelGeometry t{};
        for (int i = 0; i < 18; ++i) {
            t.elevation_rad[i]      = v_deg[i] * kD2R;
            t.azimuth_offset_rad[i] = h_deg[i] * kD2R;
        }
        return t;
    }
}  // namespace

SR18_API bool setChannelAnglesDegrees(const float v_deg[18], const float h_deg[18]) {
    if (!v_deg || !h_deg) return false;
    if (!allFinite(v_deg, 18) || !allFinite(h_deg, 18)) return false;
    ChannelGeometry t = toGeom(v_deg, h_deg);
    {
        std::lock_guard<std::mutex> lk(g_mu);
        g_user     = t;
        g_user_set = true;
    }
    g_gen.fetch_add(1, std::memory_order_relaxed);
    return true;
}

SR18_API bool setDeviceChannelAnglesDegrees(const float v_deg[18], const float h_deg[18]) {
    if (!v_deg || !h_deg) return false;
    if (!allFinite(v_deg, 18) || !allFinite(h_deg, 18)) return false;
    ChannelGeometry t = toGeom(v_deg, h_deg);
    {
        std::lock_guard<std::mutex> lk(g_mu);
        g_dev     = t;
        g_dev_set = true;
    }
    g_gen.fetch_add(1, std::memory_order_relaxed);
    return true;
}

// Effective override (USER > DEVICE); returns false only when neither source is
// set, so ChannelGeometry::sr18Calibration() falls through to the factory table.
SR18_API bool getConfiguredChannelGeometry(ChannelGeometry& out) {
    std::lock_guard<std::mutex> lk(g_mu);
    if (g_user_set) { out = g_user; return true; }
    if (g_dev_set)  { out = g_dev;  return true; }
    return false;
}

SR18_API AngleSource getChannelAngleSource() {
    std::lock_guard<std::mutex> lk(g_mu);
    if (g_user_set) return AngleSource::USER;
    if (g_dev_set)  return AngleSource::DEVICE;
    return AngleSource::DEFAULT;
}

SR18_API void getChannelAnglesDegrees(float v_deg[18], float h_deg[18]) {
    if (!v_deg || !h_deg) return;
    ChannelGeometry g = ChannelGeometry::sr18Calibration();   // effective (USER>DEVICE>factory)
    for (int i = 0; i < 18; ++i) {
        v_deg[i] = g.elevation_rad[i]      * kR2D;
        h_deg[i] = g.azimuth_offset_rad[i] * kR2D;
    }
}

SR18_API void clearChannelAngles() {
    {
        std::lock_guard<std::mutex> lk(g_mu);
        g_user_set = false;
    }
    g_gen.fetch_add(1, std::memory_order_relaxed);
}

SR18_API void clearDeviceChannelAngles() {
    {
        std::lock_guard<std::mutex> lk(g_mu);
        g_dev_set = false;
    }
    g_gen.fetch_add(1, std::memory_order_relaxed);
}

SR18_API uint64_t channelGeometryGeneration() {
    return g_gen.load(std::memory_order_relaxed);
}

SR18_API void decodeAngleFileDegrees(const uint8_t raw[72],
                                     float v_deg[18], float h_deg[18]) {
    if (!raw || !v_deg || !h_deg) return;
    // §9.1: SPLIT-BLOCK layout (real-machine structure, 2026-07-22):
    //   [0..35]  = 18 channels' HORIZONTAL angle (18 × int16 LE)
    //   [36..71] = 18 channels' VERTICAL   angle (18 × int16 LE)
    // each a signed int16 little-endian in centidegrees (×0.01°). NOT the
    // earlier per-channel interleaved guess.
    // ⚠ P7: block order (horizontal-first), 18-channel count / 72B length,
    // unit 0.01° and signedness all pending real-machine firmware confirmation.
    for (int i = 0; i < 18; ++i) {
        const uint8_t* ph = raw + i * 2;            // horizontal block
        const uint8_t* pv = raw + 36 + i * 2;       // vertical block
        int16_t azim = (int16_t)((uint16_t)ph[0] | ((uint16_t)ph[1] << 8));
        int16_t elev = (int16_t)((uint16_t)pv[0] | ((uint16_t)pv[1] << 8));
        h_deg[i] = (float)azim * 0.01f;
        v_deg[i] = (float)elev * 0.01f;
    }
}

}  // namespace benewake
