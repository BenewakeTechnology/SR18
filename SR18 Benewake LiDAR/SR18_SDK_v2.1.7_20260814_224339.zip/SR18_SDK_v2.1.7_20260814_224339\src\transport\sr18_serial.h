// src/transport/sr18_serial.h
#pragma once
#include <cstdint>
#include <cstddef>
#include <cerrno>
#include <string>

namespace sr18 {

class ISerial {
public:
    virtual ~ISerial() = default;
    // Returns 0 on success, negative errno on failure.
    virtual int  open(const std::string& port, uint32_t baud) = 0;
    virtual void close() = 0;
    // Returns number of bytes written, or negative on error.
    virtual int  write(const uint8_t* buf, size_t n) = 0;
    // Reads up to n bytes; blocks up to timeout_ms; returns bytes read (0 on timeout, -1 on error).
    virtual int  read(uint8_t* buf, size_t n, int timeout_ms) = 0;
    virtual bool isOpen() const = 0;
    // Re-program the baud on an already-open port, in place (no close). Used by
    // OTA to switch the RS485 line between 3.125 Mbps and 115200. Returns 0 on
    // success, negative on error. Default: not supported.
    virtual int setBaud(uint32_t baud) { (void)baud; return -ENOTSUP; }
};

}  // namespace sr18
