// src/assembler/sr18_frame_assembler.cpp
#include "sr18_frame_assembler.h"
#include "../../include/sr18_protocol.h"
#include "../data/sr18_timestamp.h"

namespace sr18 {

void FrameAssembler::appendPoints(const DecodedFrame& pcd) {
    // Apply any runtime angle change (user config / device fetch) before use.
    benewake::refreshChannelGeometry(geom_, geom_gen_);
    // b1 new-protocol PCD layout (2026-07-20 spec §1): Date&Time@6, us@12,
    // AZIMUTH@16 (0.01 deg/LSB), block@18 (54B = 18ch x 3B), contamination@72,
    // lidar_state@77, TDM@78..80, UDP seq@81. The remaining tail fields are
    // consumed by RxRouter's PcdInfoMonitor, not here — but contamination IS
    // read here: the 18 x 2bit levels correspond 1:1 with this frame's own 18
    // channels, so each point carries the level from ITS OWN frame rather than
    // the monitor's cross-frame cache.
    const uint8_t* f = pcd.full;
    const uint8_t* contam = f + PCD_OFF_CONTAM;
    uint16_t azimuth = (uint16_t)f[16] | ((uint16_t)f[17] << 8);
    const float az_rad = benewake::pcdAzimuthToRadians(azimuth);
    uint32_t ts_us = (uint32_t)f[12] | ((uint32_t)f[13] << 8)
                   | ((uint32_t)f[14] << 16) | ((uint32_t)f[15] << 24);
    const NormalizedTimestamp ts = normalizeWireTimestamp(f + 6, ts_us);
    if (buf_->points.empty()) {
        buf_->time_s = (uint32_t)ts.time_s;
        buf_->time_ns = ts.time_ns;
    }
    for (int ch = 0; ch < 18; ++ch) {
        const uint8_t* p = f + 18 + ch * 3;
        uint16_t wire_raw = (uint16_t)p[0] | ((uint16_t)p[1] << 8);
        float dist_m = (float)wire_raw * 0.004f;       // PCD wire LSB = 4 mm

        benewake::BwPoint pt;
        pt.distance     = (uint16_t)(dist_m * 100.0f); // store in cm (SDK convention)
        pt.intensity    = p[2];
        pt.channel      = (uint8_t)ch;
        pt.azimuth      = azimuth;
        pt.timestamp_s  = ts.time_s;
        pt.timestamp_ns = ts.time_ns;
        pt.echo         = 0x01;             // first-echo semantics for PCD
        pt.contamination = pcdContaminationLevel(contam, ch);
        benewake::pointToCartesianFromMetersRad(pt, geom_, dist_m, az_rad);
        buf_->points.push_back(pt);
    }
}

benewake::BwPointCloud::Ptr FrameAssembler::feed(const DecodedFrame& pcd, int& out_frame_id) {
    uint16_t curr_az = (uint16_t)pcd.full[16] | ((uint16_t)pcd.full[17] << 8);
    if (started_ && curr_az < prev_az_) {
        auto done = buf_;
        out_frame_id = (int)frame_idx_++;
        buf_ = std::make_shared<benewake::BwPointCloud>();
        prev_az_ = curr_az;
        appendPoints(pcd);                  // belongs to the NEW frame
        return done;
    }
    prev_az_ = curr_az;
    started_ = true;
    appendPoints(pcd);
    return nullptr;
}

benewake::BwPointCloud::Ptr FrameAssembler::flush() {
    if (buf_->points.empty()) return nullptr;
    auto done = buf_;
    buf_ = std::make_shared<benewake::BwPointCloud>();
    prev_az_ = 0;
    started_ = false;
    ++frame_idx_;
    return done;
}

void FrameAssembler::reset() {
    buf_       = std::make_shared<benewake::BwPointCloud>();
    prev_az_   = 0;
    started_   = false;
    frame_idx_ = 0;
}

}  // namespace sr18
