// src/sr18_lidar_driver.cpp
#include "../include/sr18_lidar_driver.h"
#include "router/sr18_rx_router.h"
#include "router/sr18_device_state_edge.h"
#include "router/sr18_half_duplex_executor.h"
#include "router/sr18_rd_reg_sampler.h"
#include "router/sr18_ascii_ack_matcher.h"
#include "router/sr18_lut_fail_sampler.h"
#include "data/sr18_adc_monitor.h"
#include "data/sr18_pcd_info_monitor.h"
#include "data/sr18_calibration_collector.h"
#include "data/sr18_ota_session.h"
#include "data/sr18_timestamp.h"
#include "codec/sr18_fault_codec.h"
#include "transport/sr18_serial.h"
#include "transport/sr18_recording_serial.h"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <deque>
#include <fstream>
#include <iostream>
#include <mutex>
#include <set>
#include <thread>
#include <utility>

namespace sr18 { ISerial* makePlatformSerial(); }

using namespace sr18;
using namespace benewake;

namespace benewake {
const char* sr18_get_sdk_version() {
    static const std::string ver =
        std::string(SR18_SDK_VERSION_BRANCH) + "_" +
        std::to_string(SR18_SDK_VERSION_MAJOR) + "." +
        std::to_string(SR18_SDK_VERSION_MINOR) + "." +
        std::to_string(SR18_SDK_VERSION_BUILD);
    return ver.c_str();
}
}  // namespace benewake

struct SR18Lidar::Impl {
    std::unique_ptr<ISerial>                   rx_serial;
    std::unique_ptr<ISerial>                   tx_serial;   // null in receive-only mode
    sr18::RecordingSerial*                     rec_serial = nullptr; // owned by rx_serial
    std::unique_ptr<RxRouter>                  router;
    std::unique_ptr<sr18::IDeviceStateMonitor> monitor;
    std::unique_ptr<sr18::ICommandExecutor>    executor;    // null in receive-only mode
    std::unique_ptr<sr18::IRdRegSampler>       sampler;     // null in receive-only mode
    std::unique_ptr<sr18::AsciiAckMatcher>     ascii_matcher;
    std::unique_ptr<sr18::AsciiAngleMatcher>   angle_matcher;
    std::unique_ptr<sr18::LutWriteFailSampler> lut_fail;    // null in receive-only mode
    std::unique_ptr<sr18::AdcMonitor>          adc_monitor;
    std::unique_ptr<sr18::PcdInfoMonitor>      pcd_info;
    std::unique_ptr<sr18::CalibrationCollector> calib_collector;
    std::shared_ptr<DCSPProtocol> dcsp;
    std::shared_ptr<MDOPProtocol> mdop;
    std::shared_ptr<DSOPProtocol> dsop;
    std::shared_ptr<IDOPProtocol> idop;
    std::string rx_port_str;
    std::string tx_port_str;
    uint32_t rx_baud_v = 0;
    uint32_t tx_baud_v = 0;
    std::atomic<bool> save_to_flash{false};
    std::atomic<bool> opened{false};

    // Fault-frame callback (EE DD telemetry). Guarded by fault_mu_.
    FaultCallbackFunc fault_cb_   = nullptr;
    void*             fault_user_ = nullptr;
    std::mutex        fault_mu_;
    // Runtime reporting gate, driven by enableFaultInfoParsing(). Default true
    // so SDK-only callers keep the historical print/callback behaviour; the host
    // application flips it to mirror its own fault-display switch. Runtime only —
    // never persisted, resets to true per instance.
    std::atomic<bool> fault_report_enabled_{true};

    // Automatic device angle-file fetch (see fetchDeviceAngles / start()).
    // Runs on a background thread so start() never blocks on angle I/O — the
    // parsed angles apply to the running assemblers at runtime once ready
    // (geometry generation counter). Point output is never gated on it.
    std::atomic<int>  angle_state_{static_cast<int>(AngleFetchStatus::NOT_STARTED)};
    std::atomic<bool> angle_fetched_once_{false};
    std::atomic<bool> angle_abort_{false};
    std::thread       angle_thread_;
    AngleFetchCallbackFunc angle_cb_   = nullptr;
    void*                  angle_user_ = nullptr;
    std::mutex             angle_mu_;

    void setupTransport();
    void wireProtocols();
    void dispatchFault(const sr18::FaultFrame& ff);
    void startAngleFetch();
    void stopAngleFetch();
    void angleFetchBody();
};

// Launch the once-per-connection background angle fetch (idempotent).
void SR18Lidar::Impl::startAngleFetch() {
    if (!dcsp) {                                  // receive-only → leave NOT_STARTED
        std::fprintf(stderr, "[Angle] no command path (receive-only); angle "
                             "fetch skipped, using built-in DEFAULT calibration.\n");
        std::fflush(stderr);
        return;
    }
    if (angle_fetched_once_.exchange(true)) return;
    angle_thread_ = std::thread([this]{ angleFetchBody(); });
}

// Join the background fetch, interrupting any in-flight matcher wait so
// teardown does not block on the read-angle deadline.
void SR18Lidar::Impl::stopAngleFetch() {
    if (!angle_thread_.joinable()) return;
    angle_abort_.store(true);
    if (angle_matcher) angle_matcher->abort();
    angle_thread_.join();
}

void SR18Lidar::Impl::angleFetchBody() {
    // (逐通道角度值打印已按需注释掉——只报来源，不刷 18 行。)
    // auto dumpTable = [](const char* src, const float v[18], const float h[18]) {
    //     std::fprintf(stderr, "[Angle] ---- channel angles in use (source=%s) ----\n", src);
    //     for (int i = 0; i < 18; ++i)
    //         std::fprintf(stderr, "[Angle]   ch%02d  horizontal=%8.3f deg  vertical=%8.3f deg\n",
    //                      i, h[i], v[i]);
    //     std::fflush(stderr);
    // };

    // Per-attempt timeout kept modest (device answers in >=350ms per manual):
    // bounds the background work if the device does not support the command.
    constexpr int kAttemptTimeoutMs = 2000;
    std::fprintf(stderr, "[Angle] reading device angle file (up to 3 attempts)...\n");
    std::fflush(stderr);
    uint8_t raw[72] = {0};
    bool ok = false;
    for (int attempt = 1; attempt <= 3 && !ok; ++attempt) {
        if (angle_abort_.load()) return;          // shutting down
        int rc = dcsp->dcsp_read_angle_file(raw, kAttemptTimeoutMs);
        if (rc == SR18_OK) { ok = true; break; }
        std::fprintf(stderr,
                     "[Angle] device angle-file read attempt %d/3 failed rc=%d\n",
                     attempt, rc);
        std::fflush(stderr);
    }
    if (angle_abort_.load()) return;

    if (ok) {
        float v[18], h[18];
        benewake::decodeAngleFileDegrees(raw, v, h);
        benewake::setDeviceChannelAnglesDegrees(v, h);  // runtime-applies to assemblers
        angle_state_.store(static_cast<int>(AngleFetchStatus::SUCCESS));
        std::fprintf(stderr,
                     "[Angle] ==> SUCCESS: using angles read FROM THE DEVICE.\n");
        std::fflush(stderr);
        // dumpTable("DEVICE", v, h);   // 逐通道值打印已注释
    } else {
        angle_state_.store(static_cast<int>(AngleFetchStatus::FALLBACK_DEFAULT));
        std::fprintf(stderr,
                     "[Angle] ==> FALLBACK: device read failed after 3 retries; "
                     "using the built-in DEFAULT calibration (data path not blocked).\n");
        std::fflush(stderr);
        // dumpTable("DEFAULT", ...);   // 逐通道值打印已注释
    }

    AngleFetchCallbackFunc cb = nullptr; void* u = nullptr;
    { std::lock_guard<std::mutex> lk(angle_mu_); cb = angle_cb_; u = angle_user_; }
    if (cb) cb(static_cast<AngleFetchStatus>(angle_state_.load()),
               benewake::getChannelAngleSource(), u);
}

void SR18Lidar::Impl::dispatchFault(const sr18::FaultFrame& ff) {
    // Host-driven runtime gate (enableFaultInfoParsing). When off, the frame is
    // dropped here: no BW_FAULT_INFO decode, no stderr line, no callback. The
    // wire frame was already length-consumed and CRC-checked upstream, so the
    // shared-UART byte stream stays in sync either way.
    if (!fault_report_enabled_.load(std::memory_order_relaxed)) return;

    // The device emits an EE DD frame every 1 s to hold the 1 Hz cadence, even
    // with no active fault (empty queue). Such a heartbeat carries
    // total_fault_codes == 0; suppress it entirely (no stderr line, no callback)
    // so the fault channel reports only real faults. Decoding still happens
    // upstream; this is purely a reporting policy.
    if (ff.total_fault_codes == 0) return;

    benewake::BW_FAULT_INFO fi;
    uint32_t us = (uint32_t)ff.time_raw[6]
                | ((uint32_t)ff.time_raw[7] <<  8)
                | ((uint32_t)ff.time_raw[8] << 16)
                | ((uint32_t)ff.time_raw[9] << 24);
    auto ts = sr18::normalizeWireTimestamp(ff.time_raw, us);
    fi.time_s = ts.time_s;  fi.time_ns = ts.time_ns;
    fi.fs_version        = ff.fs_version;
    fi.lidar_state       = ff.lidar_state;
    fi.rolling_counter   = ff.rolling_counter;
    fi.total_fault_codes = ff.total_fault_codes;
    fi.fault_code_id     = ff.fault_code_id;
    fi.fault_code        = ff.fault_code;
    // Always report to stderr (one line); ~1 Hz, no throttle needed.
    std::fprintf(stderr, "[Fault] code=0x%04X (%s) state=%s id=%u/%u\n",
                 (unsigned)fi.fault_code, sr18::fault_code_name(fi.fault_code),
                 sr18::lidar_state_name(fi.lidar_state),
                 (unsigned)fi.fault_code_id, (unsigned)fi.total_fault_codes);
    FaultCallbackFunc cb = nullptr; void* u = nullptr;
    { std::lock_guard<std::mutex> lk(fault_mu_); cb = fault_cb_; u = fault_user_; }
    if (cb) cb(fi, u);
}

void SR18Lidar::Impl::setupTransport() {
    using namespace sr18;
    router      = std::make_unique<RxRouter>(rx_serial.get());
    adc_monitor = std::make_unique<sr18::AdcMonitor>();
    router->setAdcMonitor(adc_monitor.get());
    pcd_info    = std::make_unique<sr18::PcdInfoMonitor>();
    router->setPcdInfoMonitor(pcd_info.get());
    calib_collector = std::make_unique<sr18::CalibrationCollector>();
    router->setCalibCollector(calib_collector.get());

    if (tx_serial) {
        // Two-port mode: full command path.
        monitor  = std::make_unique<EdgeDetectingMonitor>();
        sampler  = std::make_unique<ChkStRdRegSampler>();

        // Registration order is load-bearing: sampler-first then monitor.
        // See dcsp_read_register for the contract.
        auto* sampler_obs = dynamic_cast<IChkStObserver*>(sampler.get());
        if (sampler_obs) router->addChkStObserver(sampler_obs);
        auto* chk_obs = dynamic_cast<IChkStObserver*>(monitor.get());
        if (chk_obs) router->addChkStObserver(chk_obs);

        ascii_matcher = std::make_unique<sr18::AsciiAckMatcher>();
        router->setAsciiAckMatcher(ascii_matcher.get());
        angle_matcher = std::make_unique<sr18::AsciiAngleMatcher>();
        router->setAsciiAngleMatcher(angle_matcher.get());

        lut_fail = std::make_unique<sr18::LutWriteFailSampler>();
        router->addChkStObserver(lut_fail.get());

        executor = std::make_unique<HalfDuplexExecutor>(
                       tx_serial.get(), monitor.get(), ascii_matcher.get(),
                       angle_matcher.get());
    }
    // Receive-only mode: skip executor/sampler/monitor; DCSP gets nulls.
}

void SR18Lidar::Impl::wireProtocols() {
    SlotState init_slot = tx_serial ? SlotState::SLOT_9 : SlotState::SLOT_1;
    dcsp = std::make_shared<DCSPProtocol>(executor.get(),
                                           sampler.get(),
                                           adc_monitor.get(),
                                           init_slot,
                                           lut_fail.get());
    mdop = std::make_shared<MDOPProtocol>(router.get());
    dsop = std::make_shared<DSOPProtocol>(router.get());
    idop = std::make_shared<IDOPProtocol>(router.get());
    router->setFaultConsumer([this](const sr18::FaultFrame& f){ dispatchFault(f); });
    router->start();
}

SR18Lidar::SR18Lidar(std::string port, uint32_t baud)
    : p_(std::make_unique<Impl>())
{
    p_->rx_port_str = std::move(port);
    p_->rx_baud_v   = baud;
    {
        auto rec = std::make_unique<sr18::RecordingSerial>(
            std::unique_ptr<ISerial>(makePlatformSerial()));
        p_->rec_serial = rec.get();
        p_->rx_serial  = std::move(rec);
    }
    if (p_->rx_serial->open(p_->rx_port_str, p_->rx_baud_v) == 0) {
        p_->opened.store(true);
        p_->setupTransport();
        p_->wireProtocols();
    } else {
        std::cerr << "[SR18Lidar] failed to open RX " << p_->rx_port_str << "\n";
    }
}

SR18Lidar::SR18Lidar(std::string rx_port, std::string tx_port,
                     uint32_t rx_baud, uint32_t tx_baud)
    : p_(std::make_unique<Impl>())
{
    p_->rx_port_str = std::move(rx_port);
    p_->tx_port_str = std::move(tx_port);
    p_->rx_baud_v   = rx_baud;
    p_->tx_baud_v   = tx_baud;
    {
        auto rec = std::make_unique<sr18::RecordingSerial>(
            std::unique_ptr<ISerial>(makePlatformSerial()));
        p_->rec_serial = rec.get();
        p_->rx_serial  = std::move(rec);
    }
    p_->tx_serial.reset(makePlatformSerial());
    bool rx_ok = (p_->rx_serial->open(p_->rx_port_str, p_->rx_baud_v) == 0);
    bool tx_ok = (p_->tx_serial->open(p_->tx_port_str, p_->tx_baud_v) == 0);
    if (rx_ok && tx_ok) {
        p_->opened.store(true);
        p_->setupTransport();
        p_->wireProtocols();
        // 构造时自动获取角度暂时注释（应该用不到——start() 里仍会触发一次）。
        // Construction-time angle fetch disabled for now; start() still triggers it.
        // p_->startAngleFetch();
    } else {
        if (!rx_ok) std::cerr << "[SR18Lidar] failed to open RX " << p_->rx_port_str << "\n";
        if (!tx_ok) std::cerr << "[SR18Lidar] failed to open TX " << p_->tx_port_str << "\n";
    }
}

SR18Lidar::SR18Lidar(sr18::ISerial* rx_injected, sr18::ISerial* tx_injected)
    : p_(std::make_unique<Impl>())
{
    if (!rx_injected) {
        std::cerr << "[SR18Lidar] null RX ISerial pointer; lidar will be inert\n";
        p_->opened.store(false);
        return;
    }
    {
        auto rec = std::make_unique<sr18::RecordingSerial>(
            std::unique_ptr<ISerial>(rx_injected));
        p_->rec_serial = rec.get();
        p_->rx_serial  = std::move(rec);
    }
    if (tx_injected) p_->tx_serial.reset(tx_injected);
    p_->opened.store(p_->rx_serial->isOpen()
                      && (!p_->tx_serial || p_->tx_serial->isOpen()));
    p_->setupTransport();
    p_->wireProtocols();
}

SR18Lidar::~SR18Lidar() {
    // Join the background angle fetch first (interrupts any in-flight read) so
    // it never touches dcsp/executor/serial after they are torn down below.
    p_->stopAngleFetch();
    if (p_->router) {
        p_->router->stop();
        p_->router->setAdcMonitor(nullptr);
        p_->router->setPcdInfoMonitor(nullptr);
        p_->router->setCalibActive(false);
        p_->router->setCalibCollector(nullptr);
    }
    if (p_->rx_serial) p_->rx_serial->close();
    if (p_->tx_serial) p_->tx_serial->close();
}

bool SR18Lidar::start()  {
    if (!p_->dcsp) return false;
    int rc = p_->dcsp->dcsp_enable(true);
    if (rc != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "start fail! TC=LASER_EN rc=%d\n", rc);
        return false;
    }
    // Auto-fetch the device angle file once per connection, on a background
    // thread so start() returns immediately. On success angles apply at runtime
    // (source=DEVICE); on failure the SDK stays on the built-in default and a
    // later setChannelAnglesDegrees() (source=USER) still overrides. Data path
    // is never blocked. See angleFetchBody() for the [Angle] log lines.
    // p_->startAngleFetch();
    return true;
}
bool SR18Lidar::stop()   {
    if (!p_->dcsp) return false;
    int rc = p_->dcsp->dcsp_reboot();
    if (rc != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "stop fail! TC=WR_SYS_RST rc=%d\n", rc);
        return false;
    }
    return true;
}
bool SR18Lidar::reboot() {
    if (!p_->dcsp) return false;
    int rc = p_->dcsp->dcsp_reboot();
    if (rc != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "reboot fail! TC=WR_SYS_RST rc=%d\n", rc);
        return false;
    }
    return true;
}

bool SR18Lidar::getData(BwPointCloud::Ptr& pc, int& fid, int timeout) {
    return p_->mdop && p_->mdop->getData(pc, fid, timeout);
}
bool SR18Lidar::getData(BwPointCloud::Ptr& pc, int& fid, SYS_INFO& info, int timeout) {
    bool ok = getData(pc, fid, timeout);
    if (ok && p_->dsop) info = p_->dsop->dsop_get_system_information_no_wait();
    return ok;
}
void SR18Lidar::getDataTransmissionState(uint32_t& delay, float& pkg, float& frm) {
    if (p_->mdop) {
        p_->mdop->getDataTransmissionState(delay, pkg, frm);
    } else {
        delay = 0;  pkg = 0.0f;  frm = 0.0f;
    }
}
void SR18Lidar::setOriginDistDisplayOffsetMeters(float meters) {
    if (p_->mdop) p_->mdop->setOriginDistDisplayOffsetMeters(meters);
}
float SR18Lidar::originDistDisplayOffsetMeters() const {
    return p_->mdop ? p_->mdop->originDistDisplayOffsetMeters() : 5.5f;
}

void SR18Lidar::registPointCloudCallback(PointCloudCallbackFunc f, void* u) {
    if (p_->mdop) p_->mdop->registPointCloudCallback(f, u);
}
void SR18Lidar::cancelPointCloudCallback() {
    if (p_->mdop) p_->mdop->cancelPointCloudCallback();
}
void SR18Lidar::registHeartBeatCallback(HeartBeatCallbackFunc f, void* u) {
    if (p_->dsop) p_->dsop->dsop_regist_heart_beat_callback(f, u);
}
void SR18Lidar::cancelHeartBeatCallback() {
    if (p_->dsop) p_->dsop->dsop_cancel_heart_beat_callback();
}
void SR18Lidar::registIMUDataCallback(IMUDataCallbackFunc f, void* u) {
    if (p_->idop) p_->idop->registIMUDataCallback(f, u);
}
void SR18Lidar::cancelIMUDataCallback() {
    if (p_->idop) p_->idop->cancelIMUDataCallback();
}
std::deque<BW_IMU_INFO> SR18Lidar::getIMUData() {
    return p_->idop ? p_->idop->getIMUData() : std::deque<BW_IMU_INFO>{};
}
void SR18Lidar::registFaultCallback(FaultCallbackFunc f, void* u) {
    std::lock_guard<std::mutex> lk(p_->fault_mu_);
    p_->fault_cb_ = f; p_->fault_user_ = u;
}
void SR18Lidar::cancelFaultCallback() {
    std::lock_guard<std::mutex> lk(p_->fault_mu_);
    p_->fault_cb_ = nullptr; p_->fault_user_ = nullptr;
}
void SR18Lidar::enableFaultInfoParsing(bool enable) {
    p_->fault_report_enabled_.store(enable, std::memory_order_relaxed);
}
bool SR18Lidar::faultInfoParsingEnabled() const {
    return p_->fault_report_enabled_.load(std::memory_order_relaxed);
}

// ---- Register R/W (UP board = primary) ----
static bool readN(DCSPProtocol* d, bool down, uint32_t addr, int size,
                   std::vector<uint32_t>& out) {
    if (!d) return false;
    out.assign(size, 0);
    for (int i = 0; i < size; ++i) {
        if (d->dcsp_read_register((uint16_t)(addr + i), out[i], down) != SR18_OK) return false;
    }
    return true;
}
static bool writeN(DCSPProtocol* d, bool down, bool save,
                    const uint32_t* values, uint32_t addr, int size) {
    if (!d) return false;
    std::vector<uint16_t> addrs(size);
    for (int i = 0; i < size; ++i) addrs[i] = (uint16_t)(addr + i);
    return d->dcsp_write_register(addrs.data(), values, size, save, down) == SR18_OK;
}

bool SR18Lidar::readRegister(int32_t* v, uint32_t a, int n) {
    std::vector<uint32_t> tmp;
    if (!readN(p_->dcsp.get(), false, a, n, tmp)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "readRegister addr=0x%04x n=%d fail!\n",
            static_cast<unsigned>(a), n);
        return false;
    }
    for (int i = 0; i < n; ++i) v[i] = (int32_t)tmp[i];
    return true;
}
bool SR18Lidar::readRegister(uint32_t* v, uint32_t a, int n) {
    std::vector<uint32_t> tmp;
    if (!readN(p_->dcsp.get(), false, a, n, tmp)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "readRegister addr=0x%04x n=%d fail!\n",
            static_cast<unsigned>(a), n);
        return false;
    }
    for (int i = 0; i < n; ++i) v[i] = tmp[i];
    return true;
}
bool SR18Lidar::writeRegister(int32_t* v, uint32_t a, int n) {
    std::vector<uint32_t> tmp(n);
    for (int i = 0; i < n; ++i) tmp[i] = (uint32_t)v[i];
    if (!writeN(p_->dcsp.get(), false, p_->save_to_flash.load(), tmp.data(), a, n)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "writeRegister addr=0x%04x n=%d fail!\n",
            static_cast<unsigned>(a), n);
        return false;
    }
    return true;
}
bool SR18Lidar::writeRegister(uint32_t* v, uint32_t a, int n) {
    if (!writeN(p_->dcsp.get(), false, p_->save_to_flash.load(), v, a, n)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "writeRegister addr=0x%04x n=%d fail!\n",
            static_cast<unsigned>(a), n);
        return false;
    }
    return true;
}
bool SR18Lidar::writeRegisters(uint32_t* addrs, uint32_t* v, int n,
                               int inter_packet_delay_ms) {
    if (!p_->dcsp || n <= 0 || !addrs || !v) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "writeRegisters n=%d invalid\n", n);
        return false;
    }
    // Facade addresses are uint32_t (Benewake-style); the wire/DCSP layer uses
    // uint16_t register addresses. Narrow here, preserving order and pairing.
    std::vector<uint16_t> a16(n);
    for (int i = 0; i < n; ++i) a16[i] = (uint16_t)addrs[i];
    if (p_->dcsp->dcsp_write_register(a16.data(), v, n,
                                      p_->save_to_flash.load(), /*down=*/false,
                                      /*timeout_ms=*/1000,
                                      inter_packet_delay_ms) != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "writeRegisters n=%d fail!\n", n);
        return false;
    }
    return true;
}
bool SR18Lidar::writeRegisters(uint32_t* addrs, int32_t* v, int n,
                               int inter_packet_delay_ms) {
    if (n <= 0 || !v) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "writeRegisters n=%d invalid\n", n);
        return false;
    }
    std::vector<uint32_t> tmp(n);
    for (int i = 0; i < n; ++i) tmp[i] = (uint32_t)v[i];
    return writeRegisters(addrs, tmp.data(), n, inter_packet_delay_ms);
}
bool SR18Lidar::readDownBoardRegister(int32_t* v, uint32_t a, int n) {
    std::vector<uint32_t> tmp;
    if (!readN(p_->dcsp.get(), true, a, n, tmp)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "readDownBoardRegister addr=0x%04x n=%d fail!\n",
            static_cast<unsigned>(a), n);
        return false;
    }
    for (int i = 0; i < n; ++i) v[i] = (int32_t)tmp[i];
    return true;
}
bool SR18Lidar::readDownBoardRegister(uint32_t* v, uint32_t a, int n) {
    std::vector<uint32_t> tmp;
    if (!readN(p_->dcsp.get(), true, a, n, tmp)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "readDownBoardRegister addr=0x%04x n=%d fail!\n",
            static_cast<unsigned>(a), n);
        return false;
    }
    for (int i = 0; i < n; ++i) v[i] = tmp[i];
    return true;
}
bool SR18Lidar::writeDownBoardRegister(int32_t* v, uint32_t a, int n) {
    std::vector<uint32_t> tmp(n);
    for (int i = 0; i < n; ++i) tmp[i] = (uint32_t)v[i];
    if (!writeN(p_->dcsp.get(), true, p_->save_to_flash.load(), tmp.data(), a, n)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "writeDownBoardRegister addr=0x%04x n=%d fail!\n",
            static_cast<unsigned>(a), n);
        return false;
    }
    return true;
}
bool SR18Lidar::writeDownBoardRegister(uint32_t* v, uint32_t a, int n) {
    if (!writeN(p_->dcsp.get(), true, p_->save_to_flash.load(), v, a, n)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "writeDownBoardRegister addr=0x%04x n=%d fail!\n",
            static_cast<unsigned>(a), n);
        return false;
    }
    return true;
}
bool SR18Lidar::writeDownBoardRegisters(uint32_t* addrs, uint32_t* v, int n,
                                        int inter_packet_delay_ms) {
    if (!p_->dcsp || n <= 0 || !addrs || !v) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "writeDownBoardRegisters n=%d invalid\n", n);
        return false;
    }
    // Symmetric with writeRegisters(); only difference is down=true.
    std::vector<uint16_t> a16(n);
    for (int i = 0; i < n; ++i) a16[i] = (uint16_t)addrs[i];
    if (p_->dcsp->dcsp_write_register(a16.data(), v, n,
                                      p_->save_to_flash.load(), /*down=*/true,
                                      /*timeout_ms=*/1000,
                                      inter_packet_delay_ms) != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "writeDownBoardRegisters n=%d fail!\n", n);
        return false;
    }
    return true;
}
bool SR18Lidar::writeDownBoardRegisters(uint32_t* addrs, int32_t* v, int n,
                                        int inter_packet_delay_ms) {
    if (n <= 0 || !v) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "writeDownBoardRegisters n=%d invalid\n", n);
        return false;
    }
    std::vector<uint32_t> tmp(n);
    for (int i = 0; i < n; ++i) tmp[i] = (uint32_t)v[i];
    return writeDownBoardRegisters(addrs, tmp.data(), n, inter_packet_delay_ms);
}

/* Register-style LUT retired 2026-07-07 (see spec 2026-07-07). Superseded by
   the boot-unified SR18Lidar::downloadLUT(std::string, LutTarget) below.
bool SR18Lidar::downloadLUT(uint8_t id, const uint8_t* data, uint16_t len) {
    if (!p_->dcsp) return false;
    int rc = p_->dcsp->dcsp_download_lut(id, data, len);
    if (rc != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "downloadLUT id=%u len=%u fail! rc=%d\n",
            static_cast<unsigned>(id), static_cast<unsigned>(len), rc);
        return false;
    }
    return true;
}
bool SR18Lidar::downloadLUT(std::string file_path, bool ) {
    std::ifstream f(file_path, std::ios::binary);
    if (!f) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "downloadLUT: cannot open '%s'\n", file_path.c_str());
        return false;
    }
    f.seekg(0, std::ios::end);
    auto sz = f.tellg();
    f.seekg(0);
    std::vector<uint8_t> buf((size_t)sz);
    f.read((char*)buf.data(), sz);
    return downloadLUT(1, buf.data(), (uint16_t)buf.size());
}
*/

// Firmware upgrade — single whole-machine OTA (up-board + down-board burned
// together by the device). Renamed from downloadFirmwareOta() 2026-07-28 to
// restore the old boot-era call shape; the retired binary boot path
// (TC 0x03/0x08 + BootTarget) was deleted in the same change.
bool SR18Lidar::downloadFirmware(std::string firmware_file) {
    const auto upgrade_started_at = std::chrono::steady_clock::now();

    if (!p_->dcsp || !p_->tx_serial || !p_->rx_serial || !p_->router) {
        std::fprintf(stderr, "downloadFirmware: requires two-port mode\n");
        return false;
    }
    std::ifstream f(firmware_file, std::ios::binary);
    if (!f) { std::fprintf(stderr, "downloadFirmware: cannot open '%s'\n",
                           firmware_file.c_str()); return false; }
    f.seekg(0, std::ios::end); auto sz = f.tellg(); f.seekg(0);
    if (sz <= 0) { std::fprintf(stderr, "downloadFirmware: '%s' empty\n",
                                firmware_file.c_str()); return false; }
    std::vector<uint8_t> img((size_t)sz);
    f.read((char*)img.data(), sz);
    if (f.gcount() != (std::streamsize)sz) {
        std::fprintf(stderr, "downloadFirmware: short read\n"); return false;
    }

    // Handoff commands run with the router alive (ACK via the 3.125M matcher).
    if (p_->dcsp->dcsp_enter_upgrade_mode() != SR18_OK) {
        std::fprintf(stderr, "downloadFirmware: enter-upgrade failed\n"); return false;
    }
    if (p_->dcsp->dcsp_request_whole_package() != SR18_OK) {
        std::fprintf(stderr, "downloadFirmware: request-package failed\n"); return false;
    }

    // Take over the RS485 line: stop router, switch to 115200, restore on exit.
    const uint32_t normal_baud = p_->rx_baud_v;
    if (normal_baud == 0) {
        std::fprintf(stderr, "downloadFirmware: rx baud unknown (injected-serial ctor); OTA unsupported\n");
        return false;
    }
    p_->router->stop();
    struct BaudSwitchGuard {
        sr18::RxRouter* router; sr18::ISerial* serial; uint32_t restore_baud;
        ~BaudSwitchGuard() { serial->setBaud(restore_baud); router->start(); }
    } guard{p_->router.get(), p_->rx_serial.get(), normal_baud};

    if (p_->rx_serial->setBaud(115200) != 0) {
        std::fprintf(stderr, "downloadFirmware: setBaud 115200 failed\n"); return false;
    }
    sr18::OtaSession session(p_->rx_serial.get());
    sr18::OtaParams params;   // info stays 0 — 升级信息 semantics bench-pending
    int rc = session.run(img.data(), img.size(), params);
    if (rc != SR18_OK) {
        std::fprintf(stderr, "downloadFirmware: session rc=%d\n", rc); return false;
    }

    const auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now() - upgrade_started_at).count();
    std::fprintf(stderr,
                 "downloadFirmware: upgrade succeeded, elapsed=%lld ms (%.3f s)\n",
                 static_cast<long long>(elapsed_ms),
                 static_cast<double>(elapsed_ms) / 1000.0);
    return true;   // guard restores 3.125M + router on the way out
}

bool SR18Lidar::downloadLUT(std::string file_path, LutTarget target) {
    if (!p_->dcsp) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "downloadLUT: DCSP not available\n");
        return false;
    }
    std::ifstream f(file_path, std::ios::binary);
    if (!f) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "downloadLUT: cannot open '%s'\n", file_path.c_str());
        return false;
    }
    f.seekg(0, std::ios::end);
    auto sz = f.tellg();
    f.seekg(0);
    if (sz <= 0) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "downloadLUT: '%s' is empty\n", file_path.c_str());
        return false;
    }
    std::vector<uint8_t> buf((size_t)sz);
    f.read((char*)buf.data(), sz);

    int rc = (target == LutTarget::UP_BOARD)
           ? p_->dcsp->dcsp_wr_lut_up(buf.data(), buf.size())
           : p_->dcsp->dcsp_wr_lut_down(buf.data(), buf.size());
    if (rc != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "downloadLUT: '%s' target=%d fail rc=%d\n",
                     file_path.c_str(), (int)target, rc);
        return false;
    }
    return true;
}

bool SR18Lidar::updateFlash(bool enable) {
    p_->save_to_flash.store(enable); return true;
}
bool SR18Lidar::getFlashMode() const { return p_->save_to_flash.load(); }
bool SR18Lidar::setTimestamp(BwTimestamp ts) {
    if (!p_->dcsp) return false;
    int rc = p_->dcsp->dcsp_set_timestamp(ts);
    if (rc != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "setTimestamp fail! sec=%u ns=%u rc=%d\n",
            static_cast<unsigned>(ts.time_s),
            static_cast<unsigned>(ts.time_ns), rc);
        return false;
    }
    return true;
}

bool SR18Lidar::getAdcValues(uint16_t out[8]) {
    if (!p_->dcsp) return false;
    int rc = p_->dcsp->dcsp_get_adc_values(out);
    if (rc != SR18_OK) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "getAdcValues fail! rc=%d\n", rc);
        return false;
    }
    return true;
}

// ---- b1 telemetry tail (lidar state / TDM) --------------------------------
// Shared by PCD and origin_dist frames; all return false until the first
// CRC-valid telemetry frame has been observed. Contamination is NOT here — it
// rides on every BwPoint (see BwPoint::contamination); the frame-level getter
// was removed 2026-07-30 (PRO-84).

bool SR18Lidar::getLidarState(uint8_t& state) {
    return p_->pcd_info && p_->pcd_info->getLidarState(state);
}

bool SR18Lidar::getMotorSpeedRpm(uint16_t& rpm) {
    return p_->pcd_info && p_->pcd_info->getTdmData(sr18::TDM_ID_MOTOR_RPM, rpm);
}

bool SR18Lidar::getTdmData(uint8_t tdm_id, uint16_t& data) {
    return p_->pcd_info && p_->pcd_info->getTdmData(tdm_id, data);
}

bool SR18Lidar::getDeviceInformation(std::string& v, std::string& fv,
                                      int& tot, int& line, int& chan, std::string& sn) {
    // Channel count is fixed by the SR18 hardware design.
    chan = 18;
    // total_points / line_points come from device geometry registers (TBD address).
    tot = 0;
    line = 0;
    // Pull the latest heartbeat. If a status frame has arrived since open(),
    // SYS_INFO.version / fpga_version carry "SR18 UP=vN" / "SR18 DOWN=vN"
    // formatted from the actual UP_VER / DW_VER bytes in the wire frame
    // (see DSOPProtocol::Impl::onFrame). Otherwise dsop_get_system_information_no_wait
    // returns a default-constructed SYS_INFO whose strings are the SDK
    // placeholders (SR18_SDK_VERSION_STRING etc.). Either way the call returns true.
    if (p_->dsop) {
        SYS_INFO info = p_->dsop->dsop_get_system_information_no_wait();
        v  = info.version;
        fv = info.fpga_version;
        sn = info.sn;          // SR18 status packet does not carry SN �?placeholder until
                                // a SN-readRegister implementation lands (address TBD).
    } else {
        v  = SR18_SDK_VERSION_STRING;
        fv = "SR18-FPGA-0.0.0";
        sn = "SR18-PLACEHOLDER";
    }
    return true;
}

std::shared_ptr<DCSPProtocol> SR18Lidar::getDCSP() { return p_->dcsp; }
std::shared_ptr<MDOPProtocol> SR18Lidar::getMDOP() { return p_->mdop; }
std::shared_ptr<DSOPProtocol> SR18Lidar::getDSOP() { return p_->dsop; }

int SR18Lidar::switchMode(benewake::AsciiMode mode, int timeout_ms) {
    if (!p_->dcsp) return SR18_ERR_NOT_SUPPORTED;
    return p_->dcsp->dcsp_switch_mode(mode, timeout_ms);
}

namespace {

bool readTdmAsciiGroup(const sr18::PcdInfoMonitor& monitor,
                       uint8_t first_id, uint8_t last_id,
                       std::string& out) {
    out.clear();
    out.reserve(8);
    for (int id = first_id; id >= last_id; --id) {
        uint16_t word = 0;
        if (!monitor.getTdmData(static_cast<uint8_t>(id), word)) return false;
        out.push_back(static_cast<char>(word & 0xFF));
        out.push_back(static_cast<char>((word >> 8) & 0xFF));
    }
    while (!out.empty() && (out.back() == '\0' || out.back() == ' '))
        out.pop_back();
    return true;
}

}  // namespace

int SR18Lidar::readVersion(std::string& version, int timeout_ms) {
    version.clear();
    if (!p_->pcd_info) return SR18_ERR_NOT_SUPPORTED;
    if (timeout_ms < 0) return SR18_ERR_PARAM;

    const auto deadline = std::chrono::steady_clock::now() +
                          std::chrono::milliseconds(timeout_ms);
    for (;;) {
        std::string software;
        std::string firmware;
        if (readTdmAsciiGroup(*p_->pcd_info, 0x0F, 0x0C, software) &&
            readTdmAsciiGroup(*p_->pcd_info, 0x13, 0x10, firmware)) {
            version = software + firmware;
            return SR18_OK;
        }
        if (std::chrono::steady_clock::now() >= deadline) return SR18_TIMEOUT;
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
}

int SR18Lidar::readAngleFile(uint8_t out[72], int timeout_ms) {
    if (!p_->dcsp) return SR18_ERR_NOT_SUPPORTED;
    return p_->dcsp->dcsp_read_angle_file(out, timeout_ms);
}

void SR18Lidar::getChannelAngles(float vertical_deg[18], float horizontal_deg[18],
                                 benewake::AngleSource& source) {
    benewake::getChannelAnglesDegrees(vertical_deg, horizontal_deg);
    source = benewake::getChannelAngleSource();
}

AngleFetchStatus SR18Lidar::getAngleFetchStatus() const {
    return static_cast<AngleFetchStatus>(p_->angle_state_.load());
}

void SR18Lidar::registAngleFetchCallback(AngleFetchCallbackFunc f, void* user) {
    std::lock_guard<std::mutex> lk(p_->angle_mu_);
    p_->angle_cb_   = f;
    p_->angle_user_ = user;
}

void SR18Lidar::cancelAngleFetchCallback() {
    std::lock_guard<std::mutex> lk(p_->angle_mu_);
    p_->angle_cb_   = nullptr;
    p_->angle_user_ = nullptr;
}

// (append to src/sr18_lidar_driver.cpp)

namespace {
void warnUnsupported(const char* name) {
    static std::mutex warn_mu;
    static std::set<std::string> warned;
    std::lock_guard<std::mutex> lk(warn_mu);
    if (warned.insert(name).second) {
        std::cerr << "[SR18Lidar] " << name
                  << " not supported on SR18; returning default value\n";
    }
}
}  // namespace

#define STUB_BOOL(NAME, ...) \
    bool SR18Lidar::NAME(__VA_ARGS__) { warnUnsupported(#NAME); return false; }

STUB_BOOL(bindLocalAddress, std::string, uint32_t, uint32_t, uint32_t,
                              std::string, uint32_t, uint32_t, uint32_t)
STUB_BOOL(setConnection, std::string, uint32_t, int)
bool SR18Lidar::getConnection(std::string& ip, uint32_t& port, int& type) {
    warnUnsupported("getConnection"); ip=""; port=0; type=0; return false;
}
STUB_BOOL(setDeviceIPAndPort, std::string, uint32_t, uint32_t, std::string, std::string)
STUB_BOOL(setDestinationIPAndPort, std::string, uint32_t, uint32_t, uint32_t,
                                     std::string, std::string, std::string, uint16_t)
STUB_BOOL(setMulticastIPAndPort, std::string, uint32_t)
bool SR18Lidar::getMulticastIPAndPort(std::string& ip, uint32_t& p) {
    warnUnsupported("getMulticastIPAndPort"); ip=""; p=0; return false;
}
STUB_BOOL(setMulticastStatus, bool)
bool SR18Lidar::getMulticastStatus(bool& e) { warnUnsupported("getMulticastStatus"); e=false; return false; }
STUB_BOOL(setDHCPStatus, bool)
bool SR18Lidar::getDHCPStatus(bool& e) { warnUnsupported("getDHCPStatus"); e=false; return false; }
STUB_BOOL(setNTPParameters, std::string, uint32_t)
bool SR18Lidar::getNTPInfo(uint8_t& a, uint8_t& b, std::string& c, uint32_t& d) {
    warnUnsupported("getNTPInfo"); a=0;b=0;c="";d=0; return false;
}
STUB_BOOL(setClockConfig, bool, uint8_t, bool, uint8_t)
bool SR18Lidar::getClockConfig(bool& a, uint8_t& b, bool& c, uint8_t& d) {
    warnUnsupported("getClockConfig"); a=false;b=0;c=false;d=0; return false;
}
bool SR18Lidar::getPTPInfo(uint8_t& a, uint8_t& b, int& c, int& d, int& e, int& f, int& g) {
    warnUnsupported("getPTPInfo"); a=b=0; c=d=e=f=g=0; return false;
}
STUB_BOOL(setNetworkTimeout, int)
bool SR18Lidar::getNetworkTimeout(int& t) { warnUnsupported("getNetworkTimeout"); t=0; return false; }
STUB_BOOL(setDSOPDestIPAndPort, std::string, uint32_t)
bool SR18Lidar::getDSOPDestIPAndPort(std::string& ip, uint32_t& p) {
    warnUnsupported("getDSOPDestIPAndPort"); ip=""; p=0; return false;
}
STUB_BOOL(enablieStaticARP, bool)
bool SR18Lidar::searchDevice(SYS_INFO&, int) { warnUnsupported("searchDevice"); return false; }

STUB_BOOL(setWorkMode, int)
bool SR18Lidar::getWorkMode(int& m, int, int) { warnUnsupported("getWorkMode"); m=0; return false; }
STUB_BOOL(setROI, int, int, int, int)
STUB_BOOL(setROI, bool, const std::vector<float>&)
bool SR18Lidar::getROI(int& a, int& b, int& c, int& d) {
    warnUnsupported("getROI"); a=b=c=d=0; return false;
}
STUB_BOOL(setROIStatus, bool)
bool SR18Lidar::getROIStatus(bool& e) { warnUnsupported("getROIStatus"); e=false; return false; }
STUB_BOOL(setFOVCenter, float, float)
bool SR18Lidar::getFOVCenter(float& a, float& b) { warnUnsupported("getFOVCenter"); a=b=0; return false; }
STUB_BOOL(setFOVROILocation, float, float)
STUB_BOOL(setFOVROISize, float, float)
STUB_BOOL(setMultiEchoMode, int)
bool SR18Lidar::getMultiEchoMode(int& m) { warnUnsupported("getMultiEchoMode"); m=0; return false; }
STUB_BOOL(setCoordiateSystem, uint8_t)
bool SR18Lidar::getCoordiateSystem(uint8_t& c) { warnUnsupported("getCoordiateSystem"); c=0; return false; }
STUB_BOOL(setExtrinsicParameters, bool, const std::vector<float>&)
bool SR18Lidar::getExtrinsicParameters(bool& en, std::vector<float>& v) {
    warnUnsupported("getExtrinsicParameters"); en=false; v.clear(); return false;
}
STUB_BOOL(setLocalTransform, bool, float, float, float, float, float, float)
STUB_BOOL(setPower, int)
bool SR18Lidar::getPower(int& p) { warnUnsupported("getPower"); p=0; return false; }
STUB_BOOL(enableABFrame, bool)
STUB_BOOL(enableTimeWindowMode, bool, uint32_t)
STUB_BOOL(enableSunlightResistance, bool)
STUB_BOOL(enableAntiInterference, bool)
STUB_BOOL(enableWindowHeating, int, int, int, int, int, int, int, int, int, int)
STUB_BOOL(enableDataForwarding, bool, std::string, int)
STUB_BOOL(enableLog, bool, std::string)

bool SR18Lidar::enableRawRecord(bool _enable, std::string _path) {
    if (!p_->rec_serial) return false;
    if (_enable) {
        if (!p_->opened.load()) {
            std::cerr << "[SR18Lidar] enableRawRecord: lidar not opened\n";
            return false;
        }
        return p_->rec_serial->startRecord(_path);
    }
    p_->rec_serial->stopRecord();
    return true;
}

bool SR18Lidar::enableCalibration(bool enable) {
    if (!p_->dcsp) return false;

    // Calibration mode is gated on the device by TWO registers: upper board
    // 0x3038 and lower board 0x340D. Both go to 1 to enter, both to 0 to exit.
    uint16_t up_addr   = 0x3038;   // upper board (down=false)
    uint16_t down_addr = 0x340D;   // lower board (down=true)
    auto wr = [&](uint16_t addr, uint32_t v, bool down) {
        return p_->dcsp->dcsp_write_register(&addr, &v, 1, /*save=*/false, down) == SR18_OK;
    };

    if (enable) {
        // Enter: both boards must ACK before we trust the calibration stream.
        const bool up_ok   = wr(up_addr, 1u, /*down=*/false);
        const bool down_ok = up_ok && wr(down_addr, 1u, /*down=*/true);
        if (!up_ok || !down_ok) {
            std::fprintf(stderr,
                "[SR18Lidar] enableCalibration(true) failed: 0x3038(up)=%d 0x340D(down)=%d\n",
                (int)up_ok, (int)down_ok);
            // Revert any partial enter so the device is never left half-in.
            if (up_ok)   wr(up_addr,   0u, /*down=*/false);
            if (down_ok) wr(down_addr, 0u, /*down=*/true);
            return false;
        }
        if (p_->router) p_->router->setCalibActive(true);
        return true;
    }

    // Exit: clear BOTH device registers (both attempted, best-effort), then drop
    // the host-side RxRouter gate. The brief window after a device-write before
    // the gate flips is benign �?the device has reverted those slots to RD_REG/
    // ADC, so feedWord sees bit[31]=0 and drops them, and collectCalibration has
    // already returned (collector disarmed).
    const bool up_ok   = wr(up_addr,   0u, /*down=*/false);
    const bool down_ok = wr(down_addr, 0u, /*down=*/true);
    if (p_->router) p_->router->setCalibActive(false);
    if (!up_ok || !down_ok) {
        std::fprintf(stderr,
            "[SR18Lidar] enableCalibration(false): 0x3038(up)=%d 0x340D(down)=%d "
            "(device may still be partly in calibration)\n",
            (int)up_ok, (int)down_ok);
    }
    return up_ok && down_ok;
}

bool SR18Lidar::waitSpeedStable(int window_s, double tol, int timeout_ms) {
    if (!p_->dcsp) return false;
    using clock = std::chrono::steady_clock;
    const auto start    = clock::now();
    const auto deadline = start + std::chrono::milliseconds(timeout_ms);
    const auto window   = std::chrono::seconds(window_s);
    std::deque<std::pair<clock::time_point, double>> win;
    while (clock::now() < deadline) {
        uint32_t rpm = 0;
        if (p_->dcsp->dcsp_read_register(0x3037, rpm) == SR18_OK) {
            auto now = clock::now();
            win.emplace_back(now, (double)rpm);
            while (!win.empty() && (now - win.front().first) > window) win.pop_front();
            // Judge once we've polled for a full window_s �?by then `win` holds the
            // last window_s of samples. (Gating on `now - win.front()` would be a
            // bug: eviction caps that strictly below window, so it could never
            // reach >= window even with rock-steady speed.)
            if (win.size() >= 2 && (now - start) >= window) {
                double mn = win.front().second, mx = mn, sum = 0;
                for (auto& s : win) { mn = std::min(mn, s.second); mx = std::max(mx, s.second); sum += s.second; }
                double mean = sum / win.size();
                if (mean > 0.0 && (mx - mn) / mean < tol) return true;
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }
    return false;
}

bool SR18Lidar::collectCalibration(int target_revs, CalibrationResult& out, int timeout_ms) {
    if (!p_->calib_collector) return false;
    p_->calib_collector->arm(target_revs);
    auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout_ms);
    return p_->calib_collector->collect(out, deadline);
}

STUB_BOOL(setRCMode, bool)
bool SR18Lidar::getRCMode(bool& e) { warnUnsupported("getRCMode"); e=false; return false; }
STUB_BOOL(setGaze, bool)
bool SR18Lidar::getGaze(bool& e) { warnUnsupported("getGaze"); e=false; return false; }
STUB_BOOL(setIMUConfig, bool)
bool SR18Lidar::getIMUConfig(bool& e) { warnUnsupported("getIMUConfig"); e=false; return false; }
STUB_BOOL(setSignalMessage, char*)
STUB_BOOL(setFrontViewFilter, bool, int, int, int, int, float, float)
bool SR18Lidar::getFrontViewFilterParameters(bool& s, int& r, int& c, int& b, int& n, float& h, float& v) {
    warnUnsupported("getFrontViewFilterParameters"); s=false; r=c=b=n=0; h=v=0.f; return false;
}
bool SR18Lidar::restoreToDefault() { warnUnsupported("restoreToDefault"); return false; }
bool SR18Lidar::getDSPVersion(std::string& a, std::string& b) {
    warnUnsupported("getDSPVersion"); a=b=""; return false;
}
STUB_BOOL(setAutomobileInformation, int, int, int, int, int, int, int, int)
STUB_BOOL(setAutorunStatus, bool)
bool SR18Lidar::getAutorunStatus(bool& e) { warnUnsupported("getAutorunStatus"); e=false; return false; }
STUB_BOOL(setOfflineLoggerParameters, int, int, int, bool, bool, bool)
bool SR18Lidar::getOfflineLoggerParameters(int& a, int& b, int& c, bool& d, bool& e, bool& f) {
    warnUnsupported("getOfflineLoggerParameters"); a=b=c=0; d=e=f=false; return false;
}
bool SR18Lidar::getOfflineLoggerInfo(int& n) { warnUnsupported("getOfflineLoggerInfo"); n=0; return false; }
STUB_BOOL(uploadOfflineLogger, std::string, int)
STUB_BOOL(shutdownWarning, int)
STUB_BOOL(startOnlyReceiver, std::string, int, uint8_t, uint16_t, bool, bool, int)
STUB_BOOL(switchProtocol, int)
STUB_BOOL(setDeviceSN, const char*)
bool SR18Lidar::clearConfig() { warnUnsupported("clearConfig"); return false; }
BwPointCloud::Ptr SR18Lidar::timeWindowDataQueueFront() { return nullptr; }
void SR18Lidar::timeWindowDataQueuePop() {}
BwPointCloud::Ptr SR18Lidar::timeWindowDataQueuePopFront() { return nullptr; }
int SR18Lidar::timeWindowDataQueueSize() { return 0; }
STUB_BOOL(setTimestampFormat, int)
bool SR18Lidar::getTimestampFormat(int& s) { warnUnsupported("getTimestampFormat"); s=0; return false; }
