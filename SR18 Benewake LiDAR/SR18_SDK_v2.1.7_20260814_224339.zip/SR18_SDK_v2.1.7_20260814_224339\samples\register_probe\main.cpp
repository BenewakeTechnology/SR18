#include "sr18_lidar_driver.h"

#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>

static uint32_t parseU32(const char* s) {
    return static_cast<uint32_t>(std::strtoul(s, nullptr, 0));
}

int main(int argc, char** argv) {
    std::string rx_port = (argc > 1) ? argv[1] : "COM8";
    std::string tx_port = (argc > 2) ? argv[2] : "COM9";
    uint32_t addr = (argc > 3) ? parseU32(argv[3]) : 0x0080u;

    // Two-port construction: RX 3.125 Mbps for upstream frames,
    // TX 9600 bps for register read/write commands.
    benewake::SR18Lidar lidar(rx_port, tx_port);
    lidar.updateFlash(false);

    uint32_t before = 0;
    bool read1 = lidar.readRegister(&before, addr, 1);
    std::cout << "read1 addr=0x" << std::hex << addr
              << " ok=" << std::dec << (read1 ? 1 : 0)
              << " value=0x" << std::hex << before << std::dec << "\n";
    if (!read1) return 2;

    uint32_t write_value = (argc > 4) ? parseU32(argv[4]) : before;
    bool write = lidar.writeRegister(&write_value, addr, 1);
    std::cout << "write addr=0x" << std::hex << addr
              << " value=0x" << write_value
              << " ok=" << std::dec << (write ? 1 : 0) << "\n";
    if (!write) return 3;

    uint32_t after = 0;
    bool read2 = lidar.readRegister(&after, addr, 1);
    std::cout << "read2 addr=0x" << std::hex << addr
              << " ok=" << std::dec << (read2 ? 1 : 0)
              << " value=0x" << std::hex << after << std::dec << "\n";
    if (!read2) return 4;

    return after == write_value ? 0 : 5;
}
