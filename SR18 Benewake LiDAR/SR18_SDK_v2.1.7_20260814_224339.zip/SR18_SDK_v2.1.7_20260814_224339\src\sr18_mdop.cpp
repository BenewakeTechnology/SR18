// src/sr18_mdop.cpp
#include "../include/sr18_mdop.h"
#include "../include/sr18_msg_queue.h"
#include "../include/sr18_protocol.h"
#include "router/sr18_rx_router.h"
#include "assembler/sr18_frame_assembler.h"
#include "data/sr18_origin_dist_decoder.h"
#include "assembler/sr18_origin_dist_assembler.h"
#include <atomic>
#include <thread>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <chrono>
#include <ctime>
#include <iostream>

using namespace sr18;
using namespace benewake;

namespace {
struct RawFrame {
    uint8_t  d_type = 0;
    uint16_t len    = 0;
    uint8_t  bytes[ORIGIN_DIST_FRAME_LEN] = {0};   // 532B (largest) fits any current D_TYPE
};

struct SaveItem {
    benewake::BwOriginDist data;
};
}  // namespace

struct MDOPProtocol::Impl {
    RxRouter* router = nullptr;
    FrameAssembler asm_;
    OriginDistFrameAssembler od_asm_;

    // Async pipeline
    sr18::MsgQueue<RawFrame>          input_queue_{"mdop_input", 512};
    std::thread                       decode_thread_;
    std::atomic<bool>                 running_{false};

    // Sphere output (existing semantics: deque + cv + capacity 10 + cb hook)
    std::mutex mu_;
    std::condition_variable cv_;
    std::deque<std::pair<BwPointCloud::Ptr, int>> queue_;
    std::atomic<bool> cb_enabled_{false};
    PointCloudCallbackFunc cb_      = nullptr;
    void*                  cb_user_ = nullptr;

    // origin_dist output
    sr18::MsgQueue<BwOriginDist> origin_dist_queue_{"mdop_origin_dist", 512};

    // save data
    sr18::MsgQueue<SaveItem> save_queue_{"mdop_save", 512};
    std::thread                  save_thread_;
    std::atomic<bool>            save_running_{false};
    std::atomic<int>             save_remaining_{0};
    std::string                  save_path_, save_name_, save_suffix_;

    // ── packet-loss tracker (spec 2026-05-18 §4.3) ──
    std::mutex                            stats_mu_;
    bool                                  last_seq_valid_         = false;
    uint16_t                              last_observed_seq_      = 0;
    uint16_t                              window_start_seq_       = 0;
    std::chrono::steady_clock::time_point window_start_tp_;
    uint32_t                              lost_packets_in_window_ = 0;
    std::atomic<float>                    pkg_loss_rate_{0.0f};
    std::chrono::milliseconds             stats_window_{10000};

    // Called once per observed PCD/origin_dist packet (per-packet, not per-emit).
    // Detects SEQ gaps, logs to stderr in the form
    //   "[MDOP] packet loss: <N> packets lost (SEQ <a> -> <b>)"
    // where <a> is the previous observed SEQ and <b> is the current one,
    // and refreshes the 10s rolling pkg_loss_rate.
    void recordPacketObserved(uint16_t seq) {
        std::lock_guard<std::mutex> lk(stats_mu_);
        auto now = std::chrono::steady_clock::now();

        if (!last_seq_valid_) {
            last_seq_valid_    = true;
            last_observed_seq_ = seq;
            window_start_seq_  = seq;
            window_start_tp_   = now;
            return;
        }

        uint16_t diff = (uint16_t)(seq - last_observed_seq_);
        if (diff > 1) {
            // Pre-format and insert in ONE shot so the line stays intact when
            // other threads (SDK or host app) write stderr concurrently.
            char msg[96];
            std::snprintf(msg, sizeof(msg),
                          "[MDOP] packet loss: %u packets lost (SEQ %u -> %u)\n",
                          (unsigned)(diff - 1), (unsigned)last_observed_seq_,
                          (unsigned)seq);
            std::cerr << msg;
            lost_packets_in_window_ += (uint32_t)(diff - 1);
        }
        last_observed_seq_ = seq;

        if (now - window_start_tp_ >= stats_window_) {
            uint16_t total = (uint16_t)(seq - window_start_seq_);
            float rate = (total > 0)
                ? (float)lost_packets_in_window_ / (float)total * 100.0f
                : 0.0f;
            pkg_loss_rate_.store(rate);
            lost_packets_in_window_ = 0;
            window_start_seq_       = seq;
            window_start_tp_        = now;
        }
    }

    // Push handler called synchronously from rx_thread via RxRouter consumer.
    // MUST not block. Just memcpy into the bounded input queue.
    void onFrame(const DecodedFrame& df) {
        if (df.full_len > sizeof(RawFrame::bytes)) return;   // defensive
        RawFrame rf;
        rf.d_type = df.d_type;
        rf.len    = (uint16_t)df.full_len;
        std::memcpy(rf.bytes, df.full, df.full_len);
        input_queue_.pushMsg(rf);
    }

    // Owns the decode_thread loop. Pops RawFrame, dispatches by d_type.
    void decodeLoop() {
        while (running_.load()) {
            RawFrame rf;
            if (!input_queue_.tryPopMsg(rf, 50)) continue;   // timeout, recheck running_

            // Reconstruct DecodedFrame view from bytes
            DecodedFrame df;
            df.d_type   = rf.d_type;
            df.chk_st   = rf.bytes[4];
            df.up_ver   = rf.bytes[2];
            df.dw_ver   = rf.bytes[3];
            df.full     = rf.bytes;
            df.full_len = rf.len;

            // Status frames are not routed here: their SEQ@14 is an independent
            // counter from the PCD/origin_dist UDP sequence (protocol team,
            // 2026-07-22), so the packet-loss gap tracker observes point-cloud
            // packets only. See RxRouter dispatch for the rationale.
            if (df.d_type == DTYPE_PCD) {
                // Per-packet SEQ observation (spec 2026-05-18 §4.3): SEQ now
                // increments per packet, so the gap tracker samples here, not
                // at emit time. b1 PCD wire offset: UDP seq@81 (PCD_OFF_SEQ).
                uint16_t seq = (uint16_t)rf.bytes[PCD_OFF_SEQ]
                             | ((uint16_t)rf.bytes[PCD_OFF_SEQ + 1] << 8);
                recordPacketObserved(seq);
                int fid = -1;
                auto cloud = asm_.feed(df, fid);
                if (cloud) {
                    PointCloudCallbackFunc cb_local = nullptr;
                    void* user_local = nullptr;
                    {
                        std::lock_guard<std::mutex> lk(mu_);
                        queue_.emplace_back(cloud, fid);
                        if (queue_.size() > 10) queue_.pop_front();
                        if (cb_enabled_.load()) { cb_local = cb_; user_local = cb_user_; }
                    }
                    cv_.notify_one();
                    if (cb_local) cb_local(cloud, fid, user_local);
                }
            }
            else if (df.d_type == DTYPE_ORIGIN_DIST) {
                BwOriginDist od;
                OriginDistDecoder::decode(df, od);
                origin_dist_queue_.pushMsg(od);
                if (save_running_.load() && save_remaining_.load() > 0) {
                    SaveItem si;
                    si.data = od;
                    save_queue_.pushMsg(si);
                }

                // origin_dist → BwPointCloud (third sibling branch; uses raw df).
                // Per-packet SEQ observation. b1 wire offset: UDP seq@531
                // (OD_OFF_SEQ). origin_dist and PCD are mutually exclusive
                // modes and each carry the point-cloud UDP sequence; Status
                // has its own independent counter and is not tracked here.
                uint16_t od_seq = (uint16_t)rf.bytes[OD_OFF_SEQ]
                                | ((uint16_t)rf.bytes[OD_OFF_SEQ + 1] << 8);
                recordPacketObserved(od_seq);
                int od_fid = -1;
                auto od_cloud = od_asm_.feed(df, od_fid);
                if (od_cloud) {
                    PointCloudCallbackFunc cb_local = nullptr;
                    void* user_local = nullptr;
                    {
                        std::lock_guard<std::mutex> lk(mu_);
                        queue_.emplace_back(od_cloud, od_fid);
                        if (queue_.size() > 10) queue_.pop_front();
                        if (cb_enabled_.load()) { cb_local = cb_; user_local = cb_user_; }
                    }
                    cv_.notify_one();
                    if (cb_local) cb_local(od_cloud, od_fid, user_local);
                }
            }
        }
    }

    void saveLoop() {
        // Frame boundary: azimuth reset (curr_az < prev_az), mirroring
        // OriginDistFrameAssembler. Wire SEQ is per-packet (not per-frame)
        // since the 2026-05-18 refactor, so it can't drive file rotation.
        bool     started        = false;
        bool     discard        = true;          // discard partial first frame
        uint16_t prev_az        = 0;
        int      per_round_flag = 0;             // local; resets per saveOriginDistData call
        std::ofstream out;

        auto buildFileName = [this](int flag) -> std::string {
            char buf[512];
            if (save_name_.empty()) {
                time_t timep = time(NULL);
                struct tm tm_buf;
#if defined(_WIN32)
                localtime_s(&tm_buf, &timep);
                struct tm* nowTime = &tm_buf;
#else
                struct tm* nowTime = localtime_r(&timep, &tm_buf);
#endif
                char time_char[64];
                strftime(time_char, sizeof(time_char),
                         "%Y-%m-%d_%H-%M-%S", nowTime);
                int ms = (int)(std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::system_clock::now().time_since_epoch()).count() % 1000);
                if (save_suffix_.empty()) {
                    std::snprintf(buf, sizeof(buf), "%s/%s-%03d.txt",
                                  save_path_.c_str(), time_char, ms);
                } else {
                    std::snprintf(buf, sizeof(buf), "%s/%s-%03d_%s.txt",
                                  save_path_.c_str(), time_char, ms,
                                  save_suffix_.c_str());
                }
                (void)flag;   // unused in auto-name mode
            } else {
                std::snprintf(buf, sizeof(buf), "%s/%s_%d%s.txt",
                              save_path_.c_str(), save_name_.c_str(),
                              flag, save_suffix_.c_str());
            }
            std::string name(buf);
            std::string base = name;
            int dup_idx = 0;
            while (true) {
                std::ifstream f(name);
                if (!f.good()) break;
                ++dup_idx;
                size_t dot = base.rfind('.');
                if (dot != std::string::npos) {
                    name = base.substr(0, dot) + "_" + std::to_string(dup_idx)
                           + base.substr(dot);
                } else {
                    name = base + "_" + std::to_string(dup_idx);
                }
            }
            return name;
        };

        auto writePacket = [&out](const benewake::BwOriginDist& d) {
            for (int i = 0; i < 18; ++i) {
                out << (uint16_t)d.azimuth << " ";
                out << d.time_offset << " ";
                out << (uint16_t)d.channel[i] << " ";
                out << (uint16_t)d.scan_line[i] << " ";
                out << (uint16_t)d.spot_loc[i] << " ";
                out << (uint16_t)d.back_mean[i] << " ";
                out << (uint16_t)d.fram_err[i] << " ";
                out << (uint16_t)d.err_code[i] << " ";

                out << (uint16_t)d.echo_0[i].confidence << " ";
                out << d.echo_0[i].echo_cent << " ";
                out << d.echo_0[i].echo_win_sum << " ";
                out << d.echo_0[i].echo_win_max << " ";
                out << (uint16_t)d.echo_0[i].right_large_flag << " ";
                out << d.echo_0[i].echo_max_add_large << " ";
                out << d.echo_0[i].echo_max_add_neighbor << " ";

                out << (uint16_t)d.echo_1[i].confidence << " ";
                out << d.echo_1[i].echo_cent << " ";
                out << d.echo_1[i].echo_win_sum << " ";
                out << d.echo_1[i].echo_win_max << " ";
                out << (uint16_t)d.echo_1[i].right_large_flag << " ";
                out << d.echo_1[i].echo_max_add_large << " ";
                out << d.echo_1[i].echo_max_add_neighbor << " ";

                out << (uint16_t)d.echo_2[i].confidence << " ";
                out << d.echo_2[i].echo_cent << " ";
                out << d.echo_2[i].echo_win_sum << " ";
                out << d.echo_2[i].echo_win_max << " ";
                out << (uint16_t)d.echo_2[i].right_large_flag << " ";
                out << d.echo_2[i].echo_max_add_large << " ";
                out << d.echo_2[i].echo_max_add_neighbor << " ";
                out << std::endl;
            }
        };

        auto writeOriginDistHeader = [&out]() {
            out << "h_azimuth" << " ";
            out << "time_offset" << " ";
            out << "channel" << " ";
            out << "core_line" << " ";
            out << "core_cur_spot_loc" << " ";
            out << "core_back_mean" << " ";
            out << "core_fram_err" << " ";
            out << "core_err_code" << " ";
            for (int i = 0; i < 3; ++i) {
                out << "e" << i << "_match_grade" << " ";
                out << "e" << i << "_cent" << " ";
                out << "e" << i << "_win_sum" << " ";
                out << "e" << i << "_win_max" << " ";
                out << "e" << i << "_left_large_flag" << " ";
                out << "e" << i << "_max_add_large" << " ";
                out << "e" << i << "_max_add_neigh" << " ";
            }
            out << std::endl;
        };

        while (save_running_.load() && save_remaining_.load() > 0) {
            SaveItem si;
            if (!save_queue_.tryPopMsg(si, 50)) continue;

            const uint16_t curr_az = si.data.azimuth;

            if (!started) {
                prev_az = curr_az;
                started = true;
                continue;                               // anchor first packet; do not write
            }
            const bool boundary = (curr_az < prev_az);  // azimuth-reset frame boundary
            prev_az = curr_az;

            if (boundary) {
                if (discard) {
                    discard = false;                    // first boundary → start writing
                } else {
                    if (out.is_open()) out.close();     // close completed frame
                    if (save_remaining_.fetch_sub(1) - 1 == 0) break;
                }
                std::string fn = buildFileName(per_round_flag);
                ++per_round_flag;
                out.open(fn);
                if (!out.is_open()) {
                    std::cerr << "[MDOP] saveOriginDist: cannot open " << fn << std::endl;
                    save_running_.store(false);
                    return;
                }
                writeOriginDistHeader();
            }
            if (!discard) {
                writePacket(si.data);
            }
        }
        if (out.is_open()) out.close();
        save_running_.store(false);
    }

    void start() {
        if (running_.exchange(true)) return;
        decode_thread_ = std::thread([this]{ decodeLoop(); });
    }
    void stop() {
        if (!running_.exchange(false)) return;
        if (decode_thread_.joinable()) decode_thread_.join();
        save_running_.store(false);
        if (save_thread_.joinable()) save_thread_.join();
        input_queue_.clear();
        origin_dist_queue_.clear();
        save_queue_.clear();
        // reset packet-loss tracker so a fresh start() begins from a clean
        // state. Safe to mutate without stats_mu_ here because decode_thread_
        // has been joined above. window_start_tp_ is intentionally not
        // reset: the !last_seq_valid_ guard in recordPacketObserved
        // re-initialises it on the first packet after the next start(),
        // so a stale value is never read.
        last_seq_valid_         = false;
        last_observed_seq_      = 0;
        window_start_seq_       = 0;
        lost_packets_in_window_ = 0;
        pkg_loss_rate_.store(0.0f);
        // Reset both assemblers so frame_id restarts at 0 and in-flight
        // buffers don't leak across a stop/start cycle.
        asm_.reset();
        od_asm_.reset();
    }
};

MDOPProtocol::MDOPProtocol(RxRouter* router) : p_(std::make_unique<Impl>()) {
    p_->router = router;
    router->setMDOPConsumer([this](const DecodedFrame& df){ p_->onFrame(df); });
    p_->start();
}
MDOPProtocol::~MDOPProtocol() {
    p_->stop();
    if (p_->router) p_->router->setMDOPConsumer(nullptr);
}

bool MDOPProtocol::getData(BwPointCloud::Ptr& out, int& frame_id, int timeout_ms) {
    std::unique_lock<std::mutex> lk(p_->mu_);
    if (p_->queue_.empty()) {
        p_->cv_.wait_for(lk, std::chrono::milliseconds(timeout_ms),
                         [&]{ return !p_->queue_.empty(); });
    }
    if (p_->queue_.empty()) return false;
    auto front = p_->queue_.front();
    p_->queue_.pop_front();
    out = front.first;
    frame_id = front.second;
    return true;
}

void MDOPProtocol::registPointCloudCallback(PointCloudCallbackFunc cb, void* user) {
    std::lock_guard<std::mutex> lk(p_->mu_);
    p_->cb_       = cb;
    p_->cb_user_  = user;
    p_->cb_enabled_.store(cb != nullptr);
}
void MDOPProtocol::cancelPointCloudCallback() {
    std::lock_guard<std::mutex> lk(p_->mu_);
    p_->cb_enabled_.store(false);
    p_->cb_ = nullptr;
}

bool MDOPProtocol::getOriginDistData(BwOriginDist& out, int timeout_ms) {
    return p_->origin_dist_queue_.tryPopMsg(out, timeout_ms);
}

bool MDOPProtocol::saveOriginDistData(std::string path, std::string name,
                                       int times, std::string suffix) {
    if (times <= 0) return false;
    // If a save is already in progress, wait for it to finish (simple semantics).
    if (p_->save_thread_.joinable()) {
        p_->save_running_.store(false);
        p_->save_thread_.join();
    }
    // Drop any leftover SaveItems from the prior session — otherwise the new
    // saveLoop's first pop could anchor prev_az to a stale azimuth and
    // mis-classify the first real packet of this session as a frame
    // boundary, breaking the partial-first-frame discard guarantee.
    p_->save_queue_.clear();
    p_->save_path_   = std::move(path);
    p_->save_name_   = std::move(name);
    p_->save_suffix_ = std::move(suffix);
    p_->save_remaining_.store(times);
    p_->save_running_.store(true);
    p_->save_thread_ = std::thread([this]{ p_->saveLoop(); });
    return true;
}

void MDOPProtocol::setOriginDistDisplayOffsetMeters(float meters) {
    sr18::setOriginDistDisplayOffsetMeters(meters);
}

float MDOPProtocol::originDistDisplayOffsetMeters() const {
    return sr18::originDistDisplayOffsetMeters();
}

void MDOPProtocol::getDataTransmissionState(uint32_t& delay_us,
                                             float& pkg_loss_rate,
                                             float& frame_loss_rate) {
    // delay_us: not tracked (P7); pkg_loss_rate: real value from per-packet
    // SEQ-gap tracker; frame_loss_rate: stub at 0 — "true frame loss" via
    // azimuth coverage shortfall is future work (spec 2026-05-18 §2).
    delay_us        = 0;
    pkg_loss_rate   = p_->pkg_loss_rate_.load();
    frame_loss_rate = 0.0f;
}

void MDOPProtocol::setStatsWindowForTest(std::chrono::milliseconds w) {
    std::lock_guard<std::mutex> lk(p_->stats_mu_);
    p_->stats_window_ = w;
}
