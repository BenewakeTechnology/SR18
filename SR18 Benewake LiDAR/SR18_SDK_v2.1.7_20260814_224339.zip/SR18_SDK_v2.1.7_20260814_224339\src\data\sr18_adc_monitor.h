// src/data/sr18_adc_monitor.h
#pragma once
#include <atomic>
#include <cstdint>

namespace sr18 {

// Holds the most recent ADC sample for each of 8 channels. Single-writer
// (RxRouter rx_thread via pushSample) plus multi-reader (user threads via
// snapshot); per-slot std::atomic<uint16_t> with relaxed ordering is
// sufficient because each channel is independent and we only need the
// "latest value" semantic, not cross-slot consistency.
class AdcMonitor {
public:
    AdcMonitor() = default;
    ~AdcMonitor() = default;

    AdcMonitor(const AdcMonitor&) = delete;
    AdcMonitor& operator=(const AdcMonitor&) = delete;

    // Out-of-range ch (>=8) is silently dropped. Called from rx_thread.
    void pushSample(uint8_t ch, uint16_t val);

    // Fills out[0..7] with post-conversion values via kAdcConvert. Channels
    // not yet observed since construction yield 0. Lock-free.
    void snapshot(uint16_t out[8]) const;

private:
    std::atomic<uint16_t> cache_[8]{};   // value-initialised to 0
};

}  // namespace sr18
