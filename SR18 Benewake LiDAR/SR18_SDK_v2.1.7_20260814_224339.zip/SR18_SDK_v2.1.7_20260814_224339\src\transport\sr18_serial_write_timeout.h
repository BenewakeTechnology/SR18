// src/transport/sr18_serial_write_timeout.h
#pragma once
#include <cstdint>
#include <cstddef>

namespace sr18 {

// Compute the maximum time (ms) to wait for an overlapped serial write to
// drain, sized to the actual byte count and baud rate.
//
// On "returns only after the bytes are physically on the wire" serial drivers
// (observed on Windows for the 9600 bps command port), a fixed 1000 ms wait is
// too short for large chunks: a 1024 B LUT/boot chunk at 9600 bps needs
// 1024*10/9600 s ≈ 1067 ms just to clock out, so the write was being CancelIo'd
// mid-flight and reported as failure. Size the wait to the physical send time
// (10 bits/byte: 1 start + 8 data + 1 stop) plus generous margin, and never go
// below the historical 1000 ms floor so high-baud behaviour stays exactly as
// tight as before.
//
// Pure and platform-independent so it can be unit-tested on any host.
inline uint32_t computeWriteTimeoutMs(size_t n, uint32_t baud) {
    constexpr uint32_t kFloorMs = 1000;  // preserve legacy lower bound
    constexpr uint32_t kMarginMs = 500;  // fixed slack on top of the ×1.5 factor
    if (baud == 0) return kFloorMs;
    // Physical send time, rounded up: n bytes × 10 bits × 1000 ms / baud.
    uint64_t bits_ms = (uint64_t)n * 10u * 1000u;
    uint32_t physical_ms = (uint32_t)((bits_ms + baud - 1) / baud);
    // ×1.5 + fixed margin.
    uint32_t budget = physical_ms + physical_ms / 2u + kMarginMs;
    return budget < kFloorMs ? kFloorMs : budget;
}

}  // namespace sr18
