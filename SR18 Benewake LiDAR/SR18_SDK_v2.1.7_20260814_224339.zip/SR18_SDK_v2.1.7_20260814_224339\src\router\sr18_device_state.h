// src/router/sr18_device_state.h
#pragma once
#include <chrono>
#include <cstdint>

namespace sr18 {

// ────────────────────────────────────────────────────────────────────────
// IDeviceStateMonitor: synchronous wait API used by HalfDuplexExecutor.
// armForCompletion()/waitForCompletion() pair brackets one command's
// CHK_ST observation window. Default: EdgeDetectingMonitor.
// ────────────────────────────────────────────────────────────────────────
class IDeviceStateMonitor {
public:
    enum class Status { DONE, CRC_ERR, TIMEOUT };

    struct Result {
        Status   status;
        uint32_t rd_reg = 0;   // valid only when status==DONE && need_rd_reg=true
    };

    virtual ~IDeviceStateMonitor() = default;

    // Reset internal flags before sending a command. Must be called BEFORE
    // serial.write() to avoid attributing prior frame events to this cmd.
    virtual void armForCompletion() = 0;

    // Block until 0x04 (DONE) or 0x06 (CRC_ERR) edge observed, or deadline.
    //
    // Protocol (2026-05-04 clarification from protocol team): CHK_ST sits at
    // offset 4 of every upstream frame; ACK can in principle be carried on
    // any D_TYPE including IMU. ACK and RD_REG are independent telemetry
    // paths — ACK signals "command received" via CHK_ST, while RD_REG (only
    // present on PCD / Status / origin_dist) is sampled separately by
    // ChkStRdRegSampler. See spec §3.9.2 (2026-05-04 third clarification).
    //
    // need_rd_reg parameter: currently unused by EdgeDetectingMonitor.
    // Originally documented as "restrict ACK to PCD/Status when caller needs
    // RD_REG"; superseded by the decoupled sampler design. Kept on the
    // interface for ABI stability.
    virtual Result waitForCompletion(std::chrono::steady_clock::time_point deadline,
                                       bool need_rd_reg) = 0;
};

// ────────────────────────────────────────────────────────────────────────
// IChkStObserver: registered with RxRouter; gets every frame's CHK_ST
// byte plus pre-extracted RD_REG (RxRouter handles the byte offset
// difference between PCD@72 and Status@6; IMU passes 0).
// ────────────────────────────────────────────────────────────────────────
class IChkStObserver {
public:
    virtual ~IChkStObserver() = default;

    virtual void onChkSt(uint8_t chk_st, uint8_t d_type, uint32_t rd_reg) = 0;
};

}  // namespace sr18
