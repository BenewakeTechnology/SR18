// src/router/sr18_rd_reg_sampler.h
#pragma once
#include "sr18_device_state.h"      // for IChkStObserver
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <mutex>

namespace sr18 {

// Pure interface — DCSP depends on this, not the concrete class.
class IRdRegSampler {
public:
    virtual ~IRdRegSampler() = default;

    // Reset counters and start collecting. Must be called before each readRegister.
    virtual void arm(int target_n) = 0;

    // Block until either target_n samples collected or deadline reached.
    // Returns:
    //   - true + value_out=最新一个 RD_REG    if at least 1 sample collected
    //   - false                                if 0 samples collected before deadline
    virtual bool collect(uint32_t& value_out,
                         std::chrono::steady_clock::time_point deadline) = 0;
};

// Default implementation — observes RxRouter's CHK_ST stream.
// RxRouter calls onChkSt for every upstream frame except b1 PCD (whose byte 4
// is Reserved and which carries no RD_REG — the router excludes it at source),
// with rd_reg=0 for IMU (the protocol CSV defines no RD_REG field there). This
// class additionally filters to Status / origin_dist so IMU frames don't
// increment the sample count or overwrite last_value_ with 0.
class ChkStRdRegSampler : public IRdRegSampler, public IChkStObserver {
public:
    ChkStRdRegSampler() = default;

    void arm(int target_n) override;
    bool collect(uint32_t& value_out,
                 std::chrono::steady_clock::time_point deadline) override;

    // IChkStObserver
    void onChkSt(uint8_t chk_st, uint8_t d_type, uint32_t rd_reg) override;

private:
    std::mutex              mu_;
    std::condition_variable cv_;
    bool      armed_     = false;
    int       target_n_  = 0;
    int       collected_ = 0;
    uint32_t  last_value_ = 0;
};

}  // namespace sr18
