# SR18 SDK v2.1.7

This clean customer package was generated from Git ref `v2.1.7` at commit `3c8187e96643b1e10615efb06891377b6e0b1699`.
Package timestamp: `20260814_224339` (local time, `yyyyMMdd_HHmmss`).

## Contents

- `include/`: public SDK headers
- `src/`: complete source required to rebuild the SDK
- `bin/sr18_sdk.dll`: Windows x64 Release runtime library
- `lib/sr18_sdk.lib`: MSVC import library
- `samples/basic_demo`: start the lidar and receive five point-cloud frames
- `samples/register_probe`: read, write, and read back one register
- `samples/imu_recorder`: receive IMU data and save it as CSV
- `samples/raw_replay`: parse a raw recording offline and optionally export CSV

Unit tests, calibration code, performance diagnostics, internal PCD tools,
development documents, and build caches are intentionally excluded.

## Build the SDK from source on Windows

Requirements: Visual Studio 2022 C++ x64 tools and CMake 3.24 or newer.

```powershell
cmake -S . -B build --fresh -G "Visual Studio 17 2022" -A x64 -DSR18_BUILD_TESTS=OFF -DSR18_BUILD_SAMPLES=OFF -DSR18_CRC_ALIGN4=ON
cmake --build build --config Release --target sr18_sdk
```

## Build the samples separately

Run these commands from the package root. `SR18_SDK_ROOT` defaults to that root.

```powershell
cmake -S samples -B samples/build --fresh -G "Visual Studio 17 2022" -A x64
cmake --build samples/build --config Release
```

At run time, place `sr18_sdk.dll` next to each sample executable or add `bin`
to `PATH`.

## Build and install from source on Linux

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DSR18_BUILD_TESTS=OFF -DSR18_BUILD_SAMPLES=ON -DSR18_CRC_ALIGN4=ON
cmake --build build -j
sudo cmake --install build
sudo ldconfig
```

Release identity: `v2.1.7 / 3c8187e / 20260814_224339`.