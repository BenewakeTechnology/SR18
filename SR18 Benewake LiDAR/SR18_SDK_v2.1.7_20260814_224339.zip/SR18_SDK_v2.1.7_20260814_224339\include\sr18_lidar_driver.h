// include/sr18_lidar_driver.h
#pragma once
#include "sr18_api.h"
#include "sr18_common.h"
#include "sr18_dcsp.h"
#include "sr18_mdop.h"
#include "sr18_dsop.h"
#include "sr18_idop.h"
#include "sr18_geometry.h"
#include <string>
#include <memory>
#include <vector>
#include <cstdint>

namespace sr18 { class ISerial; }

namespace benewake {

// Result of the automatic device angle-file fetch performed on start().
//   NOT_STARTED      — fetch not yet run (receive-only, or start() not called)
//   SUCCESS          — angle file read + parsed + applied (source becomes DEVICE)
//   FALLBACK_DEFAULT — read failed after 3 retries; built-in default calibration
//                      kept (or user config, if set). Never blocks point output.
enum class AngleFetchStatus { NOT_STARTED = 0, SUCCESS = 1, FALLBACK_DEFAULT = 2 };

// Fired once when the automatic device angle fetch completes (success or
// fallback). Invoked from the thread calling start(); must not block.
using AngleFetchCallbackFunc = void(*)(AngleFetchStatus, AngleSource, void*);

// NOTE: the binary boot upgrade (TC 0x03/0x08) and its `enum class BootTarget`
// were removed 2026-07-28. Firmware upgrade is a single whole-machine OTA — see
// downloadFirmware() below — and has no per-board selection.

// Adaptation-LUT upload target (boot-format). UP_BOARD = TC 0x07 (default),
// DOWN_BOARD = TC 0x0A; the two paths are identical except the write command.
enum class LutTarget  { DOWN_BOARD, UP_BOARD };

class SR18_API SR18Lidar {
public:
    // ──────────────────────────────────────────────────────────────────
    // Constructors — three modes:
    //
    // 1. Receive-only (legacy single-port): RX 3.125 Mbps only. DCSP
    //    commands return false; data path works. Initial slot=SLOT_1
    //    (assumes device is already streaming).
    SR18Lidar(std::string port = "/dev/ttyUSB0", uint32_t baud = 3'125'000);

    // 2. Two-port (production): RX 3.125 Mbps + TX 9600 bps.
    //    Initial slot=SLOT_9 (idle).
    SR18Lidar(std::string rx_port,
              std::string tx_port,
              uint32_t    rx_baud = 3'125'000,
              uint32_t    tx_baud = 9600);

    // 3. Test injection: takes ownership of one or two ISerial pointers.
    //    tx_injected=nullptr → receive-only path.
    SR18Lidar(sr18::ISerial* rx_injected, sr18::ISerial* tx_injected = nullptr);

    ~SR18Lidar();

    // ---- Lifecycle ----
    bool start();
    bool stop();
    bool reboot();

    // Switch device mode via the ASCII protocol ($LDCMD CMD_ID 0x03). Returns
    // SR18_OK on a successful ($LDACK err==0) acknowledgement. Available only in
    // two-port mode (an executor is present); receive-only returns SR18_ERR_NOT_SUPPORTED.
    int switchMode(benewake::AsciiMode mode, int timeout_ms = 5000);

    // Read the software + firmware version carried by the telemetry TDM
    // fields. Waits until IDs 0x0F..0x0C and 0x13..0x10 have all appeared,
    // then writes their little-endian ASCII bytes in that order to `version`:
    // software 8B followed by firmware 8B. This is a telemetry read and works
    // in receive-only mode; it does not send the unverified ASCII read-version
    // command.
    int readVersion(std::string& version, int timeout_ms = 5000);

    // Read the angle file over the ASCII protocol ($LDCMD CMD_ID 0x02,
    // CMD_DATA 0x0007, special CHECK_ID 0x0A2CB395). On success (SR18_OK) copies
    // the raw 72-byte angle region (18 channels x 4 bytes) into out. Per-channel
    // decoding + inner-CRC verification are deferred; this hands back raw bytes.
    // out must point to at least 72 bytes. Two-port only; receive-only returns
    // SR18_ERR_NOT_SUPPORTED.
    int readAngleFile(uint8_t out[72], int timeout_ms = 5000);

    // ---- Channel angles (auto device fetch + user override) ----
    // start() automatically reads the device angle file ($LDCMD 0x02 0x07) once
    // per connection, parses it per §9.1, and applies it to the point-cloud
    // projection (source → DEVICE). On timeout/CRC error it retries up to 3
    // times, then falls back to the built-in default calibration WITHOUT
    // blocking point output. Two-port only; receive-only stays NOT_STARTED.
    //
    // Priority for the angles actually applied: user config > device > default.
    // User config is set via the process-global benewake::setChannelAnglesDegrees
    // (takes effect at runtime, no reconnect) and cleared via clearChannelAngles.

    // Query the currently-active per-channel angles (degrees) and their source.
    // Thin convenience over benewake::getChannelAnglesDegrees +
    // getChannelAngleSource (state is process-global).
    void getChannelAngles(float vertical_deg[18], float horizontal_deg[18],
                          benewake::AngleSource& source);

    // Status of this connection's automatic device angle fetch.
    AngleFetchStatus getAngleFetchStatus() const;

    // Register/cancel a one-shot callback fired when the auto device fetch
    // completes (success or fallback). Optional — poll getAngleFetchStatus()
    // instead if a callback is not wanted.
    void registAngleFetchCallback(AngleFetchCallbackFunc f, void* user);
    void cancelAngleFetchCallback();

    // ---- Data getters ----
    bool getData(BwPointCloud::Ptr& pointcloud, int& frame_id, int timeout = 2000);
    bool getData(BwPointCloud::Ptr& pointcloud, int& frame_id, SYS_INFO& info, int timeout = 2000);
    // Returns rolling-window transmission statistics maintained by MDOP.
    // delay_us is always 0 (host/lidar clock alignment deferred to P7).
    // pkg_loss_rate is a percentage updated every 10s from per-packet
    // SEQ-gap counts; reads return 0 until the first window completes.
    // frame_loss_rate is a stub at 0.0f — "true frame loss" via azimuth
    // coverage shortfall is future work (spec 2026-05-18 §2).
    void getDataTransmissionState(uint32_t& delay_us, float& pkg_loss_rate, float& frame_loss_rate);
    void setOriginDistDisplayOffsetMeters(float meters);
    float originDistDisplayOffsetMeters() const;

    // ---- Callbacks ----
    void registPointCloudCallback(PointCloudCallbackFunc f, void* user);
    void cancelPointCloudCallback();
    void registHeartBeatCallback(HeartBeatCallbackFunc f, void* user);
    void cancelHeartBeatCallback();
    void registIMUDataCallback(IMUDataCallbackFunc f, void* user);
    void cancelIMUDataCallback();
    std::deque<BW_IMU_INFO> getIMUData();

    // Register a callback for device fault-information frames (EE DD, ~1 Hz).
    // Delivered as a decoded BW_FAULT_INFO from the Rx thread. Every CRC-valid
    // fault frame is also logged to stderr (one line: code + name + state)
    // regardless of whether a callback is set. The SDK only reports faults —
    // it never performs the manual's remedial actions.
    // Both outputs are subject to enableFaultInfoParsing() below.
    void registFaultCallback(FaultCallbackFunc f, void* user);
    void cancelFaultCallback();

    // Runtime gate for fault-information reporting (EE DD frames).
    //
    // ENABLED BY DEFAULT — a caller that never touches this API sees exactly
    // the historical behaviour (stderr line + callback per real fault), so
    // SDK-only users do not silently lose fault output.
    //
    // enable == false: incoming fault frames are neither decoded into a
    // BW_FAULT_INFO, nor printed to stderr, nor forwarded to the callback
    // registered via registFaultCallback. enable == true restores all three.
    // Toggling is cheap (one atomic) and may be called at any time from any
    // thread, including before open / in receive-only mode.
    //
    // NOT PERSISTED: this is pure runtime state owned by the caller (the host
    // application drives it from its own fault-display switch). It is not
    // written to flash, not stored in a config file, and resets to "enabled"
    // on every new SR18Lidar instance.
    //
    // Note: the wire-level frame is still length-consumed and CRC-checked while
    // disabled — that is what keeps the shared UART byte stream in sync with
    // the binary telemetry path. Only the reporting (decode-to-struct, print,
    // callback) is suppressed.
    void enableFaultInfoParsing(bool enable);
    bool faultInfoParsingEnabled() const;

    // ---- Registers (UP board = primary) ----
    bool readRegister (int32_t* value, uint32_t address, int size);
    bool readRegister (uint32_t* value, uint32_t address, int size);
    bool writeRegister(int32_t* value, uint32_t address, int size);
    bool writeRegister(uint32_t* value, uint32_t address, int size);

    // Batch write to an arbitrary (possibly NON-CONTIGUOUS) address list on the
    // UP board. Writes `size` (addresses[i], values[i]) pairs in the given
    // order. This differs from writeRegister(value, address, size), which
    // writes `size` CONSECUTIVE addresses starting at `address`.
    //
    // Semantics (see dcsp_write_register): all addresses MUST fall in the same
    // register partition (0x0000-0x1FFF / 0x2000-0x2FFF / 0x3000-0x3FFF) — a
    // cross-partition or out-of-range list is rejected whole and returns false
    // (nothing is sent). The batch is auto-chunked by the current slot
    // (streaming = 8 regs/frame, idle = 150) with addr/value pairing and order
    // preserved. It is NOT atomic: on a mid-chunk failure, chunks already ACKed
    // stay applied and the call returns false. There is no inter-register
    // delay — callers needing DELAY timing between specific writes must segment
    // their calls accordingly. save-to-flash follows the current updateFlash()
    // mode, same as writeRegister.
    //
    // interPacketDelayMs: when the batch is split into multiple packets, wait
    // this many ms after each packet's ACK before sending the next one; the
    // LAST packet's ACK is NOT followed by any wait. Useful for <0x3000
    // pass-through registers (LS635/M5860) whose ACK only means "command
    // received" while the underlying chip write is still settling. Clamped to
    // [0, 10000]; default 0 keeps the back-to-back behaviour unchanged.
    bool writeRegisters(uint32_t* addresses, int32_t*  values, int size,
                        int interPacketDelayMs = 0);
    bool writeRegisters(uint32_t* addresses, uint32_t* values, int size,
                        int interPacketDelayMs = 0);

    // ---- Registers (DOWN board) ----
    bool readDownBoardRegister (int32_t* value, uint32_t address, int size);
    bool readDownBoardRegister (uint32_t* value, uint32_t address, int size);
    bool writeDownBoardRegister(int32_t* value, uint32_t address, int size);
    bool writeDownBoardRegister(uint32_t* value, uint32_t address, int size);

    // DOWN-board counterpart of writeRegisters(): batch write to an arbitrary
    // (possibly NON-CONTIGUOUS) address list on the DOWN board. Fully symmetric
    // with the UP-board writeRegisters — same "whole batch must share one
    // partition" guard (cross-partition / out-of-range rejected whole, nothing
    // sent), same slot auto-chunking (streaming = 8 regs/frame, idle = 150),
    // same NON-atomic behaviour (a mid-chunk failure leaves already-ACKed chunks
    // applied, no rollback) and same save-to-flash-follows-updateFlash() rule.
    // The only difference is the down-board transaction code (down=true).
    // interPacketDelayMs is honoured identically to the UP-board overloads.
    bool writeDownBoardRegisters(uint32_t* addresses, int32_t*  values, int size,
                                 int interPacketDelayMs = 0);
    bool writeDownBoardRegisters(uint32_t* addresses, uint32_t* values, int size,
                                 int interPacketDelayMs = 0);

    // ---- LUT ----
    // Register-style LUT retired 2026-07-07; superseded by the boot-unified
    // downloadLUT(file, LutTarget) added below (see spec 2026-07-07).
    // bool downloadLUT(uint8_t id, const uint8_t* data, uint16_t len);
    // bool downloadLUT(std::string file_path, bool check_sn = false);

    // Download an adaptation-LUT bin file (boot-format upload + bit[5:4] verify).
    // The bin is pre-formatted by the LUT tool; the SDK does not interpret the
    // content. UP_BOARD (TC=0x07) and DOWN_BOARD (TC=0x0A) are identical except
    // the LUT write command byte. Returns false on open failure, empty file, any
    // packet failure, or a verify state other than CHK_ST bit[5:4]==01 (PASSED).
    bool downloadLUT(std::string file_path, LutTarget target = LutTarget::UP_BOARD);

    // ---- Persist mode (bidirectional toggle, defaults true for Benewake compat) ----
    bool updateFlash(bool enable = true);
    bool getFlashMode() const;

    // ---- Timestamp ----
    bool setTimestamp(BwTimestamp ts);

    // ---- ADC values (8 channels, latest cached from Status frames;
    //      b1 PCD/origin_dist no longer carry an ADC field) ----
    bool getAdcValues(uint16_t out[8]);

    // ---- b1 telemetry tail (new-protocol fields shared by PCD and
    //      origin_dist frames, cached from the latest CRC-valid one; all
    //      return false before the first telemetry frame) ----
    // NOTE: 窗口脏污等级不在这里 —— 它随点云逐点传出，见
    // benewake::BwPoint::contamination (sr18_common.h)。原先的帧级 18ch 数组
    // getter 已于 2026-07-30 (PRO-84) 删除：帧级快照是"最近一帧"的跨帧值，
    // 无法保证和手上的点云同帧，而脏污与通道本就一一对应。
    // PCD Lidar State byte: 0x00 = normal, 0x01 = high temperature.
    bool getLidarState(uint8_t& state);
    // Motor speed in RPM (TDM ID 0x00). False until that TDM ID has cycled by.
    bool getMotorSpeedRpm(uint16_t& rpm);
    // Raw TDM data for any TDM ID (sw version 0x0F~0x0C, fw version 0x13~0x10;
    // each version group is ASCII little-endian 8B). For the combined public
    // version string, use readVersion().
    bool getTdmData(uint8_t tdm_id, uint16_t& data);

    // ---- Calibration data collection (see docs spec 2026-06-17) ----
    // Enter/exit calibration mode: writes 0x3038 = 1/0 (waits ACK) AND flips the
    // RxRouter calibration switch. While enabled, getAdcValues()/readRegister()
    // return meaningless values (those fields now carry calibration data).
    bool enableCalibration(bool enable);

    // Precondition gate (call BEFORE enableCalibration(true), while RD_REG still
    // carries register values): poll speed register 0x3037 over a window_s-second
    // sliding window; returns true once (max-min)/mean < tol, false on timeout.
    bool waitSpeedStable(int window_s, double tol, int timeout_ms);

    // Blocking collect: gather target_revs clean revolutions (or until timeout)
    // into out (samples[tooth] + per-tooth mean). Returns true iff target reached.
    bool collectCalibration(int target_revs, CalibrationResult& out, int timeout_ms);

    // ---- DeviceInformation (returns fixed strings; replace with reg query in P7) ----
    bool getDeviceInformation(std::string& version, std::string& fpga_version,
                               int& total_points_num, int& line_points_num,
                               int& channel_num, std::string& sn);

    // ---- Module accessors ----
    // WARNING: returned shared_ptr keeps the module alive, but the module
    // holds borrowed pointers to this SR18Lidar's serial+router. Caller MUST
    // NOT use the module after this SR18Lidar is destroyed. Following Benewake
    // SDK convention; treat module accessors as views, not owners.
    std::shared_ptr<DCSPProtocol> getDCSP();
    std::shared_ptr<MDOPProtocol> getMDOP();
    std::shared_ptr<DSOPProtocol> getDSOP();

    // ---- Stub APIs (kept for Benewake source compatibility; see notes) ----
    // Network/Multicast/DHCP/NTP/PTP — return false, no-op
    bool bindLocalAddress(std::string, uint32_t, uint32_t, uint32_t,
                           std::string, uint32_t, uint32_t, uint32_t);
    bool setConnection(std::string, uint32_t, int /*UDPType*/);
    bool getConnection(std::string&, uint32_t&, int& /*UDPType*/);
    bool setDeviceIPAndPort(std::string, uint32_t, uint32_t, std::string, std::string);
    bool setDestinationIPAndPort(std::string, uint32_t, uint32_t, uint32_t,
                                  std::string, std::string, std::string, uint16_t);
    bool setMulticastIPAndPort(std::string, uint32_t);
    bool getMulticastIPAndPort(std::string&, uint32_t&);
    bool setMulticastStatus(bool);  bool getMulticastStatus(bool&);
    bool setDHCPStatus(bool);       bool getDHCPStatus(bool&);
    bool setNTPParameters(std::string, uint32_t);
    bool getNTPInfo(uint8_t&, uint8_t&, std::string&, uint32_t&);
    bool setClockConfig(bool, uint8_t, bool, uint8_t);
    bool getClockConfig(bool&, uint8_t&, bool&, uint8_t&);
    bool getPTPInfo(uint8_t&, uint8_t&, int&, int&, int&, int&, int&);
    bool setNetworkTimeout(int);    bool getNetworkTimeout(int&);
    bool setDSOPDestIPAndPort(std::string, uint32_t);
    bool getDSOPDestIPAndPort(std::string&, uint32_t&);
    bool enablieStaticARP(bool);
    bool searchDevice(SYS_INFO&, int = 7000);

    // Modes / parameters
    bool setWorkMode(int); bool getWorkMode(int&, int = 2, int = 0);
    bool setROI(int,int,int,int);
    bool setROI(bool, const std::vector<float>&);
    bool getROI(int&,int&,int&,int&);
    bool setROIStatus(bool); bool getROIStatus(bool&);
    bool setFOVCenter(float,float); bool getFOVCenter(float&,float&);
    bool setFOVROILocation(float,float); bool setFOVROISize(float,float);
    bool setMultiEchoMode(int); bool getMultiEchoMode(int&);
    bool setCoordiateSystem(uint8_t); bool getCoordiateSystem(uint8_t&);
    bool setExtrinsicParameters(bool, const std::vector<float>&);
    bool getExtrinsicParameters(bool&, std::vector<float>&);
    bool setLocalTransform(bool, float, float, float, float, float, float);
    bool setPower(int); bool getPower(int&);
    bool enableABFrame(bool);
    bool enableTimeWindowMode(bool, uint32_t = 144);
    bool enableSunlightResistance(bool);
    bool enableAntiInterference(bool);
    bool enableWindowHeating(int,int,int,int,int,int,int,int,int,int);
    bool enableDataForwarding(bool, std::string, int);
    bool enableLog(bool, std::string = "log");
    /**
    * @brief Enable or disable raw RX byte-stream recording (host-side tap).
    *        Records EXACTLY the bytes the SDK reads from the RX UART, with no
    *        added headers/timestamps. Replay with benewake::ParseRaw.
    *        Data rate is ~275.2 KB/s on a live 3.2 kHz stream (~0.99 GB/h).
    * @param _enable: true to start recording, false to stop.
    * @param _path: file path for the raw dump (truncated on start).
    * @return True if success; otherwise, false.
    */
    bool enableRawRecord(bool _enable, std::string _path = "raw_record.dat");
    bool setRCMode(bool); bool getRCMode(bool&);
    bool setGaze(bool);   bool getGaze(bool&);
    bool setIMUConfig(bool); bool getIMUConfig(bool&);
    bool setSignalMessage(char*);
    bool setFrontViewFilter(bool, int, int, int, int, float, float);
    bool getFrontViewFilterParameters(bool&,int&,int&,int&,int&,float&,float&);
    bool restoreToDefault();
    bool getDSPVersion(std::string&, std::string&);
    bool setAutomobileInformation(int,int,int,int,int,int,int,int);
    bool setAutorunStatus(bool); bool getAutorunStatus(bool&);
    bool setOfflineLoggerParameters(int,int,int,bool,bool,bool);
    bool getOfflineLoggerParameters(int&,int&,int&,bool&,bool&,bool&);
    bool getOfflineLoggerInfo(int&);
    bool uploadOfflineLogger(std::string, int);
    bool shutdownWarning(int);
    bool startOnlyReceiver(std::string,int,uint8_t,uint16_t,bool,bool,int);
    bool switchProtocol(int);

    // Download firmware to the device. Blocking — takes several minutes and only
    // returns once the device has acknowledged the last packet.
    //
    // ONE whole-machine burn: the "请求升级大整包" handoff (CMD_ID 0x02 /
    // CMD_DATA 05 04) tells the device to flash the complete image, up-board and
    // down-board together. There is deliberately NO board-selection parameter.
    //
    // Internally this is the ASCII OTA path (renamed from downloadFirmwareOta
    // 2026-07-28 to restore the old boot-era call shape): issues the two handoff
    // commands (enter-upgrade, request-package) on the command port, stops
    // RxRouter, switches the RX RS485 line to 115200, runs the $LDOTA packet
    // protocol via OtaSession, then restores 3.125M + restarts RxRouter on every
    // exit path. Two-port mode only (returns false in receive-only).
    //
    // @param firmware_file  Firmware file name.
    // @return True on success; otherwise false.
    bool downloadFirmware(std::string firmware_file);
    bool setDeviceSN(const char*);
    bool clearConfig();
    BwPointCloud::Ptr timeWindowDataQueueFront();
    void timeWindowDataQueuePop();
    BwPointCloud::Ptr timeWindowDataQueuePopFront();
    int  timeWindowDataQueueSize();
    bool setTimestampFormat(int);
    bool getTimestampFormat(int&);

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};

}  // namespace benewake
