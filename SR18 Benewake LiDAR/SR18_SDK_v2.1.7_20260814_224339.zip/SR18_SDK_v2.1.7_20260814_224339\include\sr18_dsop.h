// include/sr18_dsop.h
#pragma once
#include "sr18_api.h"
#include "sr18_common.h"
#include <memory>

namespace sr18 { class RxRouter; }

namespace benewake {

class SR18_API DSOPProtocol {
public:
    explicit DSOPProtocol(sr18::RxRouter* router);
    ~DSOPProtocol();

    SYS_INFO dsop_get_system_information();
    SYS_INFO dsop_get_system_information_no_wait();

    void dsop_regist_heart_beat_callback(HeartBeatCallbackFunc cb, void* user);
    void dsop_cancel_heart_beat_callback();

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};

}  // namespace benewake
