#include "sr18_origin_dist_channel_map.h"
#include <cstring>

namespace {

constexpr uint8_t I = sr18::kInvalidOriginDistChannel;

const uint8_t kDefaultOriginDistChannelMap[4][16] = {
    {I, I, I, I, I, I, I, I, I, I, I, I, I, I, I, I},
    {I, I, I, I, I, I, I, I, I, I, I, I, I, I, I, I},
    {16, 17, I, I, I, I, I, I, I, I, I, I, I, I, I, I},
    {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
};

bool g_has_override = false;
uint8_t g_override[4][16] = {};

bool isValidMapValue(uint8_t value) {
    return value <= 17 || value == I;
}

void copyMap(uint8_t dst[4][16], const uint8_t src[4][16]) {
    std::memcpy(dst, src, sizeof(uint8_t) * 4 * 16);
}

}  // namespace

namespace benewake {

SR18_API bool setOriginDistChannelMap(const uint8_t channel_map[4][16]) {
    if (!channel_map) return false;
    for (int line = 0; line < 4; ++line) {
        for (int spot = 0; spot < 16; ++spot) {
            if (!isValidMapValue(channel_map[line][spot])) return false;
        }
    }
    copyMap(g_override, channel_map);
    g_has_override = true;
    return true;
}

SR18_API void getOriginDistChannelMap(uint8_t channel_map[4][16]) {
    if (!channel_map) return;
    copyMap(channel_map, g_has_override ? g_override : kDefaultOriginDistChannelMap);
}

SR18_API void clearOriginDistChannelMap() {
    g_has_override = false;
}

}  // namespace benewake