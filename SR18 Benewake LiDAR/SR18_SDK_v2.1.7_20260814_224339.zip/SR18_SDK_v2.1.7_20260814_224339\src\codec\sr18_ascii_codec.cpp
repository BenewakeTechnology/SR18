// src/codec/sr18_ascii_codec.cpp
#include "sr18_ascii_codec.h"
#include "sr18_crc.h"
#include <cstring>
#include <cstdio>
#include <iostream>

namespace sr18 {

namespace {
constexpr uint8_t kCmdHdr[7] = {0x24,0x4C,0x44,0x43,0x4D,0x44,0x2C}; // $LDCMD,
constexpr uint8_t kAckHdr[7] = {0x24,0x4C,0x44,0x41,0x43,0x4B,0x2C}; // $LDACK,
constexpr uint8_t kAngHdr[7] = {0x24,0x4C,0x44,0x41,0x4E,0x47,0x2C}; // $LDANG,
}  // namespace

void encode_ascii_cmd(uint8_t cmd_id, const uint8_t* cmd_data, size_t cmd_data_len,
                      uint32_t check_id, std::vector<uint8_t>& out) {
    out.clear();
    if (cmd_data_len > 254 || (!cmd_data && cmd_data_len)) return;  // Len is 1 byte
    out.reserve(19 + cmd_data_len);                        // = 18 + Len
    out.insert(out.end(), kCmdHdr, kCmdHdr + 7);
    out.push_back(static_cast<uint8_t>(1 + cmd_data_len)); // Len = CMD_ID + CMD_DATA
    const size_t body_start = 7;                           // CRC covers [Len..CHECK_ID]
    out.push_back(cmd_id);
    out.insert(out.end(), cmd_data, cmd_data + cmd_data_len);
    out.push_back(static_cast<uint8_t>(check_id        & 0xFF));
    out.push_back(static_cast<uint8_t>((check_id >>  8) & 0xFF));
    out.push_back(static_cast<uint8_t>((check_id >> 16) & 0xFF));
    out.push_back(static_cast<uint8_t>((check_id >> 24) & 0xFF));
    uint32_t crc = crc32_mpeg2_align4(out.data() + body_start,
                                      out.size() - body_start);
    out.push_back(static_cast<uint8_t>(crc        & 0xFF));
    out.push_back(static_cast<uint8_t>((crc >>  8) & 0xFF));
    out.push_back(static_cast<uint8_t>((crc >> 16) & 0xFF));
    out.push_back(static_cast<uint8_t>((crc >> 24) & 0xFF));
    out.push_back(0xEE);
    out.push_back(0xFF);
}

void encode_ascii_cmd(uint8_t cmd_id, uint16_t cmd_data, uint32_t check_id,
                      std::vector<uint8_t>& out) {
    const uint8_t data[2] = { static_cast<uint8_t>(cmd_data        & 0xFF),
                              static_cast<uint8_t>((cmd_data >> 8) & 0xFF) };
    encode_ascii_cmd(cmd_id, data, sizeof(data), check_id, out);
}

size_t ascii_ack_total_len(uint8_t len_field) {
    return 19u + len_field;   // 7 hdr + 1 Len + len_field + 1 err + 4 chk + 4 crc + 2 EE FF
}

bool parse_ascii_ack(const uint8_t* frame, size_t len, AsciiAck& out) {
    if (len < 22) return false;
    if (std::memcmp(frame, kAckHdr, 7) != 0) return false;
    uint8_t len_field = frame[7];
    if (len_field != 0x03) return false;                   // command-family only
    if (len != ascii_ack_total_len(len_field)) return false;
    if (frame[len - 2] != 0xEE || frame[len - 1] != 0xFF) return false;
    // CRC covers [Len..CHECK_ID] = frame[7 .. 7 + 1 + len_field + 1 + 4) = 6+len_field bytes
    size_t body_len = 6u + len_field;                      // = 9 for len_field 3
    uint32_t want = crc32_mpeg2_align4(frame + 7, body_len);
    size_t crc_off = 7 + body_len;                         // = 16
    uint32_t got =  (uint32_t)frame[crc_off]
                 | ((uint32_t)frame[crc_off + 1] <<  8)
                 | ((uint32_t)frame[crc_off + 2] << 16)
                 | ((uint32_t)frame[crc_off + 3] << 24);
    if (got != want) return false;
    out.cmd_id   = frame[8];
    out.cmd_data = (uint16_t)(frame[9] | (frame[10] << 8));
    out.err      = frame[11];
    out.check_id =  (uint32_t)frame[12]
                 | ((uint32_t)frame[13] <<  8)
                 | ((uint32_t)frame[14] << 16)
                 | ((uint32_t)frame[15] << 24);
    return true;
}

bool parse_ascii_angle_ack(const uint8_t* frame, size_t len, AsciiAngleFile& out) {
    // Fixed 99-byte frame (Len = 0x50).
    if (len != ascii_ack_total_len(kAsciiAngleLen)) return false;   // 99
    // Read-angle-file replies carry a dedicated header $LDANG, (NOT $LDACK,),
    // distinguishing PKT_CMD33 from ordinary command-family ACKs on the wire.
    if (std::memcmp(frame, kAngHdr, 7) != 0) return false;
    if (frame[7] != kAsciiAngleLen) return false;
    if (frame[len - 2] != 0xEE || frame[len - 1] != 0xFF) return false;
    // Outer CRC covers [Len..CHECK_ID] = frame[7 .. 7 + 6 + Len) = 6+Len bytes,
    // matching the normal-ACK rule (Len + err + CHECK_ID = 6, plus the Len-region).
    size_t body_len = 6u + kAsciiAngleLen;   // = 86 -> [7..92]
    uint32_t want = crc32_mpeg2_align4(frame + 7, body_len);
    size_t crc_off = 7 + body_len;           // = 93
    uint32_t got =  (uint32_t)frame[crc_off]
                 | ((uint32_t)frame[crc_off + 1] <<  8)
                 | ((uint32_t)frame[crc_off + 2] << 16)
                 | ((uint32_t)frame[crc_off + 3] << 24);
    if (got != want) return false;
    // CMD_ID / CMD_DATA are expected to echo the read-angle-file command
    // (0x02 / 0x0007). A mismatch is WARNED ONLY, never fatal: the frame has
    // already passed header/Len/outer-CRC/terminator, so we still surface the
    // angle bytes. (Warn-only per user directive; hard-failing here would drop
    // an otherwise-valid frame if the FPGA echoes these fields differently.)
    uint8_t  cmd_id   = frame[8];
    uint16_t cmd_data = (uint16_t)(frame[9] | (frame[10] << 8));
    if (cmd_id != 0x02 || cmd_data != 0x0007) {
        char msg[112];
        std::snprintf(msg, sizeof(msg),
                      "[AngleAck] WARN: unexpected CMD_ID/CMD_DATA "
                      "0x%02X/0x%04X (expected 0x02/0x0007)\n",
                      cmd_id, cmd_data);
        std::cerr << msg;
    }
    // Raw extraction: angle region [12..83], inner CRC [84..87], err [88],
    // echoed CHECK_ID [89..92].
    std::memcpy(out.angle_raw, frame + 12, 72);
    out.inner_crc =  (uint32_t)frame[84]
                  | ((uint32_t)frame[85] <<  8)
                  | ((uint32_t)frame[86] << 16)
                  | ((uint32_t)frame[87] << 24);
    // Inner CRC over the 72-byte angle region [12..83], same rule as every
    // other frame CRC: CRC-32/MPEG-2, align4 (72 is already 4-aligned so no
    // padding), little-endian on wire. Mismatch rejects the frame.
    uint32_t inner_want = crc32_mpeg2_align4(frame + 12, 72);
    if (out.inner_crc != inner_want) return false;
    out.err      = frame[88];
    out.check_id =  (uint32_t)frame[89]
                 | ((uint32_t)frame[90] <<  8)
                 | ((uint32_t)frame[91] << 16)
                 | ((uint32_t)frame[92] << 24);
    return true;
}

}  // namespace sr18
