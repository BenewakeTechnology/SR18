// src/codec/sr18_decoder.h
#pragma once
#include "../../include/sr18_protocol.h"
#include <chrono>
#include <cstdint>
#include <cstddef>
#include <functional>
#include <vector>
#include "sr18_ascii_codec.h"
#include "sr18_fault_codec.h"

namespace sr18 {

// Parsed upstream frame view (lifetime: until next feed call returns)
struct DecodedFrame {
    uint8_t  d_type;
    uint8_t  chk_st;
    uint8_t  up_ver;
    uint8_t  dw_ver;
    const uint8_t* full;     // Full frame bytes including CRC, length = full_len
    size_t   full_len;
    // Offset of this frame's first byte (STX0 0xEE) in the cumulative byte
    // stream fed to this decoder. Live consumers ignore it; ParseRaw uses it
    // to build the frame-offset index of a recording file.
    uint64_t stream_offset = 0;
};

class UpstreamDecoder {
public:
    using FrameCallback = std::function<void(const DecodedFrame&)>;

    explicit UpstreamDecoder(FrameCallback on_frame);

    // Reset in-progress frame state (state, buf, need). Safe to call before
    // start() / after stop() to ensure the decoder begins frame-synced. Does
    // NOT reset the cumulative stats counters (frames_emitted_, frames_dropped_,
    // total_fed_) — only the in-progress frame state is cleared.
    void reset();

    // Feed bytes; on_frame_ is invoked once per CRC-valid complete frame.
    // Bad CRC / unknown D_TYPE both bump frames_dropped_ and re-sync 1 byte
    // forward. CRC failures additionally emit a throttled stderr log
    // ("[Decoder] CRC error: N frames dropped") at most once per second so
    // burst noise (e.g. spurious 0xEE 0xFF byte sequences) doesn't flood
    // stderr; unknown D_TYPE remains silent (almost always false-STX hits).
    void feed(const uint8_t* data, size_t n);

    // Register a callback for CRC-valid $LDACK command-family frames. Invoked
    // on the same thread as feed(). The binary on_frame_ path is unaffected.
    using AsciiAckCallback = std::function<void(const AsciiAck&)>;
    void setAsciiAckCallback(AsciiAckCallback cb) { on_ascii_ack_ = std::move(cb); }

    // Register a callback for CRC-valid read-angle-file ACKs (Len 0x50, 99B).
    // Same threading contract as setAsciiAckCallback; hands back raw bytes.
    using AsciiAngleCallback = std::function<void(const AsciiAngleFile&)>;
    void setAsciiAngleCallback(AsciiAngleCallback cb) { on_ascii_angle_ = std::move(cb); }

    // Register a callback for CRC-valid EE DD fault frames (41B). Same threading
    // contract as the other callbacks; the binary telemetry path is unaffected.
    using FaultCallback = std::function<void(const FaultFrame&)>;
    void setFaultCallback(FaultCallback cb) { on_fault_ = std::move(cb); }

    // Stats (read by tests)
    size_t framesEmitted() const { return frames_emitted_; }
    size_t framesDropped() const { return frames_dropped_; }

private:
    // GOT_STX0: matched the first STX byte. The protocol stores STX = 0xFFEE
    // little-endian on wire, so STX byte 0 = 0xEE and we then expect 0xFF.
    enum class State { IDLE, GOT_STX0, HEADER, BODY, ASCII_HDR, ASCII_BODY, FAULT_BODY };
    State    state_ = State::IDLE;
    std::vector<uint8_t> buf_;     // Current frame in-progress
    size_t   need_ = 0;            // Bytes still needed for current state
    FrameCallback on_frame_;
    AsciiAckCallback on_ascii_ack_;
    AsciiAngleCallback on_ascii_angle_;
    FaultCallback on_fault_;
    size_t   frames_emitted_ = 0;
    size_t   frames_dropped_ = 0;

    // CRC-failure log throttle. crc_drops_since_log_ accumulates between
    // log emissions; crc_last_log_tp_ is default-init (epoch) so the very
    // first CRC failure logs immediately.
    size_t                                crc_drops_since_log_ = 0;
    std::chrono::steady_clock::time_point crc_last_log_tp_{};

    uint64_t total_fed_        = 0;  // Bytes accepted via public feed()
    uint64_t buf_start_offset_ = 0;  // Stream offset of buf_[0]

    void resyncDropFirstByte();    // Drop buf_[0], re-scan from buf_[1]

    // Internal worker: like feed(), but `base` is the absolute stream offset
    // of data[0]. resyncDropFirstByte() re-feeds stashed bytes through this
    // with their original offsets, so they are not double-counted.
    void feedSpan(const uint8_t* data, size_t n, uint64_t base);
};

}  // namespace sr18
