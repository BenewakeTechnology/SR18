#pragma once
#include "../../include/sr18_common.h"
#include <cstdint>

namespace sr18 {

static constexpr uint8_t kInvalidOriginDistChannel = 0xFF;

inline uint8_t originDistChannelFromScanSpot(uint8_t scan_line, uint8_t spot_loc) {
    if (scan_line >= 4 || spot_loc >= 16) {
        return kInvalidOriginDistChannel;
    }

    uint8_t map[4][16] = {};
    benewake::getOriginDistChannelMap(map);
    return map[scan_line][spot_loc];
}

}  // namespace sr18
