// src/data/sr18_adc_monitor.cpp
#include "sr18_adc_monitor.h"
#include "sr18_adc_convert.h"

namespace sr18 {

void AdcMonitor::pushSample(uint8_t ch, uint16_t val) {
    if (ch >= 8) return;
    cache_[ch].store(val, std::memory_order_relaxed);
}

void AdcMonitor::snapshot(uint16_t out[8]) const {
    for (int i = 0; i < 8; ++i) {
        uint16_t raw = cache_[i].load(std::memory_order_relaxed);
        out[i] = kAdcConvert[i](raw);
    }
}

}  // namespace sr18
