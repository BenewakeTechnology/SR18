// src/data/sr18_calibration_collector.h
#pragma once
#include "../../include/sr18_common.h"   // CalibrationResult
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <mutex>
#include <vector>

namespace sr18 {

enum class CalibrationWordSource {
    RdReg,
    AdcValue,
};

// Accumulates per-tooth encoder timing during calibration mode. Fed two raw
// 32-bit words per frame by RxRouter (RD_REG slot + ADC_VALUE slot) ONLY while
// calibration is active. Decodes valid/tooth/count; bit[31]=0 words are
// dropped at insertion (matrix holds real data only). Revolution boundary =
// tooth number wrap (curr_tooth < prev_tooth). The leading partial revolution
// is discarded — counting starts at the first clean wrap. Within a revolution,
// each tooth is recorded at most once (dedup defeats the device's repeat-reports).
class CalibrationCollector {
public:
    static constexpr int kMaxTeeth = 64;   // reserved param space upper bound

    CalibrationCollector() = default;
    CalibrationCollector(const CalibrationCollector&) = delete;
    CalibrationCollector& operator=(const CalibrationCollector&) = delete;

    // Reset state and begin collecting target_revs clean revolutions.
    // Precondition: target_revs >= 1. Values <= 0 collect nothing and make
    // collect() return false.
    void arm(int target_revs);

    // Feed one raw 32-bit calibration word. Called from rx_thread. No-op when
    // not armed. Drops bit[31]=0 and out-of-range teeth.
    void feedWord(uint32_t word,
                  CalibrationWordSource source = CalibrationWordSource::RdReg);

    // Block until target_revs clean revolutions complete or deadline. Fills out
    // (samples + per-tooth mean) with whatever was collected. Returns true iff
    // the target was reached.
    bool collect(benewake::CalibrationResult& out,
                 std::chrono::steady_clock::time_point deadline);

private:
    struct SourceState {
        int  rev_count  = 0;     // clean revolutions completed
        bool started    = false; // first clean wrap seen?
        int  prev_tooth = -1;
        int  max_tooth  = -1;
        std::vector<char>                  seen_this_rev;  // [tooth]
        std::vector<std::vector<uint32_t>> samples;        // [tooth] -> values
    };

    void resetSource(SourceState& s);
    bool feedSource(SourceState& s, uint32_t word);
    static void fillResult(const SourceState& s, benewake::CalibrationTableResult& out);

    std::mutex              mu_;
    std::condition_variable cv_;
    bool armed_       = false;
    int  target_revs_ = 0;
    SourceState rd_reg_;
    SourceState adc_value_;
};

}  // namespace sr18
