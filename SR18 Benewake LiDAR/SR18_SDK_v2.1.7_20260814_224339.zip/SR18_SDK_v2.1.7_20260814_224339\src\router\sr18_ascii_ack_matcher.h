// src/router/sr18_ascii_ack_matcher.h
#pragma once
#include "../codec/sr18_ascii_codec.h"
#include <chrono>
#include <condition_variable>
#include <mutex>

namespace sr18 {

// ASCII analogue of EdgeDetectingMonitor. Matches a $LDACK frame to the
// in-flight $LDCMD by echoed (CMD_ID, CHECK_ID). arm() before write, wait()
// blocks until a matching ack or the deadline. onAsciiAck() is fed from the
// rx thread (via RxRouter). A nonce drops late/stale acks after timeout.
class AsciiAckMatcher {
public:
    enum class Status { OK, TIMEOUT };
    struct Result { Status status = Status::TIMEOUT; uint8_t err = 0; uint16_t cmd_data = 0; };

    void   arm(uint8_t expect_cmd_id, uint32_t expect_check_id);
    Result wait(std::chrono::steady_clock::time_point deadline);
    void   onAsciiAck(const AsciiAck& ack);

private:
    std::mutex              mu_;
    std::condition_variable cv_;
    bool     armed_          = false;
    bool     hit_            = false;
    uint8_t  expect_cmd_id_  = 0;
    uint32_t expect_check_id_= 0;
    uint8_t  err_            = 0;
    uint16_t cmd_data_       = 0;
};

// Analogue of AsciiAckMatcher for the read-angle-file ACK, which carries a
// 72-byte payload that will not fit AsciiAckMatcher's 2-byte cmd_data. Matches
// on the echoed CHECK_ID (the angle command's CHECK_ID is a fixed sentinel).
class AsciiAngleMatcher {
public:
    enum class Status { OK, TIMEOUT };
    struct Result { Status status = Status::TIMEOUT; AsciiAngleFile file; };

    void   arm(uint32_t expect_check_id);
    Result wait(std::chrono::steady_clock::time_point deadline);
    void   onAsciiAngle(const AsciiAngleFile& file);
    // Wake any in-flight wait() early (returns TIMEOUT). Used on shutdown so a
    // background angle fetch does not make teardown block on the full deadline.
    void   abort();

private:
    std::mutex              mu_;
    std::condition_variable cv_;
    bool     armed_          = false;
    bool     hit_            = false;
    bool     aborted_        = false;
    uint32_t expect_check_id_= 0;
    AsciiAngleFile file_;
};

}  // namespace sr18
