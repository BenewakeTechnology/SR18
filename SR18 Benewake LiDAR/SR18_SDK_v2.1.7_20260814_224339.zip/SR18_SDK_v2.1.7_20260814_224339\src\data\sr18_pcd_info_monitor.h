// src/data/sr18_pcd_info_monitor.h
// b1 new-protocol telemetry-tail cache: lidar state + the TDM
// (time-division-multiplexed) data table.
// PCD (球坐标) tail = contamination(5) + lidar_state(1) + TDM(3); origin_dist
// (解距) tail = lidar_state(1) + TDM(3) — no contamination. Callers pass a
// pointer straight at the Lidar State byte, so the two layouts collapse to one
// entry point here (offsets live in sr18_protocol.h).
//
// Contamination is deliberately NOT cached here: it is delivered per point on
// BwPoint::contamination, decoded by FrameAssembler from the same frame the
// point came from (PRO-84, 2026-07-30). A cross-frame "latest levels" cache
// could not guarantee same-frame correspondence, so it was removed along with
// the frame-level getter.
//
// Same concurrency model as AdcMonitor: single writer (RxRouter rx_thread via
// pushTail), multi-reader (user threads via the get* accessors). Per-slot
// std::atomic with relaxed ordering — each slot only needs "latest value"
// semantics, no cross-slot consistency.
//
// TDM version-string assembly (sw 0x0F~0x0C / fw 0x13~0x10, ASCII little-endian
// 8B per group) is kept in the SR18Lidar facade. Hosts can still read individual
// raw per-ID words via getTdmData().
#pragma once
#include <atomic>
#include <cstddef>
#include <cstdint>

namespace sr18 {

class PcdInfoMonitor {
public:
    PcdInfoMonitor() = default;
    ~PcdInfoMonitor() = default;

    PcdInfoMonitor(const PcdInfoMonitor&) = delete;
    PcdInfoMonitor& operator=(const PcdInfoMonitor&) = delete;

    // Update the cache from a b1 telemetry tail. `state_tdm` points at the
    // Lidar State byte, followed by TDM id(1) + TDM data(2, LE).
    // Callers: PCD → pushTail(frame+PCD_OFF_LIDAR_STATE);
    // origin_dist → pushTail(frame+OD_OFF_LIDAR_STATE). Those two offsets are
    // where each layout's tail lands AFTER its (present or absent)
    // contamination region — that arithmetic stays in sr18_protocol.h and is
    // unaffected by contamination no longer being cached. Called from
    // rx_thread. A null pointer is ignored (defensive).
    void pushTail(const uint8_t* state_tdm);

    // getLidarState / getTdmData return false until the first telemetry frame
    // (PCD or origin_dist) has been observed. getTdmData also requires that
    // specific ID to have appeared.

    // Lidar State byte: 0x00 = normal, 0x01 = high temperature.
    bool getLidarState(uint8_t& state) const;

    // Latest TDM data word for a given TDM ID (e.g. TDM_ID_MOTOR_RPM).
    bool getTdmData(uint8_t tdm_id, uint16_t& data) const;

private:
    std::atomic<uint8_t>  lidar_state_{0};
    std::atomic<bool>     have_frame_{false};   // any telemetry frame seen
    // TDM table: bit16 = seen, low 16 bits = latest data. Full 256-ID space —
    // the manual only names a few IDs but leaves the space open (Q17).
    std::atomic<uint32_t> tdm_[256]{};
};

}  // namespace sr18
