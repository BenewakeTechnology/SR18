// src/codec/sr18_crc.cpp
#include "sr18_crc.h"

namespace sr18 {

// Non-reflected CRC-16/IBM (poly=0x8005, init=0x0000, refin=false, refout=false, xorout=0)
uint16_t crc16_ibm(const uint8_t* data, size_t len) {
    uint16_t crc = 0x0000;
    for (size_t i = 0; i < len; ++i) {
        crc ^= static_cast<uint16_t>(data[i]) << 8;
        for (int b = 0; b < 8; ++b) {
            if (crc & 0x8000) crc = (crc << 1) ^ 0x8005;
            else              crc <<= 1;
        }
    }
    return crc;
}

uint32_t crc32_mpeg2(const uint8_t* data, size_t len) {
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < len; ++i) {
        crc ^= static_cast<uint32_t>(data[i]) << 24;
        for (int b = 0; b < 8; ++b) {
            if (crc & 0x80000000u) crc = (crc << 1) ^ 0x04C11DB7u;
            else                   crc <<= 1;
        }
    }
    return crc;
}

uint32_t crc32_mpeg2_align4(const uint8_t* data, size_t len) {
    // Zero-pad up to the next 4-byte boundary; the padding bytes feed the same
    // polynomial division as a literal 0x00 byte would, so we just run extra
    // rounds with byte=0 instead of allocating a padded copy.
    const size_t pad   = (4 - (len & 3)) & 3;
    const size_t total = len + pad;
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < total; ++i) {
        const uint8_t byte = (i < len) ? data[i] : 0;
        crc ^= static_cast<uint32_t>(byte) << 24;
        for (int b = 0; b < 8; ++b) {
            if (crc & 0x80000000u) crc = (crc << 1) ^ 0x04C11DB7u;
            else                   crc <<= 1;
        }
    }
    return crc;
}

uint32_t crc32_wire(const uint8_t* data, size_t len) {
#if SR18_CRC_ALIGN4
    return crc32_mpeg2_align4(data, len);   // unified align4 rule (post-firmware)
#else
    return crc32_mpeg2(data, len);          // raw body, no pad (current hardware)
#endif
}

}  // namespace sr18
