// src/codec/sr18_encoder.cpp
#include "sr18_encoder.h"
#include "sr18_crc.h"

namespace sr18 {

void encode_downstream(TC tc, uint8_t seq,
                       const uint8_t* payload, size_t payload_len,
                       std::vector<uint8_t>& out) {
    out.clear();
    out.reserve(10 + payload_len);
    // STX 0xA5B6 little-endian on wire (B6 first, A5 second).
    // The protocol spells STX as the literal value 0xA5B6 but, like every
    // other multi-byte field on the SR18 wire, it is serialised LSB-first.
    out.push_back(0xB6);
    out.push_back(0xA5);
    out.push_back(static_cast<uint8_t>(tc));
    out.push_back(seq);
    // LEN little-endian on wire
    out.push_back(static_cast<uint8_t>(payload_len & 0xFF));
    out.push_back(static_cast<uint8_t>((payload_len >> 8) & 0xFF));
    if (payload && payload_len) {
        out.insert(out.end(), payload, payload + payload_len);
    }
    // CRC-32/MPEG-2 over [STX..payload], LE on wire. The padding rule follows
    // the SR18_CRC_ALIGN4 build switch (crc32_wire): align4 when on (pad bytes
    // not transmitted), raw body when off — see sr18_crc.h.
    uint32_t crc = crc32_wire(out.data(), out.size());
    out.push_back(static_cast<uint8_t>(crc        & 0xFF));
    out.push_back(static_cast<uint8_t>((crc >>  8) & 0xFF));
    out.push_back(static_cast<uint8_t>((crc >> 16) & 0xFF));
    out.push_back(static_cast<uint8_t>((crc >> 24) & 0xFF));
}

}  // namespace sr18
