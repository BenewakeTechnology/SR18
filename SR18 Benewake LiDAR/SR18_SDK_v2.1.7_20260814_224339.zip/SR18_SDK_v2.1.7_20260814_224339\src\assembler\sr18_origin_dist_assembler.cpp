// src/assembler/sr18_origin_dist_assembler.cpp
#include "sr18_origin_dist_assembler.h"
#include "../../include/sr18_protocol.h"
#include "../data/sr18_origin_dist_channel_map.h"
#include "../data/sr18_timestamp.h"

namespace sr18 {

namespace {
constexpr float kOriginDistMetersPerCent = 0.15f / 64.0f;
float kOriginDistDisplayOffsetM = 5.5f;
}

void setOriginDistDisplayOffsetMeters(float meters) {
    if (meters < 0.0f) meters = 0.0f;
    kOriginDistDisplayOffsetM = meters;
}

float originDistDisplayOffsetMeters() {
    return kOriginDistDisplayOffsetM;
}

void OriginDistFrameAssembler::appendPoints(const DecodedFrame& od) {
    // Apply any runtime angle change (user config / device fetch) before use.
    benewake::refreshChannelGeometry(geom_, geom_gen_);
    const uint8_t* f = od.full;

    // Header (mirrors OriginDistDecoder). b1 new protocol: azimuth is
    // 0.01 deg/LSB, same as the PCD path (2026-07-20 origin_dist directive).
    uint32_t ts_us = (uint32_t)f[12] | ((uint32_t)f[13] <<  8)
                   | ((uint32_t)f[14] << 16) | ((uint32_t)f[15] << 24);
    uint16_t azimuth = (uint16_t)f[16] | ((uint16_t)f[17] << 8);
    const float az_rad = benewake::pcdAzimuthToRadians(azimuth);
    const NormalizedTimestamp ts = normalizeWireTimestamp(f + 6, ts_us);

    if (buf_->points.empty()) {
        buf_->time_s  = (uint32_t)ts.time_s;
        buf_->time_ns = ts.time_ns;
    }

    for (int ch = 0; ch < 18; ++ch) {
        const uint8_t* p = f + 18 + ch * 28;
        uint8_t scan_line = (uint8_t)(p[0] & 0x03);
        uint8_t spot_loc = (uint8_t)((p[0] >> 2) & 0x0F);
        uint8_t sdk_channel = originDistChannelFromScanSpot(scan_line, spot_loc);
        if (sdk_channel == kInvalidOriginDistChannel) continue;

        uint8_t fram_err = (p[2] & 0x01);
        if (fram_err) continue;                       // filter ① — whole channel

        // Iterate three echo slots: echo_0/1/2 at offsets 4/12/20.
        for (int slot = 0; slot < 3; ++slot) {
            const uint8_t* pe = p + 4 + slot * 8;
            uint64_t u = 0;
            for (int i = 0; i < 8; ++i) u |= ((uint64_t)pe[i]) << (8 * i);
            uint32_t cent = (uint32_t)((u >> 4) & 0x3FFFF);
            if (cent == 0) continue;                  // filter ② — empty slot

            float dist_m = (float)cent * kOriginDistMetersPerCent
                         - kOriginDistDisplayOffsetM;
            if (dist_m < 0.0f) dist_m = 0.0f;

            benewake::BwPoint pt;
            pt.distance     = (uint16_t)(dist_m * 100.0f);
            pt.intensity    = 255;
            pt.channel      = sdk_channel;
            pt.azimuth      = azimuth;
            pt.timestamp_s  = ts.time_s;
            pt.timestamp_ns = ts.time_ns;
            pt.echo         = (uint8_t)(1u << slot);   // 0x01 / 0x02 / 0x04
            // 解距 frame body carries no 脏污 field (see sr18_protocol.h
            // OD_OFF_* — the tail goes straight from block to lidar_state), so
            // flag it unavailable rather than reporting a fake level 0 ("优").
            pt.contamination = benewake::kContaminationUnavailable;
            benewake::pointToCartesianFromMetersRad(pt, geom_, dist_m, az_rad);
            buf_->points.push_back(pt);
        }
    }
}

benewake::BwPointCloud::Ptr OriginDistFrameAssembler::feed(
        const DecodedFrame& od, int& out_frame_id) {
    uint16_t curr_az = (uint16_t)od.full[16] | ((uint16_t)od.full[17] << 8);
    if (started_ && curr_az < prev_az_) {
        auto done = buf_;
        out_frame_id = (int)frame_idx_++;
        buf_ = std::make_shared<benewake::BwPointCloud>();
        prev_az_ = curr_az;
        appendPoints(od);                  // belongs to the NEW frame
        return done;
    }
    prev_az_ = curr_az;
    started_ = true;
    appendPoints(od);
    return nullptr;
}

benewake::BwPointCloud::Ptr OriginDistFrameAssembler::flush() {
    if (buf_->points.empty()) return nullptr;
    auto done = buf_;
    buf_ = std::make_shared<benewake::BwPointCloud>();
    prev_az_ = 0;
    started_ = false;
    ++frame_idx_;
    return done;
}

void OriginDistFrameAssembler::reset() {
    buf_       = std::make_shared<benewake::BwPointCloud>();
    prev_az_   = 0;
    started_   = false;
    frame_idx_ = 0;
}

}  // namespace sr18
