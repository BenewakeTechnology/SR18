// include/sr18_mdop.h
#pragma once
#include "sr18_api.h"
#include "sr18_common.h"
#include <memory>
#include <string>
#include <chrono>

namespace sr18 { class RxRouter; class FrameAssembler; }

namespace benewake {

class SR18_API MDOPProtocol {
public:
    explicit MDOPProtocol(sr18::RxRouter* router);
    ~MDOPProtocol();

    bool getData(BwPointCloud::Ptr& out, int& frame_id, int timeout_ms = 2000);
    void registPointCloudCallback(PointCloudCallbackFunc cb, void* user);
    void cancelPointCloudCallback();

    // ---- origin_dist (D_TYPE=0x0B) — internal test feature ----
    bool getOriginDistData(BwOriginDist& out, int timeout_ms = 1000);
    bool saveOriginDistData(std::string path, std::string name,
                             int times, std::string suffix = "");
    void setOriginDistDisplayOffsetMeters(float meters);
    float originDistDisplayOffsetMeters() const;

    // ---- Statistics ----
    // Returns rolling-window transmission statistics. Values default to 0
    // before the first 10s window completes and after the protocol is
    // destroyed/reconstructed. delay_us is not tracked (P7).
    // pkg_loss_rate is the 10s rolling packet-loss percentage from
    // per-packet SEQ-gap observation (spec 2026-05-18 §4.3).
    // frame_loss_rate is a stub at 0.0f — "true frame loss" via azimuth
    // coverage shortfall is future work (spec 2026-05-18 §2).
    void getDataTransmissionState(uint32_t& delay_us,
                                   float& pkg_loss_rate,
                                   float& frame_loss_rate);

    // Internal use (test-only): override the rolling-window size. Production
    // callers must not invoke this; the documented host-app surface uses the
    // built-in 10000ms window. Tests use a short window (~20ms) to keep
    // ctest fast.
    void setStatsWindowForTest(std::chrono::milliseconds w);

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};

}  // namespace benewake
