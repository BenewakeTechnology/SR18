// src/router/sr18_half_duplex_executor.cpp
#include "sr18_half_duplex_executor.h"
#include "sr18_ascii_ack_matcher.h"

namespace sr18 {

HalfDuplexExecutor::HalfDuplexExecutor(ISerial*             serial,
                                        IDeviceStateMonitor* monitor,
                                        AsciiAckMatcher*     ascii_matcher,
                                        AsciiAngleMatcher*   angle_matcher)
    : serial_(serial), monitor_(monitor), ascii_matcher_(ascii_matcher),
      angle_matcher_(angle_matcher) {}

ICommandExecutor::Result HalfDuplexExecutor::execute(
    const uint8_t* frame, std::size_t len,
    bool need_rd_reg,
    std::chrono::milliseconds timeout)
{
    std::lock_guard<std::mutex> lk(exec_mu_);

    monitor_->armForCompletion();

    int w = serial_->write(frame, len);
    if (w < 0) return {Status::TIMEOUT, 0};

    auto deadline = std::chrono::steady_clock::now() + timeout;
    auto wr = monitor_->waitForCompletion(deadline, need_rd_reg);
    Status s = Status::TIMEOUT;
    switch (wr.status) {
        case IDeviceStateMonitor::Status::DONE:    s = Status::DONE;    break;
        case IDeviceStateMonitor::Status::CRC_ERR: s = Status::CRC_ERR; break;
        case IDeviceStateMonitor::Status::TIMEOUT: s = Status::TIMEOUT; break;
    }
    return {s, wr.rd_reg};
}

ICommandExecutor::AsciiResult HalfDuplexExecutor::executeAscii(
    const uint8_t* frame, std::size_t len,
    uint8_t expect_cmd_id, uint32_t expect_check_id,
    std::chrono::milliseconds timeout)
{
    std::lock_guard<std::mutex> lk(exec_mu_);   // one in-flight cmd across families
    if (!ascii_matcher_) return {};
    auto deadline = std::chrono::steady_clock::now() + timeout;

    ascii_matcher_->arm(expect_cmd_id, expect_check_id);   // arm-before-write
    int w = serial_->write(frame, len);
    if (w < 0) return {};

    auto r = ascii_matcher_->wait(deadline);
    if (r.status != AsciiAckMatcher::Status::OK) return {};
    return {true, r.err, r.cmd_data};
}

ICommandExecutor::AsciiAngleResult HalfDuplexExecutor::executeAsciiAngle(
    const uint8_t* frame, std::size_t len,
    uint32_t expect_check_id,
    std::chrono::milliseconds timeout)
{
    std::lock_guard<std::mutex> lk(exec_mu_);   // one in-flight cmd across families
    if (!angle_matcher_) return {};
    auto deadline = std::chrono::steady_clock::now() + timeout;

    angle_matcher_->arm(expect_check_id);       // arm-before-write
    int w = serial_->write(frame, len);
    if (w < 0) return {};

    auto r = angle_matcher_->wait(deadline);
    if (r.status != AsciiAngleMatcher::Status::OK) return {};
    return {true, r.file};
}

}  // namespace sr18
