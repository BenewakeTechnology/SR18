// src/data/sr18_ota_session.cpp
#include "sr18_ota_session.h"
#include "../codec/sr18_ota_codec.h"
#include "../transport/sr18_serial.h"
#include "../../include/sr18_common.h"
#include <chrono>
#include <vector>
#include <cstdio>
#include <cstring>

namespace sr18 {

OtaSession::OtaSession(ISerial* serial) : serial_(serial) {}

namespace {
// Read one complete OTA ACK frame within timeout_ms. Length-framed: scan for
// '$' (0x24), collect ota_ack_total_len(Len) bytes, parse. Returns true + ack
// on success; false on timeout/parse failure.
bool readOtaAck(ISerial* s, OtaAck& ack, int timeout_ms) {
    std::vector<uint8_t> buf;
    auto deadline = std::chrono::steady_clock::now()
                  + std::chrono::milliseconds(timeout_ms);
    uint8_t b;
    size_t need = 0;       // 0 = not yet synced on '$LDACK,' + Len
    while (std::chrono::steady_clock::now() < deadline) {
        int n = s->read(&b, 1, 50);
        if (n <= 0) continue;
        if (buf.empty()) { if (b != 0x24) continue; buf.push_back(b); continue; }
        buf.push_back(b);
        if (buf.size() == 8) {                 // 7 header + Len
            static const uint8_t hdr[7] = {0x24,0x4C,0x44,0x41,0x43,0x4B,0x2C};
            if (std::memcmp(buf.data(), hdr, 7) != 0) { buf.clear(); continue; }
            need = ota_ack_total_len(buf[7]);
            if (need < 8 || need > 64) { buf.clear(); need = 0; continue; }
        }
        if (need && buf.size() == need) {
            if (parse_ota_ack(buf.data(), buf.size(), ack)) {
                // OTA-family ACKs are documented to carry a FIXED CHECK_ID
                // (manual §2.3/§2.5, FPGA table §四). We check it but only
                // WARN — the ACK is still accepted.
                //
                // Why warn and not reject: 0x12345678 rests on two doc
                // assertions and has NEVER been observed on the wire. The
                // 2026-07-16 bench run that validated OTA end-to-end did not
                // read this field at all, so nobody knows what the device
                // actually sends. Rejecting would put a brand-new failure mode
                // ("no Ready ACK" / per-packet timeouts) on a path that is
                // known to work, on the strength of documentation alone.
                // Warning keeps the OTA success path byte-for-byte identical to
                // the validated build while still surfacing the real value.
                //
                // TO CLOSE THIS OUT: run one OTA, read [11..14] (big-endian) of
                // any Ready/OTA ACK. Matches -> flip this to `return` only on
                // match (one line). Differs -> fix kOtaCheckId in
                // sr18_ota_codec.h and tell the protocol team the docs are
                // wrong. Full write-up: docs/sdk/B1_OTA_GAP.md, section ⚠️ 未决.
                if (ack.check_id != kOtaCheckId) {
                    std::fprintf(stderr,
                                 "OTA: ACK CHECK_ID 0x%08X != documented 0x%08X"
                                 " — accepting anyway (see B1_OTA_GAP.md)\n",
                                 (unsigned)ack.check_id, (unsigned)kOtaCheckId);
                }
                return true;
            }
            buf.clear(); need = 0;      // bad CRC → resync (a foreign CHECK_ID
                                        // is warned about above, not rejected)
        }
    }
    return false;
}
}  // namespace

int OtaSession::run(const uint8_t* image, size_t image_len, const OtaParams& p) {
    if (!serial_ || !image || image_len == 0 || p.chunk == 0) return SR18_ERR_PARAM;

    // Manual §2.4: the first OTA packet's DATA must be >= 64 B. With
    // total = ceil(len/chunk) the first packet carries min(chunk, image_len),
    // so both a tiny image and a tiny chunk violate the floor.
    const size_t first_dlen = image_len < p.chunk ? image_len : (size_t)p.chunk;
    if (first_dlen < 64) {
        std::fprintf(stderr,
                     "OTA: first packet would be %zu B, below the 64 B minimum\n",
                     first_dlen);
        return SR18_ERR_PARAM;
    }

    // Drain residual bytes that accumulated while the line was at 3.125M and
    // the baud switch was in progress. Without this, stale bytes can falsely
    // appear to be OTA frame content and corrupt the Ready ACK sync.
    // One non-blocking read pass flushes whatever is in the driver/kernel buffer
    // at this instant; anything arriving after (i.e. the Ready ACK at 115200)
    // is unaffected.
    {
        uint8_t tmp[256];
        serial_->read(tmp, sizeof(tmp), 0);
    }

    // 1. Wait for Ready ACK (0x55).
    OtaAck ack;
    if (!readOtaAck(serial_, ack, p.ready_timeout_ms) || ack.code != 0x55) {
        std::fprintf(stderr, "OTA: no Ready ACK\n");
        return SR18_TIMEOUT;
    }

    // 2. Per-packet send loop. Packet sizing derived from the image.
    uint32_t total = (uint32_t)((image_len + p.chunk - 1) / p.chunk);
    std::fprintf(stderr, "OTA: ready, %u packets to send (%zu bytes)\n",
                 (unsigned)total, image_len);
    // Retry budget. NOT per-seq: err 0x07 sends us BACKWARDS (retransmit the
    // previous packet), so "attempts on packet N" has no stable owner once the
    // sequence can move both ways. consecutive_fail counts back-to-back failed
    // deliveries (ACK timeout or 0x07 failure ACK) for whatever packet is in
    // flight; manual §5.2c: max_retx of them and the upgrade has failed.
    //
    // high_water is the anti-livelock guard: the budget is refilled ONLY by
    // reaching a packet that has never been accepted before. Refilling on ANY
    // success would let a device that keeps rejecting packet N while accepting
    // N-1 ping-pong forever (N fails -> step back -> N-1 succeeds -> budget
    // reset -> N fails -> ...) — precisely what max_retx exists to stop.
    // Re-acking ground we already covered does not buy more retries.
    int      consecutive_fail = 0;
    uint32_t high_water       = 0;   // highest seq ever accepted, plus one
    for (uint32_t seq = 0; seq < total; ) {
        size_t off = (size_t)seq * p.chunk;
        uint32_t dlen = (uint32_t)((image_len - off < p.chunk) ? image_len - off : p.chunk);
        std::vector<uint8_t> frame;
        encode_ldota(p.info, total, seq, image + off, dlen, frame);
        std::fprintf(stderr, "OTA: packet %u/%u len=%u\n",
                     (unsigned)(seq + 1), (unsigned)total, (unsigned)dlen);

        if (serial_->write(frame.data(), frame.size()) < 0) return SR18_ERR_SERIAL;

        if (!readOtaAck(serial_, ack, p.ack_timeout_ms)) {
            // Manual §5.2c: a per-packet ACK timeout is one failed delivery, not
            // the end of the upgrade — retransmit within the retry budget.
            if (++consecutive_fail > p.max_retx) {
                std::fprintf(stderr, "OTA: packet %u/%u out of retx (no ACK)\n",
                             (unsigned)(seq + 1), (unsigned)total);
                return SR18_TIMEOUT;
            }
            std::fprintf(stderr, "OTA: packet %u/%u no ACK, retx %d/%d\n",
                         (unsigned)(seq + 1), (unsigned)total,
                         consecutive_fail, p.max_retx);
            continue;                              // resend the same packet
        }
        if (ack.code == 0x05) {                    // accepted
            ++seq;
            if (seq > high_water) {                // genuinely new ground
                high_water       = seq;
                consecutive_fail = 0;
            }
            continue;
        }
        if (ack.code != 0x07) return SR18_ERR_CRC; // unexpected DATA code

        if (++consecutive_fail > p.max_retx) {
            std::fprintf(stderr, "OTA: packet %u/%u out of retx (err 0x%02x)\n",
                         (unsigned)(seq + 1), (unsigned)total, (unsigned)ack.err);
            return SR18_TIMEOUT;
        }
        // Manual §6.2: err 0x07 = "当前包 ID 不连续，重传上一包" — the device is
        // asking for the PREVIOUS packet, not the one we just sent. Every other
        // error code means retry the packet in flight.
        if (ack.err == 0x07 && seq > 0) {
            --seq;
            std::fprintf(stderr,
                         "OTA: ID gap reported, stepping back to packet %u/%u, retx %d/%d\n",
                         (unsigned)(seq + 1), (unsigned)total,
                         consecutive_fail, p.max_retx);
        } else {
            std::fprintf(stderr, "OTA: packet %u/%u failed (err 0x%02x), retx %d/%d\n",
                         (unsigned)(seq + 1), (unsigned)total, (unsigned)ack.err,
                         consecutive_fail, p.max_retx);
        }
    }
    return SR18_OK;
}

}  // namespace sr18
