// include/sr18_idop.h
#pragma once
#include "sr18_api.h"
#include "sr18_common.h"
#include <deque>
#include <memory>

namespace sr18 { class RxRouter; }

namespace benewake {

class SR18_API IDOPProtocol {
public:
    explicit IDOPProtocol(sr18::RxRouter* router);
    ~IDOPProtocol();

    std::deque<BW_IMU_INFO> getIMUData();
    void registIMUDataCallback(IMUDataCallbackFunc cb, void* user);
    void cancelIMUDataCallback();

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};

}  // namespace benewake
