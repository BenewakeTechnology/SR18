// src/sr18_idop.cpp
#include "../include/sr18_idop.h"
#include "data/sr18_timestamp.h"
#include "router/sr18_rx_router.h"
#include <deque>
#include <mutex>
#include <atomic>

using namespace sr18;
using namespace benewake;

namespace {
constexpr float kImuAccRawToG = 1.0f / 8192.0f;
constexpr float kImuGyroRawToRadPerSec = (1.0f / 32.8f) * (3.14159265358979323846f / 180.0f);
}

struct IDOPProtocol::Impl {
    RxRouter* router;
    std::mutex mu_;
    std::deque<BW_IMU_INFO> queue_;
    std::atomic<bool> cb_enabled_{false};
    IMUDataCallbackFunc cb_ = nullptr;
    void* cb_user_ = nullptr;

    static int16_t le16(const uint8_t* p) { return (int16_t)((uint16_t)p[0] | ((uint16_t)p[1] << 8)); }

    void onFrame(const DecodedFrame& df) {
        BW_IMU_INFO info;
        // Layout: STX(2)+UPVER+DWVER+CHK+DTYPE = 6
        // TIME_S(6)@6 TIME_NS(4)@12 ACC_X(2)@16 ACC_Y(2)@18 ACC_Z(2)@20
        // GYRO_X(2)@22 GYRO_Y(2)@24 GYRO_Z(2)@26 SEQ(2)@28
        uint32_t us   = (uint32_t)df.full[12] | ((uint32_t)df.full[13]<<8)
                      | ((uint32_t)df.full[14]<<16) | ((uint32_t)df.full[15]<<24);
        const NormalizedTimestamp ts = normalizeWireTimestamp(df.full + 6, us);
        info.time_s   = ts.time_s;
        info.time_ns  = ts.time_ns;
        info.acc_x  = static_cast<float>(le16(df.full + 16)) * kImuAccRawToG;
        info.acc_y  = static_cast<float>(le16(df.full + 18)) * kImuAccRawToG;
        info.acc_z  = static_cast<float>(le16(df.full + 20)) * kImuAccRawToG;
        info.gyro_x = static_cast<float>(le16(df.full + 22)) * kImuGyroRawToRadPerSec;
        info.gyro_y = static_cast<float>(le16(df.full + 24)) * kImuGyroRawToRadPerSec;
        info.gyro_z = static_cast<float>(le16(df.full + 26)) * kImuGyroRawToRadPerSec;
        info.seq    = (uint16_t)((uint16_t)df.full[28] | ((uint16_t)df.full[29] << 8));
        IMUDataCallbackFunc cb_local = nullptr;
        void* user_local = nullptr;
        {
            std::lock_guard<std::mutex> lk(mu_);
            queue_.push_back(info);
            // Capacity 200, matching Benewake's imu_buf_ cap. getIMUData is
            // consume-and-clear, so this only bounds the worst case where a
            // poller stops draining; the cap mirrors the reference SDK.
            if (queue_.size() > 200) queue_.pop_front();
            if (cb_enabled_.load()) {
                cb_local = cb_;
                user_local = cb_user_;
            }
        }
        // Callback is invoked OUTSIDE the lock with the single just-arrived
        // frame, matching Benewake's IMUDataCallbackFunc signature exactly.
        // Users wanting the queue history call getIMUData() instead.
        if (cb_local) cb_local(info, user_local);
    }
};

IDOPProtocol::IDOPProtocol(RxRouter* router) : p_(std::make_unique<Impl>()) {
    p_->router = router;
    router->setIDOPConsumer([this](const DecodedFrame& df){ p_->onFrame(df); });
}
IDOPProtocol::~IDOPProtocol() {
    if (p_->router) p_->router->setIDOPConsumer(nullptr);
}

std::deque<BW_IMU_INFO> IDOPProtocol::getIMUData() {
    std::lock_guard<std::mutex> lk(p_->mu_);
    // Consume-and-clear, matching Benewake idop_get_imu_data (copy + clear):
    // each call returns only frames accumulated since the last call and empties
    // the buffer, so repeated polling never re-emits already-read frames.
    std::deque<BW_IMU_INFO> out;
    out.swap(p_->queue_);
    return out;
}
void IDOPProtocol::registIMUDataCallback(IMUDataCallbackFunc cb, void* user) {
    std::lock_guard<std::mutex> lk(p_->mu_);
    p_->cb_       = cb;
    p_->cb_user_  = user;
    p_->cb_enabled_.store(cb != nullptr);
}
void IDOPProtocol::cancelIMUDataCallback() {
    std::lock_guard<std::mutex> lk(p_->mu_);
    p_->cb_enabled_.store(false);
    p_->cb_ = nullptr;
}
