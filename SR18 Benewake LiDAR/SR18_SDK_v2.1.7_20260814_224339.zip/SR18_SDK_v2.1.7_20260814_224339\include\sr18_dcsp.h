// include/sr18_dcsp.h
#pragma once
#include "sr18_api.h"
#include "sr18_common.h"
#include "sr18_protocol.h"
#include <cstdint>
#include <memory>

namespace sr18 { class ICommandExecutor; }
namespace sr18 { class IRdRegSampler; }
namespace sr18 { class AdcMonitor; }
namespace sr18 { class ILutFailWatcher; }

namespace benewake {

// ASCII protocol mode-switch selector (CMD_ID 0x03). Maps to CMD_DATA per the
// command catalog in docs/sdk/ASCII_PROTOCOL.md §3.
//
// Only modes confirmed valid by the FPGA downlink table (docs/validation/
// downlink_command_io_table.md) are exposed. Deliberately NOT exposed:
//  - 通用模式 (01 00): no source — absent from the manual, its C-code, and the
//    FPGA table. Was a mis-transcription in an earlier ASCII_PROTOCOL.md; removed.
//  - 非重复扫描 (05 00 enter / 06 00 exit): defined only in the manual's C-code,
//    but the current FPGA build rejects 05 00 as an illegal/undefined command
//    (未命中命令集) — not adapted in firmware yet. Re-add as an enter/exit pair
//    once the device supports it.
// DIRTY_REFRESH (07 00) IS implemented and exposed: it is a fully-specified,
// recognized entry in the FPGA command set (valid CRC 71 49 F4 7F). The manual's
// "暂不适配" note is device-side — the FPGA accepts the command but has not wired
// its effect yet; that is firmware's timeline, not an SDK limitation.
enum class AsciiMode {
    NORMAL,             // 00 00
    RECHARGE,           // 02 00
    RECHARGE_TO_NORMAL, // 03 00
    DIRTY_REFRESH,      // 07 00
    ECHO_STRONGEST,     // 08 00
    ECHO_LAST,          // 09 00
};

class SR18_API DCSPProtocol {
public:
    // ctor: borrowed pointers; lifetime managed by SR18Lidar facade.
    // initial_slot defaults to SLOT_9 (two-port idle entry); receive-only
    // mode constructs with SLOT_1 to reflect "device already streaming".
    DCSPProtocol(sr18::ICommandExecutor* executor,
                 sr18::IRdRegSampler*    sampler,
                 sr18::AdcMonitor*       adc_monitor,
                 sr18::SlotState         initial_slot = sr18::SlotState::SLOT_9,
                 sr18::ILutFailWatcher*  lut_fail     = nullptr);
    ~DCSPProtocol();

    // 0x0B / 0x0D
    int dcsp_enable(bool flag, int timeout_ms = 6000);          // true: LASER_EN; false: SYS_RST
    int dcsp_reboot(int timeout_ms = 1000);

    // 0x0E
    int dcsp_set_timestamp(const BwTimestamp& ts, int timeout_ms = 1000);

    // 0x02 / 0x06 (single-register read)
    int dcsp_read_register(uint16_t addr, uint32_t& value_out,
                           bool down=false, int timeout_ms = 1000);

    // 0x00 / 0x01 / 0x04 / 0x05 (auto-chunked by current slot)
    // inter_packet_delay_ms: after each packet's ACK, if another packet
    // follows, sleep this many ms before sending the next one. The LAST
    // packet's ACK is NOT followed by any wait. Clamped to [0, 10000];
    // default 0 = back-to-back (behaviour identical to earlier versions).
    int dcsp_write_register(const uint16_t* addrs, const uint32_t* values, int n,
                            bool save, bool down=false, int timeout_ms = 1000,
                            int inter_packet_delay_ms = 0);

    // 0x07 register-style LUT — retired 2026-07-07 (see spec). Superseded by
    // dcsp_wr_lut_up (boot-unified) added below.
    // int dcsp_download_lut(uint8_t id, const uint8_t* data, uint16_t len,
    //                       int timeout_ms = 1000);

    // Read the most recent ADC values for all 8 channels. The device
    // transmits ADC samples cyclically — every Status frame (offset 10..13)
    // and origin_dist frame (offset 526..529) carries a 32-bit ADC_VALUE
    // word that encodes ONE high-channel and ONE low-channel sample.
    // (b1 new protocol: the PCD frame no longer has an ADC field.)
    // This call returns the latest cached value for each of channels 0..7.
    // Channels not yet observed since SDK start return 0.
    //
    // Values are post-conversion (per-channel formula stub; identity until
    // the protocol team provides physical formulas). Unit per channel TBD.
    //
    // Non-blocking. Returns SR18_OK, or SR18_ERR_PARAM if out is null.
    int dcsp_get_adc_values(uint16_t out[8]);

    // Stub commands (return SR18_ERR_NOT_SUPPORTED, no bytes sent)
    int dcsp_lidar_stop(int timeout_ms = 1000);

    // ASCII protocol commands ($LDCMD, CMD_ID 0x03 / 0x02). Coexist with the
    // binary register commands above; both share the executor's single in-flight
    // guarantee. On success, the executor's matcher confirmed a $LDACK with
    // err==0; this call then enforces the 35 ms inter-command delay.
    int dcsp_switch_mode(AsciiMode mode, int timeout_ms = 5000);

    // Read the angle file (ASCII $LDCMD CMD_ID 0x02 / CMD_DATA 0x0007, special
    // CHECK_ID 0x0A2CB395). On success copies the raw 72-byte angle region
    // (18 channels x 4 bytes) into out; per-channel decoding + inner-CRC
    // verification are deferred (raw passthrough). out must hold >= 72 bytes.
    int dcsp_read_angle_file(uint8_t out[72], int timeout_ms = 5000);

    // OTA handoff commands (ASCII, reuse the verified $LDCMD path). Issued on the
    // 9600 TX with ACK via the 3.125M matcher while RxRouter is still running.
    int dcsp_enter_upgrade_mode(int timeout_ms = 5000);     // CMD_ID 0x03 / CMD_DATA 0x0004
    int dcsp_request_whole_package(int timeout_ms = 5000);  // CMD_ID 0x02 / CMD_DATA 0x0405

    /* ── RETIRED 2026-07-28: binary bootimage upload (TC 0x03 / 0x08) ────────
       Firmware upgrade goes through the ASCII path exclusively now
       (SR18Lidar::downloadFirmware → $LDOTA). Commented out rather than
       deleted so the packetization rules stay findable; delete outright once
       the binary boot path is definitively dead.

    int dcsp_wr_boot_down(const uint8_t* img, size_t n, int timeout_ms = 5000);
    int dcsp_wr_boot_up(const uint8_t* img, size_t n, int timeout_ms = 5000);
    void setBootChunkBytes(size_t n);
       ───────────────────────────────────────────────────────────────────── */

    // 0x07 up-board LUT bin upload. Each packet's PAYLOAD is a 12-byte
    // little-endian header + that packet's DATA bytes:
    //   [0..3] total = total DATA packet count
    //   [4..7] no    = this packet's index, from 0
    //   [8..11] len  = this packet's DATA byte count
    //   [12..]  data (raw file bytes; no end magic, no tail pad on dev_b1)
    // The device only starts an upgrade session once it parses no==0, and uses
    // no==total-1 to find the last packet, whose trailing 4 bytes must be the
    // whole-image CRC word (it has to be present in the file). Then CHK_ST
    // bit[5:4] verify: settle (default 5 s; the device
    // is still reading flash / running verify right after upload), then actively
    // probe by reading up-board reg 0x310c — the device rides the fresh bit[5:4]
    // back on that command's ACK. bit[5:4] states: 00 未确认 / 01 校验通过 /
    // 10 内容不符 / 11 无host CRC; ONLY 01 (PASSED) is success. The final status
    // code is printed to stderr. Returns SR18_OK on PASSED, SR18_ERR_LUT_WRITE on
    // any other verify state (retransmission is left to the caller),
    // SR18_ERR_PARAM, SR18_ERR_NOT_SUPPORTED, or a packet/probe rc (e.g.
    // SR18_TIMEOUT if the probe gets no ACK ⇒ write NOT confirmed).
    int dcsp_wr_lut_up  (const uint8_t* data, size_t n, int packet_timeout_ms = 5000);
    // Down-board LUT (TC=0x0A). Identical to dcsp_wr_lut_up in every respect —
    // same packetization and the same 0x310c bit[5:4] verify — except the LUT
    // write command byte.
    int dcsp_wr_lut_down(const uint8_t* data, size_t n, int packet_timeout_ms = 5000);
    // Per-packet LUT DATA size (the 12-byte header is added on top, so the wire
    // payload is n+12); clamp [4,65520], round down to /4, default 1024.
    void setLutChunkBytes(size_t n);
    // bit[5:4] settle window (ms) slept through before probing; default 5000.
    // Tuning/test knob.
    void setLutVerifyWindowMs(int ms);
    // Grace (ms): the probe read-register command's ACK timeout AND how long to
    // wait for its ACK-borne CHK_ST sample; default 2000. Tuning/test knob.
    void setLutVerifyGraceMs(int ms);

    // Slot state inspection
    sr18::SlotState getCurrentSlot() const;

private:
    struct Impl;
    std::unique_ptr<Impl> p_;
};

}  // namespace benewake
