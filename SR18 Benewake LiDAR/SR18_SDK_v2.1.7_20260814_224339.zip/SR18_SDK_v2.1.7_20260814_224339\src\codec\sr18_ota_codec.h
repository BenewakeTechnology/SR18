// src/codec/sr18_ota_codec.h
#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>

namespace sr18 {

// Every OTA-family ACK — both the Ready ACK (0x55) and the per-packet data ACK
// — carries this FIXED CHECK_ID, big-endian on the wire (12 34 56 78). It is
// NOT an echo of anything the host sent: manual §2.3 "固定值，非回显CMD" / §2.5,
// FPGA downlink table §四 "PKT_OTA/OTARDY 恒 12 34 56 78".
constexpr uint32_t kOtaCheckId = 0x12345678u;

// Parsed OTA ACK ($LDACK with big-endian fields, Len=0x02).
struct OtaAck {
    uint8_t  code     = 0;   // data[0]: 0x55 ready / 0x05 success / 0x07 fail
    uint8_t  err      = 0;   // failure detail when code==0x07
    uint32_t check_id = 0;   // big-endian decoded
};

// Total wire length of an OTA ACK frame given its Len field. = 19 + len_field.
// OTA ACKs always use Len=0x02; parse_ota_ack rejects any other value.
size_t ota_ack_total_len(uint8_t len_field);

// Parse a complete $LDACK OTA-family frame (Len must be 0x02). Big-endian
// fields; CRC-32/MPEG-2 over [Len..CHECK_ID], big-endian on wire. Returns true
// iff header, CRC and EE FF terminator validate; fills out on success.
bool parse_ota_ack(const uint8_t* frame, size_t len, OtaAck& out);

// Encode one $LDOTA data packet (big-endian):
//   $LDOTA,(7) | info(4 BE) | total(4 BE) | seq(4 BE) | size(4 BE) | DATA
//   | CRC32-MPEG2-align4 over [info..DATA] (4 BE) | EE FF
// `size` is written as data_len. out is cleared then filled.
void encode_ldota(uint32_t info, uint32_t total, uint32_t seq,
                  const uint8_t* data, uint32_t data_len,
                  std::vector<uint8_t>& out);

}  // namespace sr18
