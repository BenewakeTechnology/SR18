// src/codec/sr18_ascii_codec.h
#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>

namespace sr18 {

// Parsed $LDACK command-family ACK fields.
struct AsciiAck {
    uint8_t  cmd_id   = 0;
    uint16_t cmd_data = 0;   // echoed, little-endian decoded
    uint8_t  err      = 0;   // 0x00 ok / 0x01 illegal / 0x05 timeout / 0x32 CRC
    uint32_t check_id = 0;   // echoed, little-endian decoded
};

// Encode a $LDCMD frame with a VARIABLE-length CMD_DATA (manual §2.1: the Len
// field is "CMD ID + CMD DATA 的总字节数", so CMD_DATA is not fixed at 2 B):
//   $LDCMD,(7) | Len(1) = 1 + cmd_data_len | CMD_ID(1) | CMD_DATA(cmd_data_len)
//   | CHECK_ID(4 LE) | CRC32-MPEG2-align4 over [Len..CHECK_ID] (4 LE) | EE FF
// out is cleared then filled. Total length = 18 + Len bytes (note: NOT the
// 19 + Len of ascii_ack_total_len — the ACK carries an extra error-code byte).
// cmd_data_len must be <= 254 (Len is one byte); on overflow out is left empty.
// A null cmd_data is only valid with cmd_data_len == 0.
void encode_ascii_cmd(uint8_t cmd_id, const uint8_t* cmd_data, size_t cmd_data_len,
                      uint32_t check_id, std::vector<uint8_t>& out);

// Convenience overload for the 2-byte CMD_DATA commands (mode-switch / query
// family), which are the majority. Serialises cmd_data little-endian and
// delegates to the variable-length form above; Len = 0x03, total = 21 bytes.
void encode_ascii_cmd(uint8_t cmd_id, uint16_t cmd_data, uint32_t check_id,
                      std::vector<uint8_t>& out);

// Total wire length of an $LDACK frame given its Len field. = 19 + len_field.
size_t ascii_ack_total_len(uint8_t len_field);

// Special CHECK_ID for the read-angle-file command/ACK (per FPGA downlink
// table), distinct from the default 0x12345678 that every other $LDCMD uses.
// On the wire (little-endian): 95 B3 2C 0A.
constexpr uint32_t kAsciiAngleCheckId = 0x0A2CB395u;

// Len field of the read-angle-file ACK (PKT_CMD33): 0x50 = 80, giving a total
// frame length of 19 + 80 = 99 bytes.
constexpr uint8_t  kAsciiAngleLen     = 0x50;

// Raw (undecoded) read-angle-file ACK payload. The 72-byte angle region is
// 18 channels x 4 bytes; per-channel decoding is deliberately deferred — this
// struct hands back the raw bytes only. inner_crc is the device-appended CRC
// over the angle region (little-endian decoded; VERIFIED by the parser using
// CRC-32/MPEG-2 align4 over the 72-byte region).
struct AsciiAngleFile {
    uint8_t  angle_raw[72] = {0};
    uint32_t inner_crc = 0;
    uint32_t check_id  = 0;   // echoed CHECK_ID (expect kAsciiAngleCheckId)
    uint8_t  err       = 0;
};

// Parse a complete read-angle-file reply (Len must be 0x50, total 99 bytes).
// The reply uses a dedicated header $LDANG, (NOT $LDACK,) so PKT_CMD33 is
// distinguishable from ordinary command-family ACKs on the wire.
// Wire layout (offsets):
//   [0..6] "$LDANG," | [7] Len=0x50 | [8] CMD_ID=0x02 | [9..10] CMD_DATA
//   | [11] inner_len=0x4C | [12..83] angle 72B | [84..87] inner CRC
//   | [88] err | [89..92] CHECK_ID | [93..96] outer CRC | [97..98] EE FF
// Validates header, Len, EE FF terminator, the OUTER CRC (align4 LE over
// [Len..CHECK_ID]) AND the INNER CRC (align4 LE over the 72-byte angle region);
// fills out with the raw 72-byte region + inner CRC + err + echoed CHECK_ID.
// CMD_ID/CMD_DATA mismatch is warned only (non-fatal). Channels are not decoded
// here. Returns true iff header, Len, terminator, outer CRC and inner CRC pass.
bool parse_ascii_angle_ack(const uint8_t* frame, size_t len, AsciiAngleFile& out);

// Parse a complete $LDACK,...EE FF command-family frame (Len must be 0x03).
// Returns true iff header magic, CRC (align4 LE over [Len..CHECK_ID]) and the
// EE FF terminator all validate; fills out on success. Returns false otherwise.
bool parse_ascii_ack(const uint8_t* frame, size_t len, AsciiAck& out);

}  // namespace sr18
