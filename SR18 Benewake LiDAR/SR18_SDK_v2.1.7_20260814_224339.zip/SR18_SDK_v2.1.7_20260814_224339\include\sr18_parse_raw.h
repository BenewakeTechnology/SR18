// include/sr18_parse_raw.h
// Offline parser for raw RX byte-stream recordings made with
// SR18Lidar::enableRawRecord (or any raw dump of the SR18 RX UART).
//
// Interface mirrors benewake::ParsePcap from the reference Benewake SDK
// (tools/parse_pcap), renamed Pcap -> Raw:
//   - raw_frame_find(file)      <-> pcap_frame_find: scan whole file, fill
//                                    frame_offset_list_ with the byte offset
//                                    of each point-cloud frame's first packet
//   - parseFrameByOffset(...)    same signature: decode ONE frame at offset
//   - getIntervalFromRaw()      <-> getIntervalFromPcap: frame interval [s];
//                                    derived from in-packet device timestamps
//                                    (raw dumps carry no capture timestamps)
//   - closeFile()                same
//
// Frame boundaries use the SAME azimuth-reset assemblers as the live SDK, so
// offline frames match what registPointCloudCallback would have delivered.
// PCD (D_TYPE 0x00) vs origin_dist (0x0B) is auto-detected per packet; other
// D_TYPEs (IMU/Status) are skipped. Not thread-safe (use one per thread).
#pragma once
#include "sr18_api.h"
#include "sr18_common.h"
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace benewake {

class SR18_API ParseRaw {
public:
    ParseRaw();
    ParseRaw(const char* _file_name);
    ~ParseRaw();

    // Owns a FILE*; copying would double-close it.
    ParseRaw(const ParseRaw&) = delete;
    ParseRaw& operator=(const ParseRaw&) = delete;

    void setParseFile(std::string _file_name);

    // Scan the whole file and record each point-cloud frame's first-packet
    // byte offset into frame_offset_list_. Clears any previous index.
    void raw_frame_find(std::string _file_name);

    std::vector<int64_t> frame_offset_list_;

    // Decode one frame starting at _offset (use values from
    // frame_offset_list_). On failure _point_cloud is set to nullptr.
    void parseFrameByOffset(int64_t _offset, BwPointCloud::Ptr& _point_cloud);

    // Interval between the last two consecutive frame starts seen by
    // raw_frame_find, in seconds (device timestamps). 0.0 before a scan or
    // with fewer than two frames.
    double getIntervalFromRaw();

    void closeFile();

private:
    std::string parse_file_;
    std::FILE*  in_file_ = nullptr;
    double      frame_interval_ = 0.0;

    bool ensureOpen(const std::string& _file_name);
};

}  // namespace benewake
