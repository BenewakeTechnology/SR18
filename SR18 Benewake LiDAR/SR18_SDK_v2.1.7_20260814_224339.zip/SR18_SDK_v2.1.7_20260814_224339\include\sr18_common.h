// include/sr18_common.h
#pragma once
#include "sr18_api.h"
#include <cstdint>
#include <memory>
#include <vector>
#include <deque>
#include <string>

// ---- SDK version (Benewake-style) ----
#define SR18_SDK_VERSION_BRANCH "SR18"
#define SR18_SDK_VERSION_MAJOR  2
#define SR18_SDK_VERSION_MINOR  1
#define SR18_SDK_VERSION_BUILD  7

// Human-readable SDK version string, composed from the macros above so it can
// never drift out of sync with them. Yields e.g. "SR18-SDK-2.1.7".
#define SR18_SDK_VERSION_STR_HELPER(x) #x
#define SR18_SDK_VERSION_STR(x)        SR18_SDK_VERSION_STR_HELPER(x)
#define SR18_SDK_VERSION_STRING \
    "SR18-SDK-" SR18_SDK_VERSION_STR(SR18_SDK_VERSION_MAJOR) "." \
                SR18_SDK_VERSION_STR(SR18_SDK_VERSION_MINOR) "." \
                SR18_SDK_VERSION_STR(SR18_SDK_VERSION_BUILD)

namespace benewake {

// Returns the SDK version as a static-storage C string in the form
// "<BRANCH>_<MAJOR>.<MINOR>.<BUILD>" (e.g. "SR18_1.0.9"). Mirrors the
// Benewake reference SDK's benewake_get_sdk_version() interface.
SR18_API const char* sr18_get_sdk_version();

// Optional process-wide origin_dist scan-line/spot-location to SDK-channel map.
// Values must be 0..17 or 0xFF (invalid). If not configured, the SDK uses the
// factory B-sample table. Configure before constructing SR18Lidar / parsing raw
// origin_dist frames; existing objects may already have consumed prior mapping.
SR18_API bool setOriginDistChannelMap(const uint8_t channel_map[4][16]);
SR18_API void getOriginDistChannelMap(uint8_t channel_map[4][16]);
SR18_API void clearOriginDistChannelMap();

struct BwTimestamp {
    uint32_t time_s = 0;
    uint32_t time_ns = 0;
};

// Sentinel for BwPoint::contamination when the running data mode carries no
// 脏污 field on the wire (origin_dist / 解距, D_TYPE 0x0B). Deliberately NOT 0
// — 0 is a real level ("优") and would be read as "clean" by the host app.
constexpr uint8_t kContaminationUnavailable = 0xFF;

struct BwPoint {
    float    x = 0, y = 0, z = 0;       // Right-handed Cartesian, metres.
                                         //   +X right, +Y forward (tail-fiber
                                         //   side = 0°), +Z up (rotation axis).
                                         //   Azimuth is measured clockwise
                                         //   from +Y when viewed from above.
                                         //   See include/sr18_geometry.h.
    uint16_t distance = 0;               // 1 LSB = 1 cm (SDK convention).
                                         // PCD wire LSB is 4 mm (decoded by
                                         // FrameAssembler); origin_dist derives
                                         // from centroid (decoded by
                                         // OriginDistFrameAssembler). Both
                                         // assemblers cm-quantize for storage
                                         // here AND fill x/y/z with full wire
                                         // precision via
                                         // pointToCartesianFromMeters.
    uint8_t  intensity = 0;              // 1B reflectivity
    uint8_t  channel = 0;                // 0..17
    // Azimuth raw wire counts. b1 new protocol (PCD and origin_dist alike):
    // 0.01 deg/LSB, full revolution = 36000 — convert with
    // pcdAzimuthToRadians() in sr18_geometry.h. Legacy recordings use the old
    // fix17_13-radian encoding (~51472 per rev; azimuthToRadians()).
    uint16_t azimuth = 0;
    uint32_t timestamp_ns = 0;           // Normalized sub-second part (ns)
    uint64_t timestamp_s = 0;            // Normalized seconds part
    uint8_t  echo = 0;                   // Echo-slot bitmask. bit N (N in
                                          // 0..2) is set when this point
                                          // comes from echo_N.
                                          // PCD frames (D_TYPE 0x00) carry
                                          // one distance per channel and
                                          // emit a single BwPoint with
                                          // echo = 0x01.
                                          // origin_dist frames (D_TYPE 0x0B)
                                          // carry up to 3 echoes per channel
                                          // and emit up to 3 BwPoints per
                                          // channel, one per non-zero echo
                                          // slot, with the corresponding bit
                                          // set (0x01 / 0x02 / 0x04).
    uint8_t  contamination = 0;          // Window contamination level of THIS
                                          // point's channel: 0 = 优, 1 = 中,
                                          // 2 = 差, 3 = reserved.
                                          // Source: the 18ch x 2bit 脏污 region
                                          // in the tail of the SAME 球坐标 PCD
                                          // frame this point was decoded from
                                          // (D_TYPE 0x00, offset
                                          // PCD_OFF_CONTAM) — per-point and
                                          // per-frame, never a cross-frame
                                          // cache.
                                          // origin_dist frames (D_TYPE 0x0B)
                                          // carry no 脏污 field, so points from
                                          // that path get
                                          // kContaminationUnavailable (0xFF).
                                          // This is the ONLY 脏污 output — the
                                          // frame-level 18ch-array getter on
                                          // SR18Lidar was removed 2026-07-30
                                          // (PRO-84): a cross-frame snapshot
                                          // cannot guarantee it belongs to the
                                          // point cloud you are holding.
};

struct BwPointCloud {
    using Ptr = std::shared_ptr<BwPointCloud>;
    std::vector<BwPoint> points;
    uint32_t time_s = 0;
    uint32_t time_ns = 0;
};

struct BW_IMU_INFO {
    uint64_t time_s = 0;
    uint32_t time_ns = 0;
    float    acc_x = 0.0f, acc_y = 0.0f, acc_z = 0.0f;        // g
    float    gyro_x = 0.0f, gyro_y = 0.0f, gyro_z = 0.0f;     // rad/s
    uint16_t seq = 0;
};

// Decoded fault-information frame (independent EE DD frame). Fields per the
// JT16_SR18 manual §4.4/§7. Delivered via registFaultCallback; the SDK only
// reports faults, it never acts on the "应对措施" (remedial actions).
struct BW_FAULT_INFO {
    uint64_t time_s = 0;             // normalized device time (s)
    uint32_t time_ns = 0;            // normalized sub-second (ns)
    uint8_t  fs_version = 0;         // fault-struct version
    uint8_t  lidar_state = 0;        // 0=normal 1=warning 2=shutdown 3=standby
    uint8_t  rolling_counter = 0;    // 0..7
    uint8_t  total_fault_codes = 0;  // codes currently queued
    uint8_t  fault_code_id = 0;      // 1-based index of this code in the queue
    uint16_t fault_code = 0;         // raw code; see sr18_fault_code_name()
};

// Human-readable (English) name for a fault code / lidar state. "unknown" for
// unrecognized values. Thin public wrappers over the codec LUTs so host apps
// can print faults without pulling in internal headers.
SR18_API const char* sr18_fault_code_name(uint16_t code);
SR18_API const char* sr18_lidar_state_name(uint8_t state);

// One calibration source table (RD_REG or ADC_VALUE).
// samples[tooth] holds the per-revolution valid time-count values for that
// tooth (only bit[31]=1 words are stored; length == actual valid count,
// ideally == target_revs). mean[tooth] = sum/size of that column.
struct CalibrationTableResult {
    int n_teeth = 0;        // max tooth index seen + 1 (0 if nothing collected)
    std::vector<std::vector<uint32_t>> samples;  // [tooth] -> values
    std::vector<double> mean;                    // [tooth] -> sum/size
};

// Calibration data collection result (see SR18Lidar::collectCalibration).
struct CalibrationResult {
    int n_teeth = 0;        // max tooth index seen + 1 (0 if nothing collected)
    int target_revs = 0;    // requested revolution count
    std::vector<std::vector<uint32_t>> samples;  // [tooth] -> values
    std::vector<double> mean;                    // [tooth] -> Σ/size
    CalibrationTableResult rd_reg;               // RD_REG slot table
    CalibrationTableResult adc_value;            // ADC_VALUE slot table
};

struct SYS_INFO {
    uint8_t  up_ver = 0;
    uint8_t  dw_ver = 0;
    uint8_t  chk_st = 0;
    uint32_t adc_value = 0;
    uint16_t last_seq = 0;
    std::string sn = "000000";
    std::string version = SR18_SDK_VERSION_STRING;
    std::string fpga_version = "SR18-FPGA-0.0.0";
    int sys_err = 0, sys_status = 0, comm_status = 0;
};

using HeartBeatCallbackFunc  = void(*)(const SYS_INFO&, void*);
// Single-frame IMU callback, matching Benewake's exact signature
//   typedef void(*IMUDataCallbackFunc)(benewake::BW_IMU_INFO, void*);
// (changed 2026-04-30 from a deque-of-history form that was a deviation
//  from the reference SDK and caused per-call O(N) copies)
using IMUDataCallbackFunc    = void(*)(BW_IMU_INFO, void*);
// Single-frame fault callback. Invoked from the Rx thread (must not block).
using FaultCallbackFunc      = void(*)(const BW_FAULT_INFO&, void*);
using PointCloudCallbackFunc = void(*)(BwPointCloud::Ptr, int frame_id, void*);

struct BwOriginDistEchoInfo {
    uint32_t echo_cent             = 0;
    uint16_t echo_win_sum          = 0;
    uint16_t echo_win_max          = 0;
    uint16_t echo_max_add_large    = 0;
    uint16_t echo_max_add_neighbor = 0;
    uint8_t  confidence            = 0;
    uint8_t  right_large_flag      = 0;
};

struct BwOriginDist {
    uint32_t timestamp_s  = 0;     // Unix epoch seconds (UTC), decoded from the TIME_S calendar bytes
    uint32_t timestamp_ns = 0;     // Nanoseconds (TIME_NS microsecond field x1000)
    uint32_t time_offset  = 0;     // SR18 protocol has no per-packet time_offset; kept at 0
                                    // to preserve byte-identical save-file format with Benewake.
    uint16_t azimuth      = 0;

    uint8_t  channel  [18] = {0};
    uint8_t  scan_line[18] = {0};
    uint8_t  spot_loc [18] = {0};
    uint8_t  back_mean[18] = {0};
    uint8_t  fram_err [18] = {0};   // Benewake spelling preserved
    uint8_t  err_code [18] = {0};

    BwOriginDistEchoInfo echo_0[18];
    BwOriginDistEchoInfo echo_1[18];
    BwOriginDistEchoInfo echo_2[18];
};

}  // namespace benewake

// Status code macros (Benewake-style)
#define SR18_OK                  0
#define SR18_FAIL               -1
#define SR18_TIMEOUT            -2
#define SR18_ERR_CRC            -3
#define SR18_ERR_BUSY           -4
#define SR18_ERR_PARAM          -5
#define SR18_ERR_PARTITION      -6
#define SR18_ERR_NOT_SUPPORTED  -7
#define SR18_ERR_SLOT           -8
#define SR18_ERR_SERIAL         -9
#define SR18_ERR_LUT_WRITE     -10   // LUT write not confirmed (CHK_ST bit[5:4]!=01/PASSED)
