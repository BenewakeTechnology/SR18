// src/transport/sr18_serial_win.cpp
#ifdef _WIN32
#include "sr18_serial.h"
#include "sr18_serial_write_timeout.h"
#include <windows.h>
#include <chrono>
#include <cstdio>

namespace sr18 {

class WinSerial : public ISerial {
public:
    int open(const std::string& port, uint32_t baud) override {
        close();
        std::string full = "\\\\.\\" + port;
        h_ = ::CreateFileA(full.c_str(), GENERIC_READ | GENERIC_WRITE, 0, nullptr,
                           OPEN_EXISTING, FILE_FLAG_OVERLAPPED, nullptr);
        if (h_ == INVALID_HANDLE_VALUE) return -1;

        // The SR18 RX link streams ~3200 pkt/s x 84 B ≈ 268.8 KB/s with no
        // flow control. The driver's default RX buffer (a few KB) holds only
        // tens of milliseconds of data, so any host scheduling stall overruns
        // it and a contiguous run of bytes is silently discarded — observed
        // on the bench as periodic "[Decoder] CRC error" + multi-packet SEQ
        // gaps. 1 MB buys ~3.9 s of stall headroom. (Size is a hint; the
        // driver may clamp it.)
        ::SetupComm(h_, kRxDriverBuf, kTxDriverBuf);

        DCB dcb{}; dcb.DCBlength = sizeof(dcb);
        if (!::GetCommState(h_, &dcb)) { close(); return -2; }
        dcb.BaudRate = baud;
        baud_ = baud;  // remembered for the byte-count×baud write-timeout calc
        dcb.ByteSize = 8;
        dcb.Parity   = NOPARITY;
        dcb.StopBits = ONESTOPBIT;
        dcb.fBinary  = TRUE;
        // GetCommState inherits whatever the previous application left on the
        // port. Pin every mode bit that could stall or corrupt the stream:
        // no HW/SW flow control, lines asserted, errors must not abort I/O.
        dcb.fOutxCtsFlow    = FALSE;
        dcb.fOutxDsrFlow    = FALSE;
        dcb.fDsrSensitivity = FALSE;
        dcb.fOutX           = FALSE;
        dcb.fInX            = FALSE;
        dcb.fNull           = FALSE;
        dcb.fAbortOnError   = FALSE;
        dcb.fDtrControl     = DTR_CONTROL_ENABLE;
        dcb.fRtsControl     = RTS_CONTROL_ENABLE;
        if (!::SetCommState(h_, &dcb)) { close(); return -3; }

        // "Return immediately if bytes are buffered, otherwise wait up to
        // ReadTotalTimeoutConstant for the first byte" (documented MAXDWORD /
        // MAXDWORD / constant special case). read() updates the constant when
        // the caller's timeout changes.
        last_read_timeout_ms_ = -1;
        if (applyReadTimeout(5) != 0) { close(); return -4; }

        rd_ev_ = ::CreateEventA(nullptr, TRUE, FALSE, nullptr);
        wr_ev_ = ::CreateEventA(nullptr, TRUE, FALSE, nullptr);
        if (!rd_ev_ || !wr_ev_) { close(); return -5; }

        ::PurgeComm(h_, PURGE_RXCLEAR | PURGE_TXCLEAR);
        DWORD errs = 0;
        ::ClearCommError(h_, &errs, nullptr);
        return 0;
    }
    void close() override {
        if (h_ && h_ != INVALID_HANDLE_VALUE) {
            ::CancelIoEx(h_, nullptr);
            ::CloseHandle(h_);
        }
        h_ = nullptr;
        if (rd_ev_) { ::CloseHandle(rd_ev_); rd_ev_ = nullptr; }
        if (wr_ev_) { ::CloseHandle(wr_ev_); wr_ev_ = nullptr; }
    }
    int write(const uint8_t* buf, size_t n) override {
        if (!h_ || h_ == INVALID_HANDLE_VALUE) return -1;
        ::ResetEvent(wr_ev_);
        OVERLAPPED ov{};
        ov.hEvent = wr_ev_;
        DWORD w = 0;
        BOOL ok = ::WriteFile(h_, buf, (DWORD)n, &w, &ov);
        if (!ok && ::GetLastError() == ERROR_IO_PENDING) {
            // Wait long enough for n bytes to physically clock out at baud_
            // (a fixed 1000 ms truncated 1024 B @ 9600 bps mid-flight); never
            // below the legacy 1000 ms floor. See sr18_serial_write_timeout.h.
            DWORD wait = ::WaitForSingleObject(
                ov.hEvent, (DWORD)computeWriteTimeoutMs(n, baud_));
            if (wait == WAIT_OBJECT_0) ok = ::GetOverlappedResult(h_, &ov, &w, FALSE);
            else {
                ::CancelIo(h_);
                ok = FALSE;
            }
        }
        return ok ? (int)w : -1;
    }
    int read(uint8_t* buf, size_t n, int timeout_ms) override {
        if (!h_ || h_ == INVALID_HANDLE_VALUE) return -1;
        applyReadTimeout(timeout_ms);
        pollDriverErrors();
        ::ResetEvent(rd_ev_);
        OVERLAPPED ov{};
        ov.hEvent = rd_ev_;
        DWORD r = 0;
        BOOL ok = ::ReadFile(h_, buf, (DWORD)n, &r, &ov);
        if (!ok && ::GetLastError() == ERROR_IO_PENDING) {
            // The driver enforces the timeout; this wait is a backstop only.
            DWORD wait = ::WaitForSingleObject(ov.hEvent, (DWORD)timeout_ms + 100);
            if (wait == WAIT_OBJECT_0) ok = ::GetOverlappedResult(h_, &ov, &r, FALSE);
            else {
                ::CancelIo(h_);
                return 0;
            }
        }
        return ok ? (int)r : -1;
    }
    bool isOpen() const override { return h_ && h_ != INVALID_HANDLE_VALUE; }
    int setBaud(uint32_t baud) override {
        if (!h_ || h_ == INVALID_HANDLE_VALUE) return -1;
        DCB dcb{}; dcb.DCBlength = sizeof(dcb);
        if (!::GetCommState(h_, &dcb)) return -1;
        dcb.BaudRate = baud;
        if (!::SetCommState(h_, &dcb)) return -2;
        return 0;
    }
    ~WinSerial() { close(); }

private:
    static constexpr DWORD kRxDriverBuf = 1u << 20;  // 1 MB ≈ 3.9 s @ 268.8 KB/s
    static constexpr DWORD kTxDriverBuf = 1u << 16;

    int applyReadTimeout(int timeout_ms) {
        if (timeout_ms == last_read_timeout_ms_) return 0;
        COMMTIMEOUTS to{};
        to.ReadIntervalTimeout         = MAXDWORD;
        to.ReadTotalTimeoutMultiplier  = MAXDWORD;
        to.ReadTotalTimeoutConstant    = (DWORD)(timeout_ms > 0 ? timeout_ms : 1);
        to.WriteTotalTimeoutMultiplier = 0;
        to.WriteTotalTimeoutConstant   = 0;
        if (!::SetCommTimeouts(h_, &to)) return -1;
        last_read_timeout_ms_ = timeout_ms;
        return 0;
    }

    // fAbortOnError is FALSE, so a driver RX overrun never fails a read — the
    // lost bytes just vanish from the stream. Latch and report it (throttled
    // to once per second) so a bench log can tell host-side overrun apart
    // from device-side gaps.
    void pollDriverErrors() {
        auto now = std::chrono::steady_clock::now();
        if (now - last_err_poll_tp_ < std::chrono::seconds(1)) return;
        last_err_poll_tp_ = now;
        DWORD errs = 0;
        if (::ClearCommError(h_, &errs, nullptr) &&
            (errs & (CE_RXOVER | CE_OVERRUN))) {
            char msg[96];
            std::snprintf(msg, sizeof(msg),
                          "[WinSerial] driver RX overrun (CE flags 0x%lx), bytes lost\n",
                          (unsigned long)errs);
            std::fputs(msg, stderr);
        }
    }

    HANDLE h_     = nullptr;
    HANDLE rd_ev_ = nullptr;
    HANDLE wr_ev_ = nullptr;
    uint32_t baud_ = 0;
    int    last_read_timeout_ms_ = -1;
    std::chrono::steady_clock::time_point last_err_poll_tp_{};
};

ISerial* makePlatformSerial() { return new WinSerial(); }

}  // namespace sr18

#endif  // _WIN32
