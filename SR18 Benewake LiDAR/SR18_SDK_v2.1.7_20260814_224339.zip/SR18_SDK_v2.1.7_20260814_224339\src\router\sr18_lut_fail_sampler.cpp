// src/router/sr18_lut_fail_sampler.cpp
#include "sr18_lut_fail_sampler.h"
#include "../../include/sr18_protocol.h"

namespace sr18 {

// ASCII only — these go to stderr, which on Windows lands on a GBK (CP936)
// console by default; UTF-8 bytes would be decoded as GBK and print as mojibake
// (and `chcp 65001` would not help once the log is redirected to a file or
// piped into the host app). Keep the Chinese wording in the docs, not the wire.
const char* lutVerifyStateName(LutVerifyState s) {
    switch (s) {
        case LutVerifyState::UNCONFIRMED: return "UNCONFIRMED (not confirmed)";
        case LutVerifyState::PASSED:      return "PASSED (verify OK)";
        case LutVerifyState::MISMATCH:    return "MISMATCH (content differs)";
        case LutVerifyState::NO_HOST_CRC: return "NO_HOST_CRC (no host CRC word)";
    }
    return "UNKNOWN";
}

void LutWriteFailSampler::arm() {
    std::lock_guard<std::mutex> lk(mu_);
    armed_      = true;
    fresh_      = false;
    last_state_ = LutVerifyState::UNCONFIRMED;
}

void LutWriteFailSampler::onChkSt(uint8_t chk_st, uint8_t d_type,
                                   uint32_t /*rd_reg*/) {
    // LUT bit[5:4] is valid only on an ACK-bearing Status frame. In particular,
    // periodic IMU traffic must not become the first post-arm LUT sample.
    if (d_type != DTYPE_STATUS || (chk_st & 0x04) == 0) return;
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!armed_) return;
        if (fresh_) return;        // first sample since the reset point decides
        fresh_      = true;
        last_state_ = lutVerifyStateOf(chk_st);
    }
    cv_.notify_all();
}

LutVerifyResult LutWriteFailSampler::waitVerify(
        std::chrono::steady_clock::time_point deadline) {
    std::unique_lock<std::mutex> lk(mu_);
    // Wait for the first fresh CHK_ST sample since arm() — the ACK that the
    // probe read-register command solicits. It usually lands during the
    // probe's sendCommand (before we get here); block only for a late rider.
    cv_.wait_until(lk, deadline, [&]{ return fresh_; });
    armed_ = false;
    return LutVerifyResult{ fresh_, last_state_ };
}

}  // namespace sr18
