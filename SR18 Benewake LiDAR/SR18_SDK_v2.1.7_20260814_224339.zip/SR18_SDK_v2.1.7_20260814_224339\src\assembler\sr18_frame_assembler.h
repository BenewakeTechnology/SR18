// src/assembler/sr18_frame_assembler.h
#pragma once
#include "../../include/sr18_common.h"
#include "../../include/sr18_geometry.h"
#include "../codec/sr18_decoder.h"
#include <memory>
#include <cstdint>

namespace sr18 {

// Accumulates PCD packets until an azimuth reset (curr_az < prev_az) is
// observed; emits a BwPointCloud::Ptr at each boundary. out_frame_id is an
// internal monotonic counter (0, 1, 2, ...), independent of wire SEQ.
class FrameAssembler {
public:
    benewake::BwPointCloud::Ptr feed(const DecodedFrame& pcd, int& out_frame_id);

    // Takes the in-flight (not yet boundary-terminated) buffer, or nullptr if
    // empty. Used by ParseRaw for the file's last frame, which has no
    // following packet to trigger the azimuth-reset boundary. Resets state so
    // a subsequent feed() starts a fresh frame. frame_idx_ keeps counting.
    benewake::BwPointCloud::Ptr flush();

    // Clears in-flight buffer and resets counter/state. Call from MDOP stop()
    // so a subsequent start() begins with frame_id = 0 and no stale points.
    void reset();

private:
    benewake::BwPointCloud::Ptr buf_ = std::make_shared<benewake::BwPointCloud>();
    uint16_t prev_az_   = 0;
    bool     started_   = false;
    uint32_t frame_idx_ = 0;
    // geom_gen_ MUST be declared before geom_ so it captures the config
    // generation no later than geom_ snapshots the angles (a change slipping in
    // between only causes one redundant refresh, never a stale one).
    uint64_t geom_gen_ = benewake::channelGeometryGeneration();
    benewake::ChannelGeometry geom_ = benewake::ChannelGeometry::sr18Calibration();

    void appendPoints(const DecodedFrame& pcd);
};

}  // namespace sr18
