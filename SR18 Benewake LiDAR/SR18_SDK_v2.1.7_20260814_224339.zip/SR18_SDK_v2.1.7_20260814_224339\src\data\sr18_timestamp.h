#pragma once

#include <cstdint>

namespace sr18 {

// Normalized wire timestamp: Unix epoch seconds + nanosecond sub-second part.
//
// SR18 wire format (authoritative):
//   TIME_S  : uint8[6] UTC calendar bytes, least-significant unit FIRST:
//             offset 6..11 = [second, minute, hour, day, month, year-1900]
//             (year is the LAST byte at offset 11, second is the first at offset 6;
//              confirmed by consecutive frames incrementing the offset-6 byte)
//   TIME_NS : uint32   sub-second part in MICROSECONDS (0..999999)
//
// This decoder converts the UTC calendar bytes to Unix epoch seconds and the
// microsecond field to nanoseconds (x1000). The conversion is unconditional:
// every frame is interpreted as UTC+microseconds, so the sub-second part is
// always emitted in nanoseconds.
struct NormalizedTimestamp {
    uint64_t time_s = 0;
    uint32_t time_ns = 0;

    uint64_t totalNs() const {
        return time_s * 1000000000ull + time_ns;
    }
};

// Days since 1970-01-01 for a proleptic-Gregorian (year, month, day).
// Howard Hinnant's days_from_civil algorithm.
inline int64_t daysFromCivil(int64_t year, unsigned month, unsigned day) {
    year -= month <= 2 ? 1 : 0;
    const int64_t era = (year >= 0 ? year : year - 399) / 400;
    const unsigned yoe = static_cast<unsigned>(year - era * 400);
    const unsigned doy = (153u * (month + (month > 2 ? -3 : 9)) + 2u) / 5u + day - 1u;
    const unsigned doe = yoe * 365u + yoe / 4u - yoe / 100u + doy;
    return era * 146097 + static_cast<int64_t>(doe) - 719468;
}

inline int64_t utcToUnixSeconds(uint32_t year,
                                uint32_t month,
                                uint32_t day,
                                uint32_t hour,
                                uint32_t minute,
                                uint32_t second) {
    const int64_t days = daysFromCivil(static_cast<int64_t>(year),
                                       static_cast<unsigned>(month),
                                       static_cast<unsigned>(day));
    return days * 86400ll
         + static_cast<int64_t>(hour) * 3600ll
         + static_cast<int64_t>(minute) * 60ll
         + static_cast<int64_t>(second);
}

// Decode TIME_S (6 UTC calendar bytes) + TIME_NS (microseconds) into Unix
// epoch seconds + nanoseconds. Unconditional: there is no integer-second
// fallback, so the sub-second part is always converted us -> ns.
inline NormalizedTimestamp normalizeWireTimestamp(const uint8_t raw_s[6], uint32_t raw_sub_us) {
    //   raw_s[0]=second, [1]=minute, [2]=hour, [3]=day, [4]=month, [5]=year-1900
    const uint32_t second = raw_s[0];
    const uint32_t minute = raw_s[1];
    const uint32_t hour   = raw_s[2];
    const uint32_t day    = raw_s[3];
    const uint32_t month  = raw_s[4];
    const uint32_t year   = 1900u + raw_s[5];

    NormalizedTimestamp out;
    out.time_s  = static_cast<uint64_t>(utcToUnixSeconds(year, month, day, hour, minute, second));
    out.time_ns = raw_sub_us * 1000u;   // microseconds -> nanoseconds
    return out;
}

}  // namespace sr18
