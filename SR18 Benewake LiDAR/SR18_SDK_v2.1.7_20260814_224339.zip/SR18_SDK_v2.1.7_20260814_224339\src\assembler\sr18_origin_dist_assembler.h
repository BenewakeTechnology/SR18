// src/assembler/sr18_origin_dist_assembler.h
#pragma once
#include "../../include/sr18_common.h"
#include "../../include/sr18_geometry.h"
#include "../codec/sr18_decoder.h"
#include <memory>
#include <cstdint>

namespace sr18 {

void setOriginDistDisplayOffsetMeters(float meters);
float originDistDisplayOffsetMeters();

// Accumulates origin_dist (D_TYPE 0x0B) frames until an azimuth reset
// (curr_az < prev_az) is observed; emits a BwPointCloud::Ptr at each
// boundary. For every channel iterates 3 echo slots (echo_0 at offset 4,
// echo_1 at offset 12, echo_2 at offset 20 within the 28B channel block);
// each slot contributes a BwPoint when fram_err==0 and echo_cent != 0.
// Display distance formula: distance_m = echo_cent * 0.15 / 64 - offset_m.
// Raw origin_dist recording/polling keeps the original frame data. Intensity
// fixed at 255 (origin_dist has no PCD-style intensity). BwPoint::echo
// records the slot via bit N (0x01 / 0x02 / 0x04). out_frame_id is an
// internal monotonic counter (0, 1, 2, ...), independent of wire SEQ.
class OriginDistFrameAssembler {
public:
    benewake::BwPointCloud::Ptr feed(const DecodedFrame& od, int& out_frame_id);

    // Takes the in-flight (not yet boundary-terminated) buffer, or nullptr if
    // empty. Used by ParseRaw for the file's last frame, which has no
    // following packet to trigger the azimuth-reset boundary. Resets state so
    // a subsequent feed() starts a fresh frame. frame_idx_ keeps counting.
    benewake::BwPointCloud::Ptr flush();

    void reset();

private:
    benewake::BwPointCloud::Ptr buf_ = std::make_shared<benewake::BwPointCloud>();
    uint16_t prev_az_   = 0;
    bool     started_   = false;
    uint32_t frame_idx_ = 0;
    // See FrameAssembler: geom_gen_ declared before geom_ on purpose.
    uint64_t geom_gen_ = benewake::channelGeometryGeneration();
    benewake::ChannelGeometry geom_ = benewake::ChannelGeometry::sr18Calibration();

    void appendPoints(const DecodedFrame& od);
};

}  // namespace sr18
