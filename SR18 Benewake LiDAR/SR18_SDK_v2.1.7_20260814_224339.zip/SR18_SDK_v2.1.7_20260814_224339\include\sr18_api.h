// include/sr18_api.h
// Cross-platform DLL export/import macro for SR18 SDK public interface.
//
// On Windows, the SDK is built as a DLL: classes/functions visible to
// external consumers MUST be tagged SR18_API. The macro switches between
// dllexport (when building the SDK itself) and dllimport (when a consumer
// includes the headers). On non-Windows, the macro expands to nothing —
// ELF defaults to default visibility.
//
// CMake defines SR18_DLL_EXPORT for the sr18_sdk target only; consumers
// of the headers leave it undefined and pick up dllimport.
#pragma once

#if defined(_WIN32) || defined(__CYGWIN__)
    #ifdef SR18_DLL_EXPORT
        #define SR18_API __declspec(dllexport)
    #else
        #define SR18_API __declspec(dllimport)
    #endif
#else
    #define SR18_API
#endif
