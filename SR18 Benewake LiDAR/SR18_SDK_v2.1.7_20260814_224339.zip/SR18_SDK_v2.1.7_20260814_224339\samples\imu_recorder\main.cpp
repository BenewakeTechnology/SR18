// samples/imu_recorder/main.cpp
//
// Open a serial port, listen for IMU frames, save each one as a CSV row.
// Does NOT call lidar.start() — relies on the device's idle (SLOT_9) stream
// where IMU + Status are emitted as device heartbeat. Useful for hardware
// bring-up when a device is plugged in but no scanning has been requested.
//
// Usage: imu_recorder [port] [seconds] [out_path]
//   port      — e.g. COM8 (Windows) or /dev/ttyUSB0 (Linux). default /dev/ttyUSB0
//   seconds   — record duration. default 5
//   out_path  — CSV output. default imu_log.csv
#include "sr18_lidar_driver.h"
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include <thread>

namespace {
std::atomic<int> g_count{0};

void on_imu(benewake::BW_IMU_INFO imu, void* user) {
    FILE* fp = static_cast<FILE*>(user);
    if (!fp) return;
    std::fprintf(fp,
        "%u,%llu,%u,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n",
        (unsigned)imu.seq,
        (unsigned long long)imu.time_s, (unsigned)imu.time_ns,
        imu.acc_x,  imu.acc_y,  imu.acc_z,
        imu.gyro_x, imu.gyro_y, imu.gyro_z);
    int n = g_count.fetch_add(1, std::memory_order_relaxed) + 1;
    if (n == 1) {
        std::cout << "first IMU frame received: seq=" << imu.seq
                  << " ax=" << imu.acc_x << " ay=" << imu.acc_y
                  << " az=" << imu.acc_z << "\n";
    }
}
}  // namespace

int main(int argc, char** argv) {
    std::string port     = (argc > 1) ? argv[1] : "/dev/ttyUSB0";
    int         seconds  = (argc > 2) ? std::atoi(argv[2]) : 5;
    std::string out_path = (argc > 3) ? argv[3] : "imu_log.csv";

    FILE* fp = std::fopen(out_path.c_str(), "w");
    if (!fp) {
        std::cerr << "fopen " << out_path << " failed\n";
        return 1;
    }
    std::fprintf(fp,
        "seq,time_s,time_ns,"
        "ax_g,ay_g,az_g,gx_rad_s,gy_rad_s,gz_rad_s\n");

    benewake::SR18Lidar lidar(port, 3125000);   // receive-only: no commands sent
    lidar.registIMUDataCallback(on_imu, fp);

    std::cout << "recording IMU from " << port << " for " << seconds
              << "s into " << out_path << " (no start() — SLOT_9 idle stream)...\n";
    std::this_thread::sleep_for(std::chrono::seconds(seconds));

    lidar.cancelIMUDataCallback();
    std::fflush(fp);
    std::fclose(fp);

    int n = g_count.load();
    double rate = (seconds > 0) ? (n / (double)seconds) : 0.0;
    std::cout << "captured " << n << " IMU frames (~" << rate << " Hz)\n";
    return 0;
}
