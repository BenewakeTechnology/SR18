// include/sr18_msg_queue.h
// Thread-safe bounded queue with drop-oldest-on-full semantics.
// Adapted from temp/benewake_lidar_driver-BwLidarDriver.std.10.2.2/include/msg_queue.h.
// Used by MDOPProtocol's async pipeline (rx -> input_queue -> decode_thread -> output queue).
#pragma once
#include <queue>
#include <condition_variable>
#include <mutex>
#include <chrono>
#include <string>

namespace sr18 {

template <class T>
class MsgQueue {
public:
    MsgQueue(std::string queue_name = "msg", int max_size = 512)
        : queue_name_(std::move(queue_name)), max_size_(max_size) {}

    // Push; if queue is full (size == max_size), drop the oldest element.
    void pushMsg(const T& msg) {
        std::unique_lock<std::mutex> lk(mutex_);
        queue_.push(msg);
        if ((int)queue_.size() > max_size_) queue_.pop();
        cv_data_.notify_one();
    }

    // Pop with internal timeout (pop_wait_time_ms_). On timeout, returns a
    // default-constructed T. Prefer tryPopMsg for clean success/timeout signal.
    T popMsg() {
        T data{};
        tryPopMsg(data, pop_wait_time_ms_);
        return data;
    }

    // Try to pop with explicit timeout. Returns true if `out` was filled,
    // false on timeout. Preferred entry point for callers that need to
    // distinguish "got data" from "timed out".
    bool tryPopMsg(T& out, int timeout_ms) {
        std::unique_lock<std::mutex> lk(mutex_);
        if (queue_.empty()) {
            cv_data_.wait_for(lk, std::chrono::milliseconds(timeout_ms),
                              [this]{ return !queue_.empty(); });
            if (queue_.empty()) return false;
        }
        out = queue_.front();
        queue_.pop();
        return true;
    }

    void clear() {
        std::unique_lock<std::mutex> lk(mutex_);
        std::queue<T> empty;
        std::swap(queue_, empty);
    }

    bool empty() {
        std::unique_lock<std::mutex> lk(mutex_);
        return queue_.empty();
    }

    int size() {
        std::unique_lock<std::mutex> lk(mutex_);
        return (int)queue_.size();
    }

    void setPopWaitTime(int ms) {
        std::unique_lock<std::mutex> lk(mutex_);
        pop_wait_time_ms_ = ms;
    }

private:
    std::queue<T>           queue_;
    std::condition_variable cv_data_;
    std::mutex              mutex_;
    std::string             queue_name_;
    int                     max_size_;
    int                     pop_wait_time_ms_ = 1000;
};

}  // namespace sr18
