// src/data/sr18_adc_convert.h
#pragma once
#include <cstdint>
#include "sr18_api.h"

namespace sr18 {

// Per-channel ADC conversion. Currently identity for all 8 channels — replace
// individual entries when the protocol team provides physical formulas. Each
// function takes the 12-bit raw count (0..4095) and returns the converted
// value in the channel's documented unit.
using AdcConvertFn = uint16_t(*)(uint16_t raw);

extern SR18_API const AdcConvertFn kAdcConvert[8];

}  // namespace sr18
