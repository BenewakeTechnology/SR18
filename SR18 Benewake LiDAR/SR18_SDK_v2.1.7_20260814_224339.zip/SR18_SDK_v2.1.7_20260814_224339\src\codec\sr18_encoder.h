// src/codec/sr18_encoder.h
#pragma once
#include "../../include/sr18_protocol.h"
#include <cstdint>
#include <vector>

namespace sr18 {

// Encode a downstream frame:
//   STX(2 LE) | TC(1) | SEQ(1) | LEN(2 LE) | payload | CRC32-MPEG2-LE(4)
// All multi-byte numeric fields are serialised LSB-first (little-endian) on the
// wire — the SR18 device expects this. The PAYLOAD is opaque to the encoder;
// callers are responsible for laying out per-TC payload bytes (also LE for any
// multi-byte numeric inside, see sr18_dcsp_payload.cpp).
// CRC is computed (MPEG-2 variant) over [STX..payload]. Frame overhead = 10 bytes.
// out is cleared and then filled with the encoded frame bytes.
void encode_downstream(TC tc, uint8_t seq,
                       const uint8_t* payload, size_t payload_len,
                       std::vector<uint8_t>& out);

}  // namespace sr18
