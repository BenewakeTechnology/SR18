// src/router/sr18_rd_reg_sampler.cpp
#include "sr18_rd_reg_sampler.h"
#include "../../include/sr18_protocol.h"

namespace sr18 {

void ChkStRdRegSampler::arm(int target_n) {
    std::lock_guard<std::mutex> lk(mu_);
    armed_      = true;
    target_n_   = target_n;
    collected_  = 0;
    last_value_ = 0;
}

void ChkStRdRegSampler::onChkSt(uint8_t /*chk_st*/, uint8_t d_type,
                                 uint32_t rd_reg) {
    if (d_type != DTYPE_PCD &&
        d_type != DTYPE_STATUS &&
        d_type != DTYPE_ORIGIN_DIST) {
        return;
    }
    bool fire = false;
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!armed_) return;
        last_value_ = rd_reg;
        ++collected_;
        if (collected_ >= target_n_) fire = true;
    }
    if (fire) cv_.notify_all();
}

bool ChkStRdRegSampler::collect(uint32_t& value_out,
                                 std::chrono::steady_clock::time_point deadline) {
    std::unique_lock<std::mutex> lk(mu_);
    cv_.wait_until(lk, deadline,
                   [&]{ return collected_ >= target_n_; });
    armed_ = false;
    if (collected_ == 0) return false;
    value_out = last_value_;
    return true;
}

}  // namespace sr18
