// src/codec/sr18_decoder.cpp
#include "sr18_decoder.h"
#include "sr18_crc.h"
#include <cstdio>
#include <cstring>
#include <iostream>

namespace sr18 {

namespace {
// Upper bound on an $LDACK frame; anything larger means a false '$' sync.
// The largest valid ACK is the 99-byte read-angle-file PKT_CMD33 (Len 0x50).
constexpr size_t kAsciiMaxFrame = 99;

// Returns total frame length for known D_TYPE, or 0 for unknown.
size_t frameLenFor(uint8_t d_type) {
    switch (d_type) {
        case DTYPE_PCD:    return PCD_FRAME_LEN;
        case DTYPE_IMU:    return IMU_FRAME_LEN;
        case DTYPE_ORIGIN_DIST: return ORIGIN_DIST_FRAME_LEN;
        case DTYPE_STATUS: return STATUS_FRAME_LEN;
        default:           return 0;
    }
}

// CRC validation. The CRC trailer is little-endian on wire (low byte first).
// IMU's 30-byte body is ALWAYS zero-padded to 32 before CRC (it predates and is
// independent of the align4 switch). Every other frame follows crc32_wire():
// align4 when SR18_CRC_ALIGN4 is on (b1 PCD 83->84, origin_dist 533->536), raw
// body otherwise. Status(16) is already 4-aligned, so the switch is a no-op there.
bool crcValid(uint8_t d_type, const uint8_t* frame, size_t total_len) {
    size_t body_len = total_len - 4;       // exclude CRC trailer
    uint32_t got =  (uint32_t)frame[total_len - 4]
                 | ((uint32_t)frame[total_len - 3] <<  8)
                 | ((uint32_t)frame[total_len - 2] << 16)
                 | ((uint32_t)frame[total_len - 1] << 24);
    if (d_type == DTYPE_IMU) return crc32_mpeg2_align4(frame, body_len) == got;
    return crc32_wire(frame, body_len) == got;
}
}  // namespace

UpstreamDecoder::UpstreamDecoder(FrameCallback on_frame)
    : on_frame_(std::move(on_frame)) {}

void UpstreamDecoder::reset() {
    state_ = State::IDLE;
    buf_.clear();
    need_  = 0;
    // Cumulative stats (frames_emitted_, frames_dropped_, total_fed_) are
    // intentionally preserved — only the in-progress frame state is cleared.
}

void UpstreamDecoder::resyncDropFirstByte() {
    if (!buf_.empty()) {
        buf_.erase(buf_.begin());
        ++buf_start_offset_;
    }
    state_ = State::IDLE;
    need_  = 0;
    // Re-process leftover bytes at their original offsets (do NOT bump total_fed_)
    if (!buf_.empty()) {
        std::vector<uint8_t> stash = std::move(buf_);
        uint64_t stash_base = buf_start_offset_;
        buf_.clear();
        feedSpan(stash.data(), stash.size(), stash_base);
    }
}

void UpstreamDecoder::feed(const uint8_t* data, size_t n) {
    uint64_t base = total_fed_;
    total_fed_ += n;
    feedSpan(data, n, base);
}

void UpstreamDecoder::feedSpan(const uint8_t* data, size_t n, uint64_t base) {
    // Upstream STX 0xFFEE is little-endian on wire: byte0 = 0xEE, byte1 = 0xFF.
    for (size_t i = 0; i < n; ++i) {
        uint8_t b = data[i];
        switch (state_) {
            case State::IDLE:
                if (b == 0xEE) {
                    buf_.clear();
                    buf_.push_back(b);
                    buf_start_offset_ = base + i;
                    state_ = State::GOT_STX0;
                } else if (b == 0x24) {           // '$' — possible $LDACK
                    buf_.clear();
                    buf_.push_back(b);
                    buf_start_offset_ = base + i;
                    state_ = State::ASCII_HDR;
                    need_  = 7;                    // L D A C K , + Len
                }
                break;
            case State::GOT_STX0:
                if (b == 0xFF) {
                    buf_.push_back(b);
                    state_ = State::HEADER;
                    need_  = 4;          // up_ver + dw_ver + chk_st + d_type
                } else if (b == 0xDD) {  // EE DD — independent fault frame
                    buf_.push_back(b);
                    state_ = State::FAULT_BODY;
                    need_  = kFaultFrameLen - 2;   // 41 total, 2 already in buf_
                } else {
                    // Not STX; if 0xEE start over from this byte
                    state_ = (b == 0xEE) ? State::GOT_STX0 : State::IDLE;
                    buf_.clear();
                    if (state_ == State::GOT_STX0) {
                        buf_.push_back(b);
                        buf_start_offset_ = base + i;
                    }
                }
                break;
            case State::HEADER:
                buf_.push_back(b);
                if (--need_ == 0) {
                    uint8_t d_type = buf_[5];
                    size_t total = frameLenFor(d_type);
                    if (total == 0) {
                        ++frames_dropped_;
                        resyncDropFirstByte();
                    } else {
                        state_ = State::BODY;
                        need_  = total - buf_.size();
                    }
                }
                break;
            case State::BODY:
                buf_.push_back(b);
                if (--need_ == 0) {
                    uint8_t d_type = buf_[5];
                    if (crcValid(d_type, buf_.data(), buf_.size())) {
                        DecodedFrame df;
                        df.d_type = d_type;
                        df.chk_st = buf_[4];
                        df.up_ver = buf_[2];
                        df.dw_ver = buf_[3];
                        df.full        = buf_.data();
                        df.full_len    = buf_.size();
                        df.stream_offset = buf_start_offset_;
                        ++frames_emitted_;
                        on_frame_(df);
                        buf_.clear();
                        state_ = State::IDLE;
                    } else {
                        ++frames_dropped_;
                        ++crc_drops_since_log_;
                        // Throttle: log at most once per second, summarising
                        // the count accumulated since the previous log line.
                        // First-ever drop logs immediately because
                        // crc_last_log_tp_ is default-initialised to epoch.
                        auto now = std::chrono::steady_clock::now();
                        if (now - crc_last_log_tp_ >= std::chrono::seconds(1)) {
                            // Pre-format and insert in ONE shot so the line
                            // stays intact when other threads (SDK or host
                            // app) write stderr concurrently.
                            char msg[64];
                            std::snprintf(msg, sizeof(msg),
                                          "[Decoder] CRC error: %u frames dropped\n",
                                          (unsigned)crc_drops_since_log_);
                            std::cerr << msg;
                            crc_drops_since_log_ = 0;
                            crc_last_log_tp_     = now;
                        }
                        resyncDropFirstByte();
                    }
                }
                break;
            case State::ASCII_HDR:
                buf_.push_back(b);
                if (--need_ == 0) {
                    // buf_ now holds 7 header bytes + 1 Len byte. Two headers are
                    // valid: $LDACK, (command-family ACK) and $LDANG, (dedicated
                    // read-angle-file reply, PKT_CMD33).
                    static const uint8_t kAckHdr[7] =
                        {0x24,0x4C,0x44,0x41,0x43,0x4B,0x2C};
                    static const uint8_t kAngHdr[7] =
                        {0x24,0x4C,0x44,0x41,0x4E,0x47,0x2C};
                    bool hdr_ok = std::memcmp(buf_.data(), kAckHdr, 7) == 0 ||
                                  std::memcmp(buf_.data(), kAngHdr, 7) == 0;
                    uint8_t len_field = buf_[7];
                    size_t total = ascii_ack_total_len(len_field);
                    if (!hdr_ok ||
                        total > kAsciiMaxFrame || total <= buf_.size()) {
                        ++frames_dropped_;
                        resyncDropFirstByte();
                    } else {
                        state_ = State::ASCII_BODY;
                        need_  = total - buf_.size();
                    }
                }
                break;
            case State::FAULT_BODY:
                buf_.push_back(b);
                if (--need_ == 0) {
                    FaultFrame ff;
                    if (parse_fault_frame(buf_.data(), buf_.size(), ff)) {
                        // Fault frames are telemetry-independent; like ASCII acks
                        // they are NOT counted in frames_emitted_.
                        if (on_fault_) on_fault_(ff);
                        buf_.clear();
                        state_ = State::IDLE;
                    } else {
                        ++frames_dropped_;
                        resyncDropFirstByte();
                    }
                }
                break;
            case State::ASCII_BODY:
                buf_.push_back(b);
                if (--need_ == 0) {
                    // $LDANG, header = read-angle-file PKT_CMD33 (99B, Len 0x50).
                    // Its header and field layout differ from the $LDACK,
                    // command-family ACK, so it routes to a dedicated parser +
                    // callback.
                    static const uint8_t kAngHdr[7] =
                        {0x24,0x4C,0x44,0x41,0x4E,0x47,0x2C};
                    if (std::memcmp(buf_.data(), kAngHdr, 7) == 0) {
                        AsciiAngleFile af;
                        if (parse_ascii_angle_ack(buf_.data(), buf_.size(), af)) {
                            if (on_ascii_angle_) on_ascii_angle_(af);
                            buf_.clear();
                            state_ = State::IDLE;
                        } else {
                            ++frames_dropped_;
                            resyncDropFirstByte();
                        }
                        break;
                    }
                    AsciiAck ack;
                    if (parse_ascii_ack(buf_.data(), buf_.size(), ack)) {
                        // ASCII acks are intentionally NOT counted in
                        // frames_emitted_ (kept binary-telemetry-only for
                        // RxRouter/tests); ack count is observable via callback.
                        if (on_ascii_ack_) on_ascii_ack_(ack);
                        buf_.clear();
                        state_ = State::IDLE;
                    } else {
                        ++frames_dropped_;
                        resyncDropFirstByte();
                    }
                }
                break;
        }
    }
}

}  // namespace sr18
