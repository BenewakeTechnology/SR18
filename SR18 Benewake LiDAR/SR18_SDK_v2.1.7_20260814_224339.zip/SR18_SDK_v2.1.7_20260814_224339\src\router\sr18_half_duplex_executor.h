// src/router/sr18_half_duplex_executor.h
#pragma once
#include "sr18_command_executor.h"
#include "sr18_device_state.h"
#include "../transport/sr18_serial.h"
#include <mutex>

namespace sr18 { class AsciiAckMatcher; class AsciiAngleMatcher; }

namespace sr18 {

// Executes a single downstream frame: arm monitor → serial.write → wait
// for completion edge. The wire is no longer half-duplex (TX has its own
// dedicated 9600 line); the name is retained for include-stability and
// reflects the arm/write/wait sequencing rather than the wire topology.
class HalfDuplexExecutor : public ICommandExecutor {
public:
    HalfDuplexExecutor(ISerial*             serial,
                       IDeviceStateMonitor* monitor,
                       AsciiAckMatcher*     ascii_matcher = nullptr,
                       AsciiAngleMatcher*   angle_matcher = nullptr);

    Result execute(const uint8_t* frame, std::size_t len,
                   bool need_rd_reg,
                   std::chrono::milliseconds timeout) override;

    AsciiResult executeAscii(const uint8_t* frame, std::size_t len,
                             uint8_t expect_cmd_id, uint32_t expect_check_id,
                             std::chrono::milliseconds timeout) override;

    AsciiAngleResult executeAsciiAngle(const uint8_t* frame, std::size_t len,
                                       uint32_t expect_check_id,
                                       std::chrono::milliseconds timeout) override;

private:
    ISerial*             serial_;
    IDeviceStateMonitor* monitor_;
    AsciiAckMatcher*     ascii_matcher_;
    AsciiAngleMatcher*   angle_matcher_;
    std::mutex           exec_mu_;
};

}  // namespace sr18
