// src/router/sr18_lut_fail_sampler.h
#pragma once
#include "sr18_device_state.h"      // for IChkStObserver
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <mutex>

namespace sr18 {

// LUT verify state carried in CHK_ST bit[5:4] (bit5 = MSB, bit4 = LSB). One bit
// (bit[5]) could not tell "not confirmed yet" from "verified & failed"; the two
// bits are decided at the device's S_LUT_CRC settle phase. PASSED (01) is the
// ONLY success signal — every other value means the write is not confirmed and
// the caller must retransmit (retransmission is left to the caller).
enum class LutVerifyState : uint8_t {
    UNCONFIRMED = 0x0,  // 00 未确认: verify 没跑到结算/末包没到/包不连续/还在读 flash/未启动
    PASSED      = 0x1,  // 01 校验通过: flash 实读 CRC == host CRC 尾字（唯一成功信号）
    MISMATCH    = 0x2,  // 10 校验失败-内容不符: 捕获 host CRC 但实读 CRC ≠ 期望
    NO_HOST_CRC = 0x3,  // 11 校验跳过-无host CRC: 未捕获尾字 (lut_has_crc_word=0)
};

// Human-readable name for logging the final status code.
const char* lutVerifyStateName(LutVerifyState s);

// Decode CHK_ST bit[5:4] into a LutVerifyState.
inline LutVerifyState lutVerifyStateOf(uint8_t chk_st) {
    return static_cast<LutVerifyState>((chk_st >> 4) & 0x03);
}

// Result of soliciting the post-settle CHK_ST.
struct LutVerifyResult {
    bool           sampled = false;                     // a fresh CHK_ST landed by deadline
    LutVerifyState state   = LutVerifyState::UNCONFIRMED;  // bit[5:4]; valid iff sampled
};

// Pure interface — DCSP depends on this, not the concrete class.
class ILutFailWatcher {
public:
    virtual ~ILutFailWatcher() = default;
    virtual void arm() = 0;                        // reset before each verify
    // Block until the first fresh CHK_ST sample lands or `deadline`, then report
    // its bit[5:4] LutVerifyState (sampled=false if none arrived by deadline).
    // Call arm() AFTER the post-upload settle and right before actively
    // soliciting the sample (the ACK to a read-register probe); the device
    // rides the fresh bit[5:4] back on that ACK (real-machine 2026-07-24).
    virtual LutVerifyResult waitVerify(
        std::chrono::steady_clock::time_point deadline) = 0;
};

// Watches valid Status-frame CHK_ST for bit[5:4] = LUT verify state. IMU is not
// a LUT-state carrier and must not consume the first post-arm sample.
class LutWriteFailSampler : public ILutFailWatcher, public IChkStObserver {
public:
    LutWriteFailSampler() = default;
    void arm() override;
    LutVerifyResult waitVerify(
        std::chrono::steady_clock::time_point deadline) override;
    void onChkSt(uint8_t chk_st, uint8_t d_type, uint32_t rd_reg) override;
private:
    std::mutex              mu_;
    std::condition_variable cv_;
    bool           armed_      = false;
    bool           fresh_      = false;   // a sample landed since the last reset point
    LutVerifyState last_state_ = LutVerifyState::UNCONFIRMED;  // bit[5:4] of that sample
};

}  // namespace sr18
