// src/transport/sr18_serial_posix.cpp
#ifndef _WIN32
#include "sr18_serial.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/select.h>
#include <cerrno>
#include <cstring>

#ifdef __linux__
// Linux: termios2 + BOTHER programs an *arbitrary* integer baud — notably the
// SR18 host UART's 3.125 Mbps — which the fixed termios speed_t (Bxxxx) enum
// cannot express (it jumps 3000000 -> 3500000, with no 3125000). asm/termbits.h
// supplies struct termios2, BOTHER, IBSHIFT and every c_*flag bit; it must NOT
// be combined with glibc <termios.h> in one translation unit (both define
// struct termios). TCGETS2/TCSETS2 come from <sys/ioctl.h>.
#include <asm/termbits.h>
#include <sys/ioctl.h>
#else
#include <termios.h>
#endif

namespace sr18 {

#ifdef __linux__
// Configure raw 8N1 at an arbitrary baud via termios2/BOTHER. Returns 0 or -errno.
static int configurePort(int fd, uint32_t baud) {
    struct termios2 tio{};
    if (ioctl(fd, TCGETS2, &tio) != 0) return -errno;
    // Raw mode (equivalent to cfmakeraw): no input/output processing, no echo.
    tio.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tio.c_oflag &= ~OPOST;
    tio.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    // 8 data bits, no parity, 1 stop bit; ignore modem lines; receiver on.
    tio.c_cflag &= ~(CSIZE | PARENB | CSTOPB);
    tio.c_cflag |= (CS8 | CLOCAL | CREAD);
    // Arbitrary baud: select BOTHER on both the output and input speed fields,
    // then write the integer rate into c_ospeed/c_ispeed.
    tio.c_cflag &= ~(CBAUD | CIBAUD);
    tio.c_cflag |= BOTHER | (BOTHER << IBSHIFT);
    tio.c_ospeed = baud;
    tio.c_ispeed = baud;
    tio.c_cc[VMIN]  = 0;
    tio.c_cc[VTIME] = 0;
    return (ioctl(fd, TCSETS2, &tio) != 0) ? -errno : 0;
}
#else
// Non-Linux POSIX (macOS/BSD): no termios2, so only the fixed speed_t enum is
// reachable here; non-standard rates such as 3.125 Mbps return -EINVAL. (The
// SR18 is driven on Linux/Windows; this path exists only to keep such builds
// compiling.)
static speed_t speedFor(uint32_t baud) {
    switch (baud) {
        case 9600:    return B9600;
        case 19200:   return B19200;
        case 38400:   return B38400;
        case 57600:   return B57600;
        case 115200:  return B115200;
        case 230400:  return B230400;
        case 460800:  return B460800;
        case 921600:  return B921600;
#ifdef B1000000
        case 1000000: return B1000000;
#endif
#ifdef B2000000
        case 2000000: return B2000000;
#endif
#ifdef B3000000
        case 3000000: return B3000000;
#endif
        default:      return B0;
    }
}
static int configurePort(int fd, uint32_t baud) {
    termios tio{};
    if (tcgetattr(fd, &tio) != 0) return -errno;
    cfmakeraw(&tio);
    speed_t s = speedFor(baud);
    if (s == B0) return -EINVAL;
    cfsetispeed(&tio, s);
    cfsetospeed(&tio, s);
    tio.c_cflag |= (CLOCAL | CREAD);
    tio.c_cflag &= ~CSTOPB;
    tio.c_cflag &= ~PARENB;
    tio.c_cflag &= ~CSIZE;
    tio.c_cflag |= CS8;
    tio.c_cc[VMIN]  = 0;
    tio.c_cc[VTIME] = 0;
    return (tcsetattr(fd, TCSANOW, &tio) != 0) ? -errno : 0;
}
#endif

class PosixSerial : public ISerial {
public:
    int open(const std::string& port, uint32_t baud) override {
        close();
        fd_ = ::open(port.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);
        if (fd_ < 0) return -errno;
        int rc = configurePort(fd_, baud);
        if (rc != 0) { close(); return rc; }
        return 0;
    }
    void close() override {
        if (fd_ >= 0) { ::close(fd_); fd_ = -1; }
    }
    int write(const uint8_t* buf, size_t n) override {
        if (fd_ < 0) return -1;
        ssize_t w = ::write(fd_, buf, n);
        return (w < 0) ? -errno : (int)w;
    }
    int read(uint8_t* buf, size_t n, int timeout_ms) override {
        if (fd_ < 0) return -1;
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(fd_, &rfds);
        timeval tv;
        tv.tv_sec  = timeout_ms / 1000;
        tv.tv_usec = (timeout_ms % 1000) * 1000;
        int s = ::select(fd_ + 1, &rfds, nullptr, nullptr, &tv);
        if (s == 0)  return 0;
        if (s < 0)   return -errno;
        ssize_t r = ::read(fd_, buf, n);
        return (r < 0) ? -errno : (int)r;
    }
    bool isOpen() const override { return fd_ >= 0; }
    int setBaud(uint32_t baud) override {
        if (fd_ < 0) return -1;
        // Re-program speed on the live fd. The OTA layer drains residual bytes
        // around the switch (read-and-discard); we deliberately avoid tcflush
        // here so this TU stays free of <termios.h> (it uses asm/termbits.h on
        // Linux, which must not be combined with glibc termios).
        return configurePort(fd_, baud);
    }
    ~PosixSerial() { close(); }

private:
    int fd_ = -1;
};

ISerial* makePlatformSerial() { return new PosixSerial(); }

}  // namespace sr18

#endif  // !_WIN32
