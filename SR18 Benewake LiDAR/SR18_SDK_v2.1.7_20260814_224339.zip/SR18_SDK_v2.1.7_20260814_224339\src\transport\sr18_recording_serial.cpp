// src/transport/sr18_recording_serial.cpp
#include "sr18_recording_serial.h"
#include <iostream>
#include <string>

namespace sr18 {

RecordingSerial::RecordingSerial(std::unique_ptr<ISerial> inner,
                                 size_t queue_capacity)
    : inner_(std::move(inner)),
      queue_cap_(queue_capacity),
      queue_("raw_record", (int)(queue_capacity > 0 ? queue_capacity : 1)) {}

RecordingSerial::~RecordingSerial() {
    stopRecord();
}

int RecordingSerial::open(const std::string& port, uint32_t baud) {
    return inner_ ? inner_->open(port, baud) : -1;
}

void RecordingSerial::close() {
    stopRecord();
    if (inner_) inner_->close();
}

int RecordingSerial::write(const uint8_t* buf, size_t n) {
    return inner_ ? inner_->write(buf, n) : -1;
}

bool RecordingSerial::isOpen() const {
    return inner_ && inner_->isOpen();
}

int RecordingSerial::setBaud(uint32_t baud) { return inner_ ? inner_->setBaud(baud) : -1; }

int RecordingSerial::read(uint8_t* buf, size_t n, int timeout_ms) {
    int got = inner_ ? inner_->read(buf, n, timeout_ms) : -1;
    if (got > 0 && recording_.load(std::memory_order_acquire)) {
        // Tee a copy into the bounded queue. Detect the full condition ourselves
        // so the drop is counted and the file gap is explainable.
        // queue_cap_ == 0 means zero-capacity intent: always drop.
        bool full = (queue_cap_ == 0) ||
                    ((size_t)queue_.size() >= queue_cap_);
        if (full) {
            chunks_dropped_.fetch_add(1, std::memory_order_relaxed);
            ++drops_since_log_;
            auto now = std::chrono::steady_clock::now();
            if (now - last_drop_log_ >= std::chrono::seconds(1)) {
                std::string line = "[RecordingSerial] " +
                    std::to_string(drops_since_log_) +
                    " record chunks dropped (writer too slow)\n";
                std::cerr << line;       // single insertion: no torn lines
                drops_since_log_ = 0;
                last_drop_log_ = now;
            }
        } else {
            queue_.pushMsg(std::vector<uint8_t>(buf, buf + got));
        }
    }
    return got;
}

bool RecordingSerial::startRecord(const std::string& path) {
    std::lock_guard<std::mutex> lk(rec_mu_);
    // Open the NEW file first; only stop the current recording if it succeeds
    // so a failed restart leaves the previous recording untouched.
    std::FILE* f = nullptr;
#ifdef _WIN32
    if (fopen_s(&f, path.c_str(), "wb") != 0) f = nullptr;
#else
    f = std::fopen(path.c_str(), "wb");
#endif
    if (!f) {
        std::cerr << "[RecordingSerial] cannot open record file: " << path << "\n";
        return false;
    }
    stopRecordLocked();                          // safe: new file already open
    file_ = f;
    queue_.clear();
    bytes_recorded_.store(0, std::memory_order_relaxed);
    chunks_dropped_.store(0, std::memory_order_relaxed);
    drops_since_log_ = 0;
    last_drop_log_ = {};
    writer_run_.store(true, std::memory_order_release);
    writer_ = std::thread(&RecordingSerial::writerLoop, this);
    recording_.store(true, std::memory_order_release);
    return true;
}

void RecordingSerial::stopRecord() {
    std::lock_guard<std::mutex> lk(rec_mu_);
    stopRecordLocked();
}

void RecordingSerial::stopRecordLocked() {
    if (!recording_.load(std::memory_order_acquire) && !writer_.joinable()) return;
    recording_.store(false, std::memory_order_release);   // read() stops teeing
    writer_run_.store(false, std::memory_order_release);  // writer drains then exits
    if (writer_.joinable()) writer_.join();
    if (file_) {
        std::fclose(file_);
        file_ = nullptr;
    }
}

void RecordingSerial::writerLoop() {
    std::vector<uint8_t> chunk;
    auto writeChunk = [&](const std::vector<uint8_t>& c) {
        if (file_ && !c.empty()) {
            size_t w = std::fwrite(c.data(), 1, c.size(), file_);
            bytes_recorded_.fetch_add((uint64_t)w, std::memory_order_relaxed);
            if (w < c.size()) {
                // Disk full / IO error: count is honest (bytes_recorded_ only
                // grows by what landed); log once so a truncated dump is
                // explainable, then stop trying.
                std::cerr << "[RecordingSerial] write error: file truncated\n";
                std::fclose(file_);
                file_ = nullptr;
            }
        }
    };
    for (;;) {
        if (queue_.tryPopMsg(chunk, 50)) {
            writeChunk(chunk);
        } else if (!writer_run_.load(std::memory_order_acquire)) {
            // Stop requested and the timed pop came back empty. A producer may
            // have pushed between that timeout and this check: final
            // non-blocking drain so no pre-stop chunk is lost.
            while (queue_.tryPopMsg(chunk, 0)) writeChunk(chunk);
            break;
        }
    }
    if (file_) std::fflush(file_);
}

}  // namespace sr18
