// src/router/sr18_ascii_ack_matcher.cpp
#include "sr18_ascii_ack_matcher.h"

namespace sr18 {

void AsciiAckMatcher::arm(uint8_t expect_cmd_id, uint32_t expect_check_id) {
    std::lock_guard<std::mutex> lk(mu_);
    armed_           = true;
    hit_             = false;
    expect_cmd_id_   = expect_cmd_id;
    expect_check_id_ = expect_check_id;
    err_             = 0;
    cmd_data_        = 0;
}

void AsciiAckMatcher::onAsciiAck(const AsciiAck& ack) {
    bool fire = false;
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!armed_ || hit_) return;
        if (ack.cmd_id != expect_cmd_id_ || ack.check_id != expect_check_id_) return;
        hit_      = true;
        err_      = ack.err;
        cmd_data_ = ack.cmd_data;
        fire      = true;
    }
    if (fire) cv_.notify_all();
}

AsciiAckMatcher::Result AsciiAckMatcher::wait(
    std::chrono::steady_clock::time_point deadline) {
    std::unique_lock<std::mutex> lk(mu_);
    if (!cv_.wait_until(lk, deadline, [&]{ return hit_; })) {
        armed_ = false;
        return Result{Status::TIMEOUT, 0, 0};
    }
    armed_ = false;
    return Result{Status::OK, err_, cmd_data_};
}

void AsciiAngleMatcher::arm(uint32_t expect_check_id) {
    std::lock_guard<std::mutex> lk(mu_);
    armed_           = true;
    hit_             = false;
    aborted_         = false;
    expect_check_id_ = expect_check_id;
    file_            = AsciiAngleFile{};
}

void AsciiAngleMatcher::abort() {
    {
        std::lock_guard<std::mutex> lk(mu_);
        aborted_ = true;
    }
    cv_.notify_all();
}

void AsciiAngleMatcher::onAsciiAngle(const AsciiAngleFile& file) {
    bool fire = false;
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!armed_ || hit_) return;
        if (file.check_id != expect_check_id_) return;
        hit_  = true;
        file_ = file;
        fire  = true;
    }
    if (fire) cv_.notify_all();
}

AsciiAngleMatcher::Result AsciiAngleMatcher::wait(
    std::chrono::steady_clock::time_point deadline) {
    std::unique_lock<std::mutex> lk(mu_);
    if (!cv_.wait_until(lk, deadline, [&]{ return hit_ || aborted_; }) || !hit_) {
        armed_ = false;
        return Result{Status::TIMEOUT, AsciiAngleFile{}};
    }
    armed_ = false;
    return Result{Status::OK, file_};
}

}  // namespace sr18
