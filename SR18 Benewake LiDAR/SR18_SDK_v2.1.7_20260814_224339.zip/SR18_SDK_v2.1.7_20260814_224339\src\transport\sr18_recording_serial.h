// src/transport/sr18_recording_serial.h
// ISerial decorator: passes everything through to the wrapped serial and,
// when recording is enabled, tees the bytes returned by read() into a bounded
// queue drained by a dedicated writer thread (raw bytes, no framing/headers).
//
// The reading thread NEVER touches the disk: a disk stall (Windows AV scan,
// spinning disk flush) cannot stall the rx thread and trigger driver-level
// RX overruns (see the 2026-06-10 WinSerial fix). Queue-full drops the chunk
// (counted + throttled stderr warning) instead of blocking.
//
// Threading: read() is called from RxRouter's rx thread only (single-rx-thread
// design) and synchronizes with start/stop solely via the recording_ atomic —
// it never takes rec_mu_. A read() that loads recording_==true while stop runs
// may push one orphan chunk after the writer exits; that chunk sits in the
// bounded queue and is wiped by queue_.clear() on the next startRecord, so it
// can never leak into a file. startRecord/stopRecord serialize against each
// other via rec_mu_; file_ is handed to the writer thread before it starts and
// reclaimed after join(), so it needs no lock.
#pragma once
#include "sr18_serial.h"
#include "../../include/sr18_msg_queue.h"
#include <atomic>
#include <chrono>
#include <cstdio>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>

namespace sr18 {

class RecordingSerial : public ISerial {
public:
    // queue_capacity: max buffered chunks before drops; default sized for
    // ~268.8 KB/s live stream with seconds of disk-stall headroom. Tests use
    // 0 to deterministically exercise the drop path.
    explicit RecordingSerial(std::unique_ptr<ISerial> inner,
                             size_t queue_capacity = 1024);
    ~RecordingSerial() override;

    // ISerial pass-through
    int  open(const std::string& port, uint32_t baud) override;
    void close() override;                  // stops recording first
    int  write(const uint8_t* buf, size_t n) override;
    int  read(uint8_t* buf, size_t n, int timeout_ms) override;
    bool isOpen() const override;
    int  setBaud(uint32_t baud) override;

    // Recording control (thread-safe; restart with a new path = open new file
    // first; on failure the current recording continues unchanged)
    bool startRecord(const std::string& path);
    void stopRecord();
    bool     isRecording() const { return recording_.load(std::memory_order_acquire); }
    uint64_t bytesRecorded() const { return bytes_recorded_.load(std::memory_order_relaxed); }
    uint64_t chunksDropped() const { return chunks_dropped_.load(std::memory_order_relaxed); }

private:
    std::unique_ptr<ISerial> inner_;

    std::atomic<bool>     recording_{false};
    std::atomic<uint64_t> bytes_recorded_{0};
    std::atomic<uint64_t> chunks_dropped_{0};

    std::mutex            rec_mu_;       // guards start/stop + file_/writer_ lifecycle
    std::FILE*            file_ = nullptr;
    std::thread           writer_;
    std::atomic<bool>     writer_run_{false};
    size_t                queue_cap_;
    MsgQueue<std::vector<uint8_t>> queue_;

    // Throttle for queue-full warnings (at most one line per second).
    std::chrono::steady_clock::time_point last_drop_log_{};
    uint64_t drops_since_log_ = 0;

    void writerLoop();
    void stopRecordLocked();             // caller holds rec_mu_
};

}  // namespace sr18
