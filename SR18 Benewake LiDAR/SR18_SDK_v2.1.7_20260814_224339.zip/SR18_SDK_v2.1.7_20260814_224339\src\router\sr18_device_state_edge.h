// src/router/sr18_device_state_edge.h
#pragma once
#include "sr18_device_state.h"
#include <condition_variable>
#include <mutex>

namespace sr18 {

class EdgeDetectingMonitor : public IDeviceStateMonitor,
                              public IChkStObserver {
public:
    EdgeDetectingMonitor() = default;

    // IDeviceStateMonitor
    void armForCompletion() override;
    Result waitForCompletion(std::chrono::steady_clock::time_point deadline,
                             bool need_rd_reg) override;

    // IChkStObserver
    void onChkSt(uint8_t chk_st, uint8_t d_type, uint32_t rd_reg) override;

private:
    std::mutex              mu_;
    std::condition_variable cv_;

    bool      armed_         = false;
    bool      done_observed_ = false;
    bool      crc_observed_  = false;
    uint8_t   done_d_type_   = 0;
    uint32_t  done_rd_reg_   = 0;
};

}  // namespace sr18
