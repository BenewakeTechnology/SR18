// src/data/sr18_adc_convert.cpp
#include "sr18_adc_convert.h"

namespace {
uint16_t identity(uint16_t raw) { return raw; }
}  // namespace

const sr18::AdcConvertFn sr18::kAdcConvert[8] = {
    identity, identity, identity, identity,
    identity, identity, identity, identity,
};
