// samples/basic_demo/main.cpp
#include "sr18_lidar_driver.h"
#include <iostream>
#include <thread>
#include <chrono>

int main(int argc, char** argv) {
    std::string rx_port = (argc > 1) ? argv[1] : "/dev/ttyUSB0";
    std::string tx_port = (argc > 2) ? argv[2] : "/dev/ttyUSB1";
    benewake::SR18Lidar lidar(rx_port, tx_port);   // RX 3.125 Mbps, TX 9600 bps

    if (!lidar.start()) {
        std::cerr << "start() failed\n";
        return 1;
    }
    std::cout << "started, polling 5 frames...\n";

    for (int i = 0; i < 5; ++i) {
        benewake::BwPointCloud::Ptr pc;
        int frame_id = -1;
        if (lidar.getData(pc, frame_id, 2000)) {
            std::cout << "frame_id=" << frame_id
                      << "  points=" << pc->points.size() << "\n";
        } else {
            std::cout << "no data within 2s\n";
        }
    }
    lidar.stop();
    return 0;
}
