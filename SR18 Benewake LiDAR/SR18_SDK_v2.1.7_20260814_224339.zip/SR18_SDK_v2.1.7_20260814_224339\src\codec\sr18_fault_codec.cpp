// src/codec/sr18_fault_codec.cpp
#include "sr18_fault_codec.h"
#include "sr18_crc.h"
#include "../../include/sr18_common.h"
#include <cstring>

namespace sr18 {

bool parse_fault_frame(const uint8_t* frame, size_t len, FaultFrame& out) {
    if (len != kFaultFrameLen) return false;
    if (frame[0] != 0xEE || frame[1] != 0xDD) return false;
    // CRC-32/MPEG-2 over [13..36] (Lidar State .. Reserved), 24 bytes
    // (already 4-byte aligned), little-endian trailer at [37..40].
    uint32_t want = crc32_mpeg2_align4(frame + 13, 24);
    uint32_t got  =  (uint32_t)frame[37]
                  | ((uint32_t)frame[38] <<  8)
                  | ((uint32_t)frame[39] << 16)
                  | ((uint32_t)frame[40] << 24);
    if (got != want) return false;

    out.fs_version = frame[2];
    std::memcpy(out.time_raw, frame + 3, 10);
    out.lidar_state       = (uint8_t)((frame[13] >> 5) & 0x07);
    out.rolling_counter   = (uint8_t)(frame[13] & 0x07);
    out.total_fault_codes = (uint8_t)((frame[14] >> 4) & 0x0F);
    out.fault_code_id     = (uint8_t)(frame[14] & 0x0F);
    out.fault_code        = (uint16_t)(frame[15] | (frame[16] << 8));
    std::memcpy(out.reserved, frame + 17, 20);
    return true;
}

const char* fault_code_name(uint16_t code) {
    switch (code) {
        case 0x0104: return "window fouling";
        case 0x0111: return "over-temperature (zone A)";
        case 0x0112: return "over-temperature (zone B)";
        case 0x0113: return "IMU fault";
        case 0x0116: return "input voltage abnormal";
        case 0x0117: return "lidar parameter abnormal";
        case 0x0210: return "motor speed abnormal";
        case 0x0211: return "motor stall";
        case 0x0212: return "motor over-current";
        case 0x0213: return "encoder output abnormal";
        case 0x0214: return "encoder disk fouling";
        case 0x0215: return "startup failure";
        case 0x0406: return "PPS sync accuracy low";
        case 0x0407: return "GNSS signal lost";
        case 0x0408: return "PPS signal lost";
        case 0x0409: return "GNSS signal abnormal";
        case 0x0501: return "eye-safety fault";
        default:     return "unknown";
    }
}

const char* lidar_state_name(uint8_t state) {
    switch (state) {
        case 0: return "normal";
        case 1: return "warning";
        case 2: return "shutdown";
        case 3: return "standby";
        default: return "unknown";
    }
}

}  // namespace sr18

// Public (benewake) wrappers so host apps can name faults without pulling in
// internal codec headers. Declared in include/sr18_common.h.
namespace benewake {
const char* sr18_fault_code_name(uint16_t code) { return sr18::fault_code_name(code); }
const char* sr18_lidar_state_name(uint8_t state) { return sr18::lidar_state_name(state); }
}  // namespace benewake
