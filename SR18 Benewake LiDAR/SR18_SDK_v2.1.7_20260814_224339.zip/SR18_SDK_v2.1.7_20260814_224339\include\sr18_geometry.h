// include/sr18_geometry.h
// Geometric helpers — azimuth-fixed-point decoding and (channel, azimuth, distance)
// → Cartesian conversion.
//
// AZIMUTH wire format: see BwPoint.azimuth in sr18_common.h. Briefly: fix17_13
// radians, range 0..2*pi. The protocol layer transmits it as uint16 (little-endian,
// like every other multi-byte field on the SR18 wire).
//
// Coordinate-system convention (right-handed, host-facing):
//   +X = right side of the lidar (when viewed from above looking down -Z)
//   +Y = "forward" — tail-fiber exit side; az = 0° points here
//   +Z = up; rotation axis of the spinning head
// The wire-supplied azimuth is the angle measured CLOCKWISE from +Y when
// viewed from +Z above, matching the SR18 protocol drawing. Polar→Cartesian
// therefore uses x = r·cos(el)·sin(az) and y = r·cos(el)·cos(az) (the sin/cos
// swap relative to the textbook formula encodes the "0° lies on +Y, increases
// CW" convention).
//
// 18-channel calibration: per-channel vertical (elevation) angle plus per-channel
// horizontal offset (azimuth bias) supplied by the protocol team. Values live in
// `ChannelGeometry::sr18Calibration()`. Vertical-angle distribution is non-uniform.
// Horizontal offsets include a small negative main scan-plane bias, with channels
// 11/13/15/17 on a second positive-offset scan plane.
#pragma once

#include "sr18_api.h"
#include "sr18_common.h"
#include <array>
#include <cmath>
#include <cstdint>

namespace benewake {

// ----- AZIMUTH unit conversion --------------------------------------------

// fix17_13 -> radians. Divide by 2^13.
inline float azimuthToRadians(uint16_t raw) {
    return static_cast<float>(raw) / 8192.0f;
}

// fix17_13 -> degrees. Approximately raw * 6993e-6 (per radian_calc_c README).
// ⚠ LEGACY ENCODING ONLY. Do NOT feed BwPoint::azimuth from a b1 device here —
// b1 telemetry is 0.01 deg/LSB (full circle 36000), so this returns a wrong
// angle, not an imprecise one. For b1 counts use raw * 0.01f (degrees) or
// pcdAzimuthToRadians(raw) below.
inline float azimuthToDegrees(uint16_t raw) {
    constexpr float DEG_PER_RAD = 57.29577951308232f;   // 180 / pi
    return azimuthToRadians(raw) * DEG_PER_RAD;
}

// b1 new-protocol telemetry azimuth (PCD AND origin_dist): wire unit is
// 0.01 deg (full circle = 36000, manual §4.2; origin_dist follows the same
// skeleton per the 2026-07-20 directive). The fix17_13 helpers above remain
// for host code handling legacy recordings only.
// ⚠ P7: unit unverified on real b1 firmware (2026-07-20 spec item B).
inline float pcdAzimuthToRadians(uint16_t raw) {
    constexpr float CENTI_DEG_TO_RAD = 0.00017453292519943295f;  // 0.01 * pi/180
    return static_cast<float>(raw) * CENTI_DEG_TO_RAD;
}

// ----- 18-channel calibration table ---------------------------------------

// Per-channel vertical (elevation) and horizontal (azimuth-bias) angles, in
// radians. Channel index 0..17. Channel 0 is the topmost beam (+41.36 deg),
// channel 17 the bottommost (-6.13 deg).
//
// NOTE: this struct is INTENTIONALLY NOT marked SR18_API. On Windows MSVC,
// tagging a class with __declspec(dllimport) tells the compiler to look up
// every member via the DLL's export table — even inline-defined ones. Since
// ChannelGeometry's members are all inline (and the entire type is a thin
// wrapper around two std::arrays), exporting them would force adding non-inline
// .cpp definitions and shipping them via the DLL. The data-only design lets
// host apps consume the header without any DLL dependency for these helpers.
// Forward declaration + configurable-override accessor (defined in
// src/sr18_geometry.cpp). Declared BEFORE ChannelGeometry because the inline
// sr18Calibration() below calls it; a namespace function declared after the
// struct would not be visible inside the inline member body.
struct ChannelGeometry;
SR18_API bool getConfiguredChannelGeometry(ChannelGeometry& out);

struct ChannelGeometry {
    std::array<float, 18> elevation_rad;
    std::array<float, 18> azimuth_offset_rad;

    // Returns the SR18 factory-calibrated table.
    static ChannelGeometry sr18Calibration() {
        // Configurable override (set via setChannelAnglesDegrees before the
        // owning assembler is constructed). Falls through to the factory table.
        ChannelGeometry cfg{};
        if (getConfiguredChannelGeometry(cfg)) return cfg;
        constexpr float D2R = 0.017453292519943295f;
        // {vertical_deg, horizontal_offset_deg} per channel, supplied by the
        // protocol team.
        constexpr float v_deg[18] = {
            40.08f, 37.18f, 34.43f, 31.74f, 29.07f, 26.41f, 23.75f, 21.10f,
            18.46f, 15.82f, 13.19f, 10.56f,  7.92f,  5.28f,  2.64f, -0.01f,
            -4.01f, -7.99f,
        };
        constexpr float h_deg[18] = {
            0.337f, 0.339f, 0.341f, 0.344f, 0.348f, 0.354f,
            0.360f, 0.367f, 0.374f, 0.384f, 0.393f, 0.404f,
            0.415f, 0.428f, 0.441f, 0.456f, 7.272f, 7.342f,
        };
        ChannelGeometry t{};
        for (int i = 0; i < 18; ++i) {
            t.elevation_rad[i]      = v_deg[i] * D2R;
            t.azimuth_offset_rad[i] = h_deg[i] * D2R;
        }
        return t;
    }
};

// ----- Angle source & priority --------------------------------------------
// 当前生效角度的来源标记。优先级：USER(用户配置) > DEVICE(设备角度文件) >
// DEFAULT(内置出厂标定)。供上位机查询展示。
enum class AngleSource { DEFAULT = 0, DEVICE = 1, USER = 2 };

// ----- Configurable per-channel angle override ----------------------------
// 配置 18 通道的垂直(俯仰)与水平(方位偏置)角，单位「度」，SDK 内部转弧度。
//
// 优先级最高（USER）。**实时生效**：运行中调用即应用到后续帧，无需重连 —— 在线
// assembler 每包轮询 channelGeometryGeneration() 感知变化。进程级：影响本进程内
// 所有 assembler。返回 false：空指针或含非有限值(NaN/Inf)，此时存储不变。
SR18_API bool setChannelAnglesDegrees(const float vertical_deg[18],
                                      const float horizontal_deg[18]);
// 读回当前生效角度（度，按优先级）。从未配置任何来源则返回出厂标定角度。
SR18_API void getChannelAnglesDegrees(float vertical_deg[18],
                                      float horizontal_deg[18]);
// 清除用户配置。之后回退到设备获取值（若已获取），否则内置默认标定。实时生效。
SR18_API void clearChannelAngles();

// 当前生效角度的来源（USER / DEVICE / DEFAULT）。
SR18_API AngleSource getChannelAngleSource();

// ----- Device-fetched angles (SDK-internal, priority DEVICE) ---------------
// 设备角度文件解析结果写入接口（由 SDK 自动获取流程调用；优先级低于用户配置）。
// 实时生效。返回 false：空指针或含非有限值。
SR18_API bool setDeviceChannelAnglesDegrees(const float vertical_deg[18],
                                            const float horizontal_deg[18]);
// 清除设备角度，回退到内置默认标定（用户配置仍优先）。
SR18_API void clearDeviceChannelAngles();

// 角度配置世代计数：任何来源变更后自增。assembler 缓存本地副本并轮询本值，
// 世代变化时重新加载生效角度，从而实现运行中实时切换、无需重构 assembler。
SR18_API uint64_t channelGeometryGeneration();

// 按 §9.1 解析原始 72 字节角度区为每通道「度」。布局为**分块(split-block)**：
// [0..35] = 全部 18 通道的水平角、[36..71] = 全部 18 通道的垂直角，各为有符号
// int16 小端 ×0.01°（前半水平、后半垂直）。⚠ P7：分块先后、18 通道/72B、单位
// 0.01° 与符号性均未经真机固件核实。
SR18_API void decodeAngleFileDegrees(const uint8_t raw[72],
                                     float vertical_deg[18],
                                     float horizontal_deg[18]);

// 按世代计数刷新本地缓存的 ChannelGeometry。稳态下极廉价（一次 relaxed 原子读）。
// assembler 每包调用，使用户/设备角度变更在运行中生效。
inline void refreshChannelGeometry(ChannelGeometry& geom, uint64_t& gen_cache) {
    uint64_t g = channelGeometryGeneration();
    if (g != gen_cache) {
        geom      = ChannelGeometry::sr18Calibration();
        gen_cache = g;
    }
}

// ----- Polar -> Cartesian -------------------------------------------------

// `BwPoint.distance` is the SDK's canonical cm-quantized distance field
// (uint16_t, 1 LSB = 1 cm). Wire-side LSBs differ by D_TYPE — PCD is
// 4 mm/LSB, decoded inside the assembler (see sr18_frame_assembler.cpp);
// origin_dist computes distance from a centroid-derived float meters
// value (see sr18_origin_dist_assembler.cpp). Both assemblers store
// the cm-quantized value here AND fill x/y/z directly with full wire
// precision via `pointToCartesianFromMeters`.
//
// `pointToCartesian(BwPoint&, geom, scale=0.01f)` and `fillCartesian` are
// the legacy helpers that re-derive x/y/z from `pt.distance * scale`.
//
// **Do not call them on a cloud emitted by the SDK.** The assemblers already
// fill x/y/z from float meters with full wire precision; calling these
// helpers on such a cloud silently overwrites x/y/z with cm-derived values
// (because `pt.distance` is cm-quantized), dropping ~4 mm (PCD) / ~2.34 mm
// (origin_dist) of position precision.
//
// They remain available only for clouds host code constructs by hand from
// a stored cm `pt.distance` — e.g., when reading a saved cloud back from
// disk that doesn't carry x/y/z.
//
// The wire-supplied AZIMUTH is augmented by the per-channel horizontal offset
// before projection — this lets each channel land at its true horizontal angle.
//
// sin/cos are swapped relative to the textbook polar→Cartesian formula
// because the SR18 azimuth is measured clockwise from +Y (see file header),
// not counter-clockwise from +X.
//
// ⚠ LEGACY AZIMUTH ENCODING ONLY (fix17_13). Calling this on a b1 point cloud
// silently produces WRONG geometry: a full revolution of 36000 (0.01 deg/LSB)
// counts is read as 36000/8192 = 4.395 rad = 252 deg, so the whole scan is
// compressed and rotated. The SDK's own assemblers already fill x/y/z for both
// b1 paths — host code should NOT re-project. If you must, use
// pointToCartesianFromMetersRad(p, geom, dist_m, pcdAzimuthToRadians(p.azimuth)).
inline void pointToCartesian(BwPoint& p,
                              const ChannelGeometry& geom,
                              float distance_scale_meters = 0.01f) {
    float r = static_cast<float>(p.distance) * distance_scale_meters;
    float az = azimuthToRadians(p.azimuth) + geom.azimuth_offset_rad[p.channel];
    float el = geom.elevation_rad[p.channel];
    float horiz = r * std::cos(el);
    p.x = horiz * std::sin(az);
    p.y = horiz * std::cos(az);
    p.z = r * std::sin(el);
}

// Variant that takes distance directly in meters, bypassing BwPoint.distance
// (which is a cm-quantized uint16 and would lose ~2.34 mm precision when used
// as the source for high-resolution paths like origin_dist).
//
// ⚠ LEGACY AZIMUTH ENCODING ONLY (fix17_13). The meters-vs-cm distance source
// is the *lesser* difference here: on a b1 device the azimuth unit does not
// match (0.01 deg/LSB vs fix17_13), so the result is plain WRONG, not merely
// ~4 mm coarser. NOT used by the SDK's own b1 assemblers anymore (both pass
// pcdAzimuthToRadians via the Rad variant below); kept only for host code
// re-deriving coordinates from legacy (pre-b1) recordings.
inline void pointToCartesianFromMeters(BwPoint& p,
                                       const ChannelGeometry& geom,
                                       float distance_m) {
    float az = azimuthToRadians(p.azimuth) + geom.azimuth_offset_rad[p.channel];
    float el = geom.elevation_rad[p.channel];
    float horiz = distance_m * std::cos(el);
    p.x = horiz * std::sin(az);
    p.y = horiz * std::cos(az);
    p.z = distance_m * std::sin(el);
}

// Variant with a caller-supplied azimuth in radians, for wire encodings whose
// unit differs from fix17_13 — both b1 telemetry paths (PCD and origin_dist)
// pass pcdAzimuthToRadians(raw) here while BwPoint.azimuth keeps the raw
// 0.01-deg counts for host-side inspection.
inline void pointToCartesianFromMetersRad(BwPoint& p,
                                          const ChannelGeometry& geom,
                                          float distance_m,
                                          float azimuth_rad) {
    float az = azimuth_rad + geom.azimuth_offset_rad[p.channel];
    float el = geom.elevation_rad[p.channel];
    float horiz = distance_m * std::cos(el);
    p.x = horiz * std::sin(az);
    p.y = horiz * std::cos(az);
    p.z = distance_m * std::sin(el);
}

// Convenience: fill xyz for every point in a cloud using the same table+scale.
//
// ⚠ LEGACY AZIMUTH ENCODING ONLY — inherits pointToCartesian's b1 caveat above.
// Host apps used to be told they could call this after getData(); since
// 2026-05-04 the SDK fills x/y/z itself in BOTH modes, and on b1 azimuth units
// this call would overwrite correct coordinates with wrong ones. Don't call it
// on live b1 clouds.
inline void fillCartesian(BwPointCloud& cloud,
                           const ChannelGeometry& geom,
                           float distance_scale_meters = 0.01f) {
    for (auto& p : cloud.points) {
        pointToCartesian(p, geom, distance_scale_meters);
    }
}

}  // namespace benewake
