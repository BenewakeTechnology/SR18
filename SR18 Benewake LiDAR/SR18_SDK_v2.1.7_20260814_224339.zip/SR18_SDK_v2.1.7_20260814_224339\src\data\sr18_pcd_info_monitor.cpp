// src/data/sr18_pcd_info_monitor.cpp
#include "sr18_pcd_info_monitor.h"
#include "../../include/sr18_protocol.h"

namespace sr18 {

void PcdInfoMonitor::pushTail(const uint8_t* state_tdm) {
    if (!state_tdm) return;
    lidar_state_.store(state_tdm[0], std::memory_order_relaxed);
    uint8_t  id   = state_tdm[1];
    uint16_t data = (uint16_t)state_tdm[2] | ((uint16_t)state_tdm[3] << 8);
    tdm_[id].store(0x10000u | data, std::memory_order_relaxed);
    have_frame_.store(true, std::memory_order_release);
}

bool PcdInfoMonitor::getLidarState(uint8_t& state) const {
    if (!have_frame_.load(std::memory_order_acquire)) return false;
    state = lidar_state_.load(std::memory_order_relaxed);
    return true;
}

bool PcdInfoMonitor::getTdmData(uint8_t tdm_id, uint16_t& data) const {
    uint32_t v = tdm_[tdm_id].load(std::memory_order_relaxed);
    if (!(v & 0x10000u)) return false;
    data = (uint16_t)(v & 0xFFFFu);
    return true;
}

}  // namespace sr18
