// src/sr18_dcsp_payload.cpp
//
// All multi-byte numeric fields are serialised LITTLE-ENDIAN on the wire.
// (Originally BE; switched to LE 2026-04-30 after host integration found the
//  SR18 device expects LSB-first within every field.)
#include "sr18_dcsp_payload.h"

namespace sr18 {

static void pushLE16(std::vector<uint8_t>& v, uint16_t x) {
    v.push_back((uint8_t)(x & 0xFF));
    v.push_back((uint8_t)((x >> 8) & 0xFF));
}
static void pushLE32(std::vector<uint8_t>& v, uint32_t x) {
    v.push_back((uint8_t)(x & 0xFF));
    v.push_back((uint8_t)((x >>  8) & 0xFF));
    v.push_back((uint8_t)((x >> 16) & 0xFF));
    v.push_back((uint8_t)((x >> 24) & 0xFF));
}

void dcsp_encode_wr_reg(const uint16_t* addrs, const uint32_t* values, int n,
                        std::vector<uint8_t>& out) {
    out.clear();
    out.reserve(2 + 6 * n);
    pushLE16(out, (uint16_t)n);
    for (int i = 0; i < n; ++i) {
        pushLE16(out, addrs[i]);
        pushLE32(out, values[i]);
    }
}

void dcsp_encode_rd_reg(uint16_t addr, std::vector<uint8_t>& out) {
    // Read register has NO reg_num prefix (unlike write). Payload is only
    // addr(2 LE) + value=0(4 LE) = 6 bytes. Confirmed against device on COM8
    // 2026-05-03: a request prefixed with reg_num was rejected; the bare
    // addr+value form is what the SR18 device acks.
    out.clear();
    out.reserve(6);
    pushLE16(out, addr);
    pushLE32(out, 0);
}

/* dcsp_encode_wr_lut retired 2026-07-07 (see spec 2026-07-07) — superseded by
   the boot-unified LUT download path.
void dcsp_encode_wr_lut(uint8_t id, const uint8_t* value, uint16_t len,
                        std::vector<uint8_t>& out) {
    out.clear();
    out.reserve(4 + len);
    out.push_back(1);          // lut_num
    out.push_back(id);
    pushLE16(out, len);
    out.insert(out.end(), value, value + len);
}
*/

void dcsp_encode_timestamp(const uint8_t s[6], uint32_t ns,
                           std::vector<uint8_t>& out) {
    // The caller already provides s[] in the on-wire byte order (LE).
    out.clear();
    out.reserve(10);
    out.insert(out.end(), s, s + 6);
    pushLE32(out, ns);
}

}  // namespace sr18
