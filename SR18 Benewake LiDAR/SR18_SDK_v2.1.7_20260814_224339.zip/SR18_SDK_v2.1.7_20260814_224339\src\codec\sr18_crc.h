// src/codec/sr18_crc.h
#pragma once
#include <cstdint>
#include <cstddef>

// Compile-time selector for the SR18 wire-CRC padding rule.
//   SR18_CRC_ALIGN4 == 0 (default): current / pre-CRC hardware. Downstream
//     commands and PCD compute CRC-32/MPEG-2 over the raw body (NO padding).
//     IMU still pads its 30-byte body to 32 (it always has, independent of this
//     switch); Status(16) and origin_dist(532) are already 4-aligned.
//   SR18_CRC_ALIGN4 == 1: post-firmware unified rule — EVERY frame/command
//     zero-pads its body up to the next 4-byte boundary before CRC
//     (PCD 82->84, downstream LASER_EN 6->8, ...).
// Flip to 1 (CMake: -DSR18_CRC_ALIGN4=ON) once the device firmware adopts the
// unified align4 rule. The full unified change lives in git 9453dca; this switch
// gates it off by default so the SDK keeps talking to current hardware. NOTE:
// PCD 82->84 and downstream non-4B padding are still bench-unverified (P7).
#ifndef SR18_CRC_ALIGN4
#define SR18_CRC_ALIGN4 0
#endif

namespace sr18 {

// CRC-16/IBM (non-reflected variant). poly=0x8005, init=0x0000, refin=false, refout=false, xorout=0
// Catalog check value: crc16_ibm("123456789", 9) = 0xFEE8.
// Note: NO LONGER USED on the wire — both upstream and downstream now use CRC-32/MPEG-2
// (the protocol was unified in 2026-04-30). The function and its tests are retained for
// reference / regression coverage.
uint16_t crc16_ibm(const uint8_t* data, size_t len);

// CRC-32/MPEG-2. poly=0x04C11DB7, init=0xFFFFFFFF, refin=false, refout=false, xorout=0
// Used on BOTH downstream (0xA5B6) and upstream (0xFFEE) frames. This fn computes
// over exactly the bytes given (no padding) — prefer crc32_mpeg2_align4() for wire
// frames. The returned uint32 is serialised LSB-first on the wire (little-endian),
// like every other multi-byte field on the SR18 link.
uint32_t crc32_mpeg2(const uint8_t* data, size_t len);

// crc32_mpeg2 with the SR18 wire padding rule: zero-pad the input up to the next
// 4-byte (32-bit word) boundary, then compute CRC-32/MPEG-2. This is the UNIFORM
// rule for every SR18 frame and downstream command — e.g. IMU body 30->32, PCD
// body 82->84, downstream LASER_EN header 6->8; already-aligned bodies (Status 16,
// origin_dist 532) are unchanged. The pad bytes are for the CRC computation only;
// they are never placed on the wire. Both endpoints (encoder + decoder + device)
// must use this so the trailing CRC matches.
uint32_t crc32_mpeg2_align4(const uint8_t* data, size_t len);

// Wire CRC for downstream commands and non-IMU upstream frames (PCD / Status /
// origin_dist), honoring the SR18_CRC_ALIGN4 build switch:
//   ON  -> crc32_mpeg2_align4 (pad to 4-byte boundary)
//   OFF -> crc32_mpeg2        (raw body, no padding)
// For already-4-aligned bodies (Status 16, origin_dist 532) the two are
// identical, so this is safe to use uniformly. IMU is the one exception: it
// always uses crc32_mpeg2_align4() directly regardless of the switch, because
// its 30->32 padding predates and is independent of the unified align4 rule.
uint32_t crc32_wire(const uint8_t* data, size_t len);

}  // namespace sr18
