// src/data/sr18_origin_dist_decoder.h
#pragma once
#include "../codec/sr18_decoder.h"
#include "../../include/sr18_common.h"

namespace sr18 {

// Stateless decoder: parses one 0x0B (origin_dist) wire frame into a BwOriginDist.
// Caller provides a fully-validated frame (CRC already checked, len = ORIGIN_DIST_FRAME_LEN).
struct OriginDistDecoder {
    static void decode(const DecodedFrame& df, benewake::BwOriginDist& out);
};

}  // namespace sr18
