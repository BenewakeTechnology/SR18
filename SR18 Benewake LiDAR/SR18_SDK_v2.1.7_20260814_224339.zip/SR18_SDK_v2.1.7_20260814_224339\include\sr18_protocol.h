// include/sr18_protocol.h
#pragma once
#include <cstdint>
#include <cstddef>

namespace sr18 {

// Downstream Transaction Codes (TC)
enum class TC : uint8_t {
    WR_REG_TEMP_DOWN = 0x00,
    WR_REG_SAVE_DOWN = 0x01,
    RD_REG_DOWN      = 0x02,
    WR_BOOT_DOWN     = 0x03,   // bootimage upload (down-board) — UNUSED since
                               // 2026-07-28 (binary boot retired; see sr18_dcsp.h)
    WR_REG_TEMP_UP   = 0x04,
    WR_REG_SAVE_UP   = 0x05,
    RD_REG_UP        = 0x06,
    WR_LUT_UP        = 0x07,
    WR_BOOT_UP       = 0x08,   // bootimage upload (up-board) — UNUSED since
                               // 2026-07-28 (binary boot retired; use $LDOTA)
    WR_LUT_DOWN      = 0x0A,   // down-board LUT (per FPGA downlink table); shares
                               // the up-board LUT path, only this command differs
    LASER_EN         = 0x0B,
    LIDAR_STOP       = 0x0C,   // stub — replaced by SYS_RST
    WR_SYS_RST       = 0x0D,
    WR_TIMESTAMP     = 0x0E,
};

// Upstream D_TYPE codes
constexpr uint8_t DTYPE_PCD         = 0x00;
constexpr uint8_t DTYPE_IMU         = 0x01;
constexpr uint8_t DTYPE_ORIGIN_DIST = 0x0B;
constexpr uint8_t DTYPE_STATUS      = 0x0C;

// Frame totals
// PCD and origin_dist follow the b1 new-protocol layout (manual §4.1/§4.2,
// 2026-07-20 spec + same-day user directive "解距除 Block 1 外与新协议一致"):
// shared skeleton = header(6) + Date&Time(6) + us(4) + azimuth(2) + block +
// tail [contamination(5) + lidar_state(1) + TDM id(1) + TDM data(2) +
// UDP seq(2) + CRC(4)]. PCD block = 18ch x 3B = 54 (87 total); origin_dist
// block = 18ch x 28B = 504 (537 total). The legacy layouts (PCD 86 B with
// RD_REG@72/ADC@76/SEQ@80; origin_dist 536 B with RD_REG@522/ADC@526/SEQ@530)
// are NOT decodable on this branch.
constexpr size_t PCD_FRAME_LEN         = 87;
constexpr size_t IMU_FRAME_LEN         = 34;
constexpr size_t ORIGIN_DIST_FRAME_LEN = 532;
constexpr size_t STATUS_FRAME_LEN      = 20;

// b1 new-protocol PCD tail layout (offsets into the full frame).
// Contamination: 18 ch x 2 bit = 36 bit -> 5 bytes (ceil), LSB-first within
// each byte (4 ch/byte per manual §4.2). ⚠ P7: firmware may pad to 6 B
// (4-byte-aligned body); if so bump kPcdContamLen and everything shifts.
constexpr size_t PCD_OFF_AZIMUTH     = 16;
constexpr size_t PCD_OFF_BLOCK       = 18;   // 18 ch x 3 B = 54 B
constexpr size_t PCD_OFF_CONTAM      = 72;
constexpr size_t kPcdContamLen       = 5;
// Lidar State byte: 0x00 = 正常工作, 0x01 = 高温 (manual §4.2 / downlink table).
// 高温 is itself a *lidar state* value, NOT a separate temperature-warning
// field — so this byte is named lidar_state, not temp_warn.
constexpr size_t PCD_OFF_LIDAR_STATE = PCD_OFF_CONTAM + kPcdContamLen;      // 77
constexpr size_t PCD_OFF_TDM_ID      = PCD_OFF_LIDAR_STATE + 1;             // 78
constexpr size_t PCD_OFF_TDM_DATA    = PCD_OFF_TDM_ID + 1;                  // 79
constexpr size_t PCD_OFF_SEQ         = PCD_OFF_TDM_DATA + 2;                // 81
static_assert(PCD_OFF_SEQ + 2 + 4 == PCD_FRAME_LEN, "PCD tail layout mismatch");

// Unpack one channel's 2-bit contamination level out of the packed 5-byte PCD
// tail region. `contam` points at PCD_OFF_CONTAM; `ch` is 0..17. Single source
// of truth for the bit layout — used by both the per-point path
// (FrameAssembler) and the frame-level cache (PcdInfoMonitor).
inline uint8_t pcdContaminationLevel(const uint8_t* contam, int ch) {
    return (uint8_t)((contam[(size_t)ch / 4] >> ((ch % 4) * 2)) & 0x03);
}

// b1 new-protocol origin_dist (解距 / mode1) tail — same skeleton as PCD but
// WITHOUT the contamination field: per the downlink table §五 and manual, the
// 解距 point-cloud body carries no 脏污 bytes (only 球坐标/mode0 does). block =
// 18ch x 28B; tail = lidar_state(1) + TDM id(1) + TDM data(2) + SEQ(2) + CRC(4).
constexpr size_t OD_OFF_BLOCK       = 18;                                   // 504 B
constexpr size_t OD_OFF_LIDAR_STATE = OD_OFF_BLOCK + 18 * 28;               // 522
constexpr size_t OD_OFF_TDM_ID      = OD_OFF_LIDAR_STATE + 1;               // 523
constexpr size_t OD_OFF_TDM_DATA    = OD_OFF_TDM_ID + 1;                    // 524
constexpr size_t OD_OFF_SEQ         = OD_OFF_TDM_DATA + 2;                  // 526
static_assert(OD_OFF_SEQ + 2 + 4 == ORIGIN_DIST_FRAME_LEN,
              "origin_dist tail layout mismatch");

// TDM (time-division-multiplexed) IDs carried in the PCD tail (manual §4.2).
constexpr uint8_t TDM_ID_MOTOR_RPM = 0x00;   // TDM data = motor speed, RPM

// Downstream STX = 0xA5B6 (little-endian on wire: 0xB6 0xA5)
constexpr uint16_t STX_DOWN = 0xA5B6;
// Upstream STX = 0xFFEE (little-endian on wire: 0xEE 0xFF)
constexpr uint16_t STX_UP   = 0xFFEE;

// Optical-comm slot state — affects packet limits
enum class SlotState : uint8_t {
    SLOT_9 = 9,    // default / idle (PAYLOAD <= 2040 B, REG <= 340)
    SLOT_1 = 1,    // running       (PAYLOAD <= 48 B,   REG <= 8)
};

// Register address partitions (a single write must stay in one partition)
enum class RegisterPartition : uint8_t {
    PART_0 = 0,    // 0x0000 - 0x1FFF
    PART_1 = 1,    // 0x2000 - 0x2FFF
    PART_2 = 2,    // 0x3000 - 0x3FFF
    INVALID,
};

// CHK_ST decode (offset 4 in every upstream frame)
struct ChkSt {
    bool    valid;     // bit[2]
    uint8_t status;    // bit[1:0]: 0=OK, 1=hold, 2=CRC_err

    static ChkSt parse(uint8_t raw) {
        return ChkSt{ (raw & 0x04) != 0, static_cast<uint8_t>(raw & 0x03) };
    }
};

}  // namespace sr18
