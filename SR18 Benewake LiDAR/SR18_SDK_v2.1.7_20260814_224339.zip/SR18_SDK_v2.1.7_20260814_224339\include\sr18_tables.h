// include/sr18_tables.h
#pragma once
#include "sr18_protocol.h"

namespace sr18 {

inline RegisterPartition partitionOf(uint16_t addr) {
    if (addr <= 0x1FFF) return RegisterPartition::PART_0;
    if (addr <= 0x2FFF) return RegisterPartition::PART_1;
    if (addr <= 0x3FFF) return RegisterPartition::PART_2;
    return RegisterPartition::INVALID;
}

inline int maxRegistersPerPacket(SlotState slot) {
    // SLOT_1 (streaming) = 8 regs/frame; SLOT_9 (idle) = 150 regs/frame.
    // (Idle ceiling lowered 340 -> 150 on 2026-07-08 per protocol team.)
    return slot == SlotState::SLOT_1 ? 8 : 150;
}

inline int maxPayloadBytes(SlotState slot) {
    return slot == SlotState::SLOT_1 ? 48 : 2040;
}

}  // namespace sr18
