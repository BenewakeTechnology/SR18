// src/data/sr18_ota_session.h
#pragma once
#include <cstdint>
#include <cstddef>

namespace sr18 {

class ISerial;

struct OtaParams {
    uint32_t info            = 0;       // 升级信息[4]; semantics bench-pending
    uint32_t chunk           = 1024;    // DATA bytes per packet
    int      ready_timeout_ms = 10000;  // wait for Ready ACK (0x55)
    int      ack_timeout_ms   = 20000;  // per-packet OTA ACK
    int      max_retx         = 5;      // per-packet retransmit limit
};

// Drives the $LDOTA packet protocol on a serial already switched to 115200 and
// exclusively owned (RxRouter stopped). Waits for the Ready ACK, then sends the
// image as derived packets (total=ceil(len/chunk), seq 0..total-1, size=DATA
// len). Returns SR18_OK or a negative SR18 error code.
//
// Retransmit policy (manual §5.2c / §6.2): both an ACK timeout AND a 0x07
// failure ACK count as one failed delivery; max_retx CONSECUTIVE failures end
// the upgrade with SR18_TIMEOUT. A 0x07 ACK carrying err 0x07 ("当前包 ID 不连续,
// 重传上一包") steps the sequence BACK one packet — the counter is therefore
// global-consecutive, not per-seq. It is refilled only by advancing past the
// high-water mark, so a device that ping-pongs between two packets still hits
// the limit instead of looping forever.
//
// NOT implemented (recorded in docs/sdk/B1_OTA_GAP.md): 序列号分板 (0~699 下板 /
// 700~1399 上板), err 0x0A early abort, 断点续传, A/B 分区, 升级后重启,
// 末包 ACK 后的 100 ms 波特率交接窗口.
class OtaSession {
public:
    explicit OtaSession(ISerial* serial);
    int run(const uint8_t* image, size_t image_len, const OtaParams& p);
private:
    ISerial* serial_;
};

}  // namespace sr18
