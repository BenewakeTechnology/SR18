// src/codec/sr18_ota_codec.cpp
#include "sr18_ota_codec.h"
#include "sr18_crc.h"
#include <cstring>

namespace sr18 {

namespace {
constexpr uint8_t kAckHdr[7]  = {0x24,0x4C,0x44,0x41,0x43,0x4B,0x2C}; // $LDACK,
constexpr uint8_t kOtaHdr[7]  = {0x24,0x4C,0x44,0x4F,0x54,0x41,0x2C}; // $LDOTA,
inline void put_be32(std::vector<uint8_t>& o, uint32_t v) {
    o.push_back((uint8_t)((v >> 24) & 0xFF));
    o.push_back((uint8_t)((v >> 16) & 0xFF));
    o.push_back((uint8_t)((v >>  8) & 0xFF));
    o.push_back((uint8_t)( v        & 0xFF));
}
}  // namespace

size_t ota_ack_total_len(uint8_t len_field) { return 19u + len_field; }

bool parse_ota_ack(const uint8_t* frame, size_t len, OtaAck& out) {
    if (len < 21) return false;
    if (std::memcmp(frame, kAckHdr, 7) != 0) return false;
    uint8_t len_field = frame[7];
    if (len_field != 0x02) return false;                 // OTA-family ACK
    if (len != ota_ack_total_len(len_field)) return false;
    if (frame[len - 2] != 0xEE || frame[len - 1] != 0xFF) return false;
    size_t body_len = 6u + len_field;                    // [Len..CHECK_ID] = 8
    uint32_t want = crc32_mpeg2_align4(frame + 7, body_len);
    size_t crc_off = 7 + body_len;                       // = 15
    uint32_t got =  ((uint32_t)frame[crc_off]     << 24) // big-endian on wire
                 | ((uint32_t)frame[crc_off + 1] << 16)
                 | ((uint32_t)frame[crc_off + 2] <<  8)
                 |  (uint32_t)frame[crc_off + 3];
    if (got != want) return false;
    out.code     = frame[8];
    out.err      = frame[8 + len_field];                 // = frame[10]
    out.check_id =  ((uint32_t)frame[9 + len_field]     << 24)  // BE, = frame[11..14]
                 | ((uint32_t)frame[9 + len_field + 1] << 16)
                 | ((uint32_t)frame[9 + len_field + 2] <<  8)
                 |  (uint32_t)frame[9 + len_field + 3];
    return true;
}

void encode_ldota(uint32_t info, uint32_t total, uint32_t seq,
                  const uint8_t* data, uint32_t data_len,
                  std::vector<uint8_t>& out) {
    out.clear();
    out.reserve(7 + 16 + data_len + 6);
    out.insert(out.end(), kOtaHdr, kOtaHdr + 7);
    const size_t body_start = out.size();                // CRC covers [info..DATA]
    put_be32(out, info);
    put_be32(out, total);
    put_be32(out, seq);
    put_be32(out, data_len);
    if (data && data_len) out.insert(out.end(), data, data + data_len);
    uint32_t crc = crc32_mpeg2_align4(out.data() + body_start, out.size() - body_start);
    out.push_back((uint8_t)((crc >> 24) & 0xFF));        // big-endian on wire
    out.push_back((uint8_t)((crc >> 16) & 0xFF));
    out.push_back((uint8_t)((crc >>  8) & 0xFF));
    out.push_back((uint8_t)( crc        & 0xFF));
    out.push_back(0xEE);
    out.push_back(0xFF);
}

}  // namespace sr18
