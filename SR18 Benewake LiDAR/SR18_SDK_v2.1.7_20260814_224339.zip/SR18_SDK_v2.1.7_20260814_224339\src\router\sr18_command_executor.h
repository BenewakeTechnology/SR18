// src/router/sr18_command_executor.h
#pragma once
#include <chrono>
#include <cstddef>
#include <cstdint>
#include "../codec/sr18_ascii_codec.h"

namespace sr18 {

// ────────────────────────────────────────────────────────────────────────
// ICommandExecutor: end-to-end execution of one downstream frame.
// Used by DCSPProtocol; encapsulates serial.write + ACK wait.
// Implementations serialize concurrent calls internally.
// ────────────────────────────────────────────────────────────────────────
class ICommandExecutor {
public:
    enum class Status { DONE, CRC_ERR, TIMEOUT };

    struct Result {
        Status   status;
        uint32_t rd_reg = 0;   // valid when status==DONE && need_rd_reg=true
    };

    virtual ~ICommandExecutor() = default;

    // Synchronously execute one already-encoded downstream frame:
    //   1. wait for safe TX window
    //   2. serial.write(frame, len)
    //   3. wait for device-state edge (DONE/CRC_ERR/TIMEOUT)
    // Concurrent calls serialize internally.
    virtual Result execute(const uint8_t* frame, std::size_t len,
                           bool need_rd_reg,
                           std::chrono::milliseconds timeout) = 0;

    // ASCII command-family result. ack=false means no matching $LDACK before
    // the deadline. ack=true means an ACK was received; err is its error code
    // (0 = success), cmd_data is the echoed payload.
    struct AsciiResult { bool ack = false; uint8_t err = 0; uint16_t cmd_data = 0; };

    // Execute an already-encoded $LDCMD frame and wait for the matching
    // $LDACK (by expected CMD_ID + CHECK_ID). Default impl returns no-ack so
    // binary-only / receive-only executors and test mocks need no change.
    virtual AsciiResult executeAscii(const uint8_t* /*frame*/, std::size_t /*len*/,
                                     uint8_t /*expect_cmd_id*/,
                                     uint32_t /*expect_check_id*/,
                                     std::chrono::milliseconds /*timeout*/) {
        return {};
    }

    // Read-angle-file result. ack=false means no matching PKT_CMD33 before the
    // deadline; on ack=true, file holds the raw 72-byte angle region.
    struct AsciiAngleResult { bool ack = false; AsciiAngleFile file; };

    // Execute an already-encoded read-angle-file $LDCMD and wait for the 99-byte
    // ACK matched by the echoed CHECK_ID. Default impl returns no-ack so
    // binary-only / receive-only executors and test mocks need no change.
    virtual AsciiAngleResult executeAsciiAngle(const uint8_t* /*frame*/,
                                               std::size_t /*len*/,
                                               uint32_t /*expect_check_id*/,
                                               std::chrono::milliseconds /*timeout*/) {
        return {};
    }

};

}  // namespace sr18
