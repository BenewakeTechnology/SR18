// src/sr18_dcsp.cpp
#include "../include/sr18_dcsp.h"
#include "../include/sr18_tables.h"
#include "router/sr18_command_executor.h"
#include "router/sr18_rd_reg_sampler.h"
#include "router/sr18_lut_fail_sampler.h"
#include "codec/sr18_encoder.h"
#include "codec/sr18_ascii_codec.h"
#include "sr18_dcsp_payload.h"
#include <thread>
#include "data/sr18_adc_monitor.h"
#include <atomic>
#include <chrono>
#include <thread>
#include <vector>
#include <cstring>
#include <cstdio>
#include <iostream>

using namespace sr18;
using namespace benewake;

namespace {
// dev_b1: bin uploads (up-board LUT TC 0x07 / down-board LUT TC 0x0A) no longer
// append the 12-byte end magic, nor do they 0xFF-pad the tail to a 4-byte
// boundary — the device consumes exactly the bytes read from the file. The
// former kBootEndMagic / kLutEndMagic constants were removed with the magic.
//
// 2026-07-28: every upload packet now carries a 12-byte little-endian header
// ahead of its data — see kImgHdrBytes / putLe32 below and sendImage().
constexpr int      kFinalizeTimeoutMs = 60000;     // last-packet timeout
constexpr size_t   kLutChunkDefault   = 1024;      // default DATA bytes/packet

// Upload packet header (board diagnostic report 2026-07-27,
// docs/sdk/host_0x07_upgrade_fail_report_for_host_team.md §4.2/§4.4):
//   payload[0..3]  total : total number of DATA packets   (32-bit LE)
//   payload[4..7]  no    : this packet's index, from 0    (32-bit LE)
//   payload[8..11] len   : this packet's DATA byte count   (32-bit LE)
//   payload[12..]  data
// The device starts an upgrade session only when it parses `no == 0`, and uses
// `no == total-1` to recognise the final packet (whose tail carries the host's
// whole-image CRC word). Same triple as the ASCII $LDOTA boot header (总包数 /
// 序列号 / 包大小) but LITTLE-endian and WITHOUT $LDOTA's leading 4-byte
// 升级信息 field — do not copy encode_ldota()'s header here.
constexpr size_t kImgHdrBytes = 12;
inline void putLe32(std::vector<uint8_t>& v, uint32_t x) {
    v.push_back(static_cast<uint8_t>( x        & 0xFF));
    v.push_back(static_cast<uint8_t>((x >>  8) & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 16) & 0xFF));
    v.push_back(static_cast<uint8_t>((x >> 24) & 0xFF));
}

// Post-ACK settle before soliciting bit[5]: the device transiently asserts the
// fail bit right after a successful upload and clears it within this window
// (real-machine 2026-07-17). We sleep through it, then actively probe.
constexpr int kLutVerifyWindowDefaultMs = 5000;
// After settle, how long to wait for the probe's ACK-borne CHK_ST sample; also
// the probe read-register command's own ACK timeout.
constexpr int kLutVerifyGraceDefaultMs  = 2000;
// Up-board register read as the post-settle probe: the device rides the fresh
// bit[5] back on this command's ACK CHK_ST. The read-back value is ignored —
// any ACK-bearing command works; 0x310c is a harmless up-board register
// (real-machine 2026-07-24).
constexpr uint16_t kLutVerifyProbeReg = 0x310c;
}  // namespace

struct DCSPProtocol::Impl {
    ICommandExecutor*       executor;
    IRdRegSampler*          sampler;
    AdcMonitor*             adc_monitor;
    uint8_t                 seq_ = 0;
    // FIXED CHECK_ID per the FPGA downlink table: every $LDCMD (except the
    // angle-file query) uses the constant 78 56 34 12 = 0x12345678. The device
    // treats it as a fixed tag, not a free nonce — single-command-in-flight
    // (exec_mu_) means a fixed value is unambiguous for ACK matching. Do NOT
    // roll it (a rolling value risks rejection past the first command).
    static constexpr uint32_t kAsciiCheckId = 0x12345678u;
    std::atomic<SlotState>  slot_;
    // boot_chunk_bytes_ retired with the binary boot path (see dcsp_wr_boot_*).
    size_t           lut_chunk_bytes_      = kLutChunkDefault;       // 1024
    int              lut_verify_window_ms_ = kLutVerifyWindowDefaultMs;
    int              lut_verify_grace_ms_  = kLutVerifyGraceDefaultMs;
    ILutFailWatcher* lut_fail_             = nullptr;

    int sendCommand(TC tc, const std::vector<uint8_t>& payload, int timeout_ms,
                    uint32_t* rd_reg_out = nullptr) {
        if (!executor) return SR18_ERR_NOT_SUPPORTED;
        bool need_rd_reg = (rd_reg_out != nullptr);
        auto timeout     = std::chrono::milliseconds(timeout_ms);

#ifdef SR18_DEBUG_INFO
        std::fprintf(stderr, "Execute TC 0x%02x ...\n",
                     static_cast<unsigned>(tc));
#endif

        for (int tries = 0; tries < 3; ++tries) {
#ifdef SR18_DEBUG_INFO
            std::cerr << "    attempts: " << (tries + 1) << '\n';
#endif
            std::vector<uint8_t> frame;
            encode_downstream(tc, seq_++, payload.data(), payload.size(), frame);

            auto r = executor->execute(frame.data(), frame.size(),
                                        need_rd_reg, timeout);
            switch (r.status) {
                case ICommandExecutor::Status::DONE:
                    if (rd_reg_out) *rd_reg_out = r.rd_reg;
                    return SR18_OK;
                case ICommandExecutor::Status::CRC_ERR:
                    std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                              << " line: " << __LINE__ << '\n';
                    std::fprintf(stderr,
                        "TC 0x%02x CRC error on attempt %d\n",
                        static_cast<unsigned>(tc), tries + 1);
                    continue;
                case ICommandExecutor::Status::TIMEOUT:
                    std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                              << " line: " << __LINE__ << '\n';
                    std::fprintf(stderr,
                        "TC 0x%02x timeout on attempt %d\n",
                        static_cast<unsigned>(tc), tries + 1);
                    continue;
            }
        }
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "TC 0x%02x out of retries (3 attempts)\n",
                     static_cast<unsigned>(tc));
        return SR18_TIMEOUT;
    }

    // Fixed-SEQ variant: every retry attempt uses the same `seq` so the
    // device can recognise a retransmission and skip duplicate processing.
    // The caller owns the sequence counter — this method never increments it.
    int sendCommandFixedSeq(TC tc, const std::vector<uint8_t>& payload,
                            int timeout_ms, uint8_t seq,
                            uint32_t* rd_reg_out = nullptr) {
        if (!executor) return SR18_ERR_NOT_SUPPORTED;
        bool need_rd_reg = (rd_reg_out != nullptr);
        auto timeout     = std::chrono::milliseconds(timeout_ms);

#ifdef SR18_DEBUG_INFO
        std::fprintf(stderr, "Execute TC 0x%02x seq=%u ...\n",
                     static_cast<unsigned>(tc), static_cast<unsigned>(seq));
#endif

        for (int tries = 0; tries < 3; ++tries) {
#ifdef SR18_DEBUG_INFO
            std::cerr << "    attempts: " << (tries + 1) << '\n';
#endif
            std::vector<uint8_t> frame;
            encode_downstream(tc, seq, payload.data(), payload.size(), frame);

            auto r = executor->execute(frame.data(), frame.size(),
                                        need_rd_reg, timeout);
            switch (r.status) {
                case ICommandExecutor::Status::DONE:
                    if (rd_reg_out) *rd_reg_out = r.rd_reg;
                    return SR18_OK;
                case ICommandExecutor::Status::CRC_ERR:
                    std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                              << " line: " << __LINE__ << '\n';
                    std::fprintf(stderr,
                        "TC 0x%02x seq=%u CRC error on attempt %d\n",
                        static_cast<unsigned>(tc),
                        static_cast<unsigned>(seq), tries + 1);
                    continue;
                case ICommandExecutor::Status::TIMEOUT:
                    std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                              << " line: " << __LINE__ << '\n';
                    std::fprintf(stderr,
                        "TC 0x%02x seq=%u timeout on attempt %d\n",
                        static_cast<unsigned>(tc),
                        static_cast<unsigned>(seq), tries + 1);
                    continue;
            }
        }
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "TC 0x%02x seq=%u out of retries (3 attempts)\n",
            static_cast<unsigned>(tc), static_cast<unsigned>(seq));
        return SR18_TIMEOUT;
    }

    int sendAsciiCmd(uint8_t cmd_id, uint16_t cmd_data, int timeout_ms,
                     uint16_t* data_out = nullptr) {
        if (!executor) return SR18_ERR_NOT_SUPPORTED;
        auto timeout = std::chrono::milliseconds(timeout_ms);
        for (int tries = 0; tries < 3; ++tries) {
            uint32_t check_id = kAsciiCheckId;   // fixed per FPGA table (see member note)
            std::vector<uint8_t> frame;
            encode_ascii_cmd(cmd_id, cmd_data, check_id, frame);
            auto r = executor->executeAscii(frame.data(), frame.size(),
                                            cmd_id, check_id, timeout);
            if (!r.ack) continue;                 // ACK timeout → resend same logical cmd
            // ACK received; enforce 35 ms inter-command spacing.
            std::this_thread::sleep_for(std::chrono::milliseconds(35));
            if (data_out) *data_out = r.cmd_data;
            switch (r.err) {
                case 0x00: return SR18_OK;
                case 0x32: return SR18_ERR_CRC;
                case 0x01: return SR18_ERR_PARAM;     // illegal instruction
                default:   return SR18_ERR_NOT_SUPPORTED;
            }
        }
        return SR18_TIMEOUT;
    }

    int sendAsciiAngle(uint8_t out[72], int timeout_ms) {
        if (!executor) return SR18_ERR_NOT_SUPPORTED;
        auto timeout = std::chrono::milliseconds(timeout_ms);
        for (int tries = 0; tries < 3; ++tries) {
            std::vector<uint8_t> frame;
            encode_ascii_cmd(/*cmd_id=*/0x02, /*cmd_data=*/0x0007,
                             kAsciiAngleCheckId, frame);
            auto r = executor->executeAsciiAngle(frame.data(), frame.size(),
                                                 kAsciiAngleCheckId, timeout);
            if (!r.ack) continue;                 // no ACK → resend same logical cmd
            std::this_thread::sleep_for(std::chrono::milliseconds(35));
            std::memcpy(out, r.file.angle_raw, 72);
            return SR18_OK;
        }
        return SR18_TIMEOUT;
    }

    int sendImage(TC tc, size_t size_limit,
                  const uint8_t* img, size_t n, size_t chunk, int packet_timeout_ms) {
        if (!executor) return SR18_ERR_NOT_SUPPORTED;
        if (!img || n == 0) {
            std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                      << " line: " << __LINE__ << '\n';
            std::fprintf(stderr, "sendImage: null img or n=0\n");
            return SR18_ERR_PARAM;
        }

        size_t words_bytes = (n + 3) & ~size_t(3);   // bytes actually written (4B words)
        if (size_limit != 0 && words_bytes > size_limit) {
            std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                      << " line: " << __LINE__ << '\n';
            std::fprintf(stderr,
                "image %zu bytes exceeds size limit %zu\n", n, size_limit);
            return SR18_ERR_PARAM;
        }

        // Packetization (dev_b1, chunk = C DATA bytes; NO end magic, NO tail pad):
        //   full_count = n / C ; R = n % C   (R = remainder, 0..C-1)
        //   send full_count packets of exactly C data bytes           [middle]
        //   if R != 0:  one tail packet of exactly R raw data bytes   [finalize]
        // Each packet's PAYLOAD = 12-byte [total|no|len] LE header + those data
        // bytes, so the outer frame LEN is 12 + len (e.g. 1036 for C=1024).
        // The last packet emitted (the tail, or the last full packet when R==0)
        // gets the 60 s finalize timeout; all earlier packets use per-packet.
        const size_t C          = chunk;
        const size_t full_count = n / C;
        const size_t R          = n % C;                   // remainder, 0..C-1
        const int    total      = (int)full_count + (R != 0 ? 1 : 0);

        int idx = 0;                 // == the `no` field: 0-based packet index
        uint8_t pkt_seq = 0;         // frame SEQ; own counter, reset per command
        auto sendPkt = [&](const uint8_t* data, size_t dlen, bool finalize) -> int {
            std::vector<uint8_t> pl;
            pl.reserve(kImgHdrBytes + dlen);
            putLe32(pl, static_cast<uint32_t>(total));   // total packet count
            putLe32(pl, static_cast<uint32_t>(idx));     // no, from 0
            putLe32(pl, static_cast<uint32_t>(dlen));    // this packet's data len
            pl.insert(pl.end(), data, data + dlen);

            uint8_t this_seq = pkt_seq;    // capture — all retries share this SEQ
            std::fprintf(stderr,
                "INFO: image packet %d/%d no=%d len=%zu payload=%zu seq=%u%s\n",
                idx + 1, total, idx, dlen, pl.size(),
                static_cast<unsigned>(this_seq),
                finalize ? " (finalize)" : "");
            int to = finalize ? kFinalizeTimeoutMs : packet_timeout_ms;
            int rc = sendCommandFixedSeq(tc, pl, to, this_seq);
            if (rc != SR18_OK) {
                std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                          << " line: " << __LINE__ << '\n';
                std::fprintf(stderr, "image: packet %d/%d seq=%u failed rc=%d\n",
                             idx + 1, total,
                             static_cast<unsigned>(this_seq), rc);
            }
            ++idx;
            ++pkt_seq;           // advance for the next packet
            return rc;
        };

        // Full packets: exactly C data bytes. When R==0 the last full packet is
        // the finalize packet; otherwise all full packets are middle packets.
        const size_t full_bytes = full_count * C;
        for (size_t off = 0; off < full_bytes; off += C) {
            const bool last_full = (off + C == full_bytes);
            const bool finalize  = (R == 0) && last_full;
            int rc = sendPkt(img + off, C, finalize);
            if (rc != SR18_OK) return rc;
        }

        if (R != 0) {
            // Raw remainder tail — exactly R data bytes, no magic, no 0xFF pad.
            // Its last 4 bytes are the host's whole-image CRC word (part of the
            // file); the device captures them to run its own flash-readback CRC.
            return sendPkt(img + full_bytes, R, /*finalize=*/true);
        }
        return SR18_OK;
    }

    // LUT upload for either board. Up-board (TC=0x07) and down-board (TC=0x0A)
    // are identical in every respect EXCEPT the LUT write command byte — same
    // packetization (raw bytes, no magic, no pad) and the same post-write
    // bit[5:4] verify probe (RD_REG 0x310c on the up-board). Only `lut_tc`
    // differs between the two entry points.
    int sendLut(TC lut_tc, const uint8_t* data, size_t n, int packet_timeout_ms) {
        int rc = sendImage(lut_tc, /*size_limit=*/0, data, n,
                           lut_chunk_bytes_, packet_timeout_ms);
        if (rc != SR18_OK) return rc;
        if (lut_fail_) {                    // verify whole-image write via bit[5:4]
            // 1) Settle: right after a successful upload the device is still
            //    reading flash / running verify (bit[5:4]=00 未确认, transiently
            //    also asserts the fail bit). Sleep through it so the S_LUT_CRC
            //    phase reaches its verdict.
            std::this_thread::sleep_for(
                std::chrono::milliseconds(lut_verify_window_ms_));
            // 2) Actively solicit the post-settle CHK_ST. arm() BEFORE the probe
            //    sendCommand so the sampler is listening when the ACK frame's
            //    CHK_ST fires through RxRouter (same ordering contract as
            //    dcsp_read_register). Read up-board reg 0x310c — the read-back
            //    value is irrelevant; bit[5:4] rides back on this command's ACK.
            lut_fail_->arm();
            std::vector<uint8_t> probe;
            sr18::dcsp_encode_rd_reg(kLutVerifyProbeReg, probe);
            int prc = sendCommand(TC::RD_REG_UP, probe, lut_verify_grace_ms_);
            if (prc != SR18_OK) {           // no ACK ⇒ write NOT confirmed
                std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                          << " line: " << __LINE__ << '\n';
                std::fprintf(stderr,
                    "LUT verify probe (RD_REG 0x%04x) got no ACK (rc=%d) — "
                    "write NOT confirmed\n",
                    static_cast<unsigned>(kLutVerifyProbeReg), prc);
                return prc;
            }
            // 3) Judge bit[5:4] of the probe's ACK CHK_ST (captured during
            //    sendCommand, or wait out the grace for a late-riding frame).
            //    Only PASSED (01) is success; every other state → the original
            //    SR18_ERR_LUT_WRITE (rc unchanged). We ALSO print the device's
            //    real bit[5:4] code so the four states are distinguishable.
            //    Retransmission is left to the caller.
            auto deadline = std::chrono::steady_clock::now()
                          + std::chrono::milliseconds(lut_verify_grace_ms_);
            sr18::LutVerifyResult vr = lut_fail_->waitVerify(deadline);
            // No CHK_ST despite the probe ACK ⇒ still unconfirmed.
            sr18::LutVerifyState st = vr.sampled ? vr.state
                                                 : sr18::LutVerifyState::UNCONFIRMED;
            int rc = (st == sr18::LutVerifyState::PASSED) ? SR18_OK
                                                          : SR18_ERR_LUT_WRITE;
            unsigned code = static_cast<unsigned>(st) & 0x03;   // real bit[5:4] value
            std::fprintf(stderr,
                "LUT verify: device bit[5:4]=%u%u (code=%u) %s%s -> rc=%d\n",
                (code >> 1) & 1, code & 1, code, sr18::lutVerifyStateName(st),
                vr.sampled ? "" : " (no CHK_ST sample after probe ACK)", rc);
            if (rc != SR18_OK) {
                std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                          << " line: " << __LINE__ << '\n';
            }
            return rc;
        }
        return SR18_OK;
    }
};

DCSPProtocol::DCSPProtocol(ICommandExecutor* executor,
                            IRdRegSampler*   sampler,
                            AdcMonitor*      adc_monitor,
                            SlotState        initial_slot,
                            ILutFailWatcher* lut_fail)
    : p_(std::make_unique<Impl>()) {
    p_->executor    = executor;
    p_->sampler     = sampler;
    p_->adc_monitor = adc_monitor;
    p_->slot_.store(initial_slot);
    p_->lut_fail_   = lut_fail;
}

DCSPProtocol::~DCSPProtocol() = default;

SlotState DCSPProtocol::getCurrentSlot() const { return p_->slot_.load(); }

int DCSPProtocol::dcsp_enable(bool flag, int timeout_ms) {
    if (flag) {
        std::vector<uint8_t> empty;
        int rc = p_->sendCommand(TC::LASER_EN, empty, timeout_ms);
        if (rc == SR18_OK) {
            p_->slot_.store(SlotState::SLOT_1);
        }
        return rc;
    }
    return dcsp_reboot(timeout_ms);
}

int DCSPProtocol::dcsp_reboot(int timeout_ms) {
    std::vector<uint8_t> empty;
    int rc = p_->sendCommand(TC::WR_SYS_RST, empty, timeout_ms);
    if (rc == SR18_OK) {
        p_->slot_.store(SlotState::SLOT_9);
    }
    return rc;
}

int DCSPProtocol::dcsp_set_timestamp(const BwTimestamp& ts, int timeout_ms) {
    std::vector<uint8_t> pl;
    uint8_t s[6] = {
        (uint8_t)( ts.time_s        & 0xFF),
        (uint8_t)((ts.time_s >>  8) & 0xFF),
        (uint8_t)((ts.time_s >> 16) & 0xFF),
        (uint8_t)((ts.time_s >> 24) & 0xFF),
        0,
        0,
    };
    sr18::dcsp_encode_timestamp(s, ts.time_ns, pl);
    return p_->sendCommand(TC::WR_TIMESTAMP, pl, timeout_ms);
}

int DCSPProtocol::dcsp_lidar_stop(int)                                { return SR18_ERR_NOT_SUPPORTED; }

/* ── RETIRED 2026-07-28: binary bootimage upload (TC 0x03 / 0x08) ────────────
   Firmware upgrade now goes through the ASCII path exclusively
   (SR18Lidar::downloadFirmware → $LDOTA, real-machine validated 2026-07-16).
   Commented out rather than deleted so the packetization rules stay findable;
   delete outright once definitively dead. If it is ever revived it must carry the
   12-byte [total|no|len] payload header that sendImage() now emits, PLUS the
   0x08-only differences the board reports (an 8-byte version handshake packet
   at no=0, data packets numbered from no=1, total = data packets + 1) — the
   handshake packet's content is not specified anywhere yet.

constexpr uint32_t kPrimarySizeLimit = 0x0C0000;   // 768 KB Primary region

int DCSPProtocol::dcsp_wr_boot_down(const uint8_t* img, size_t n, int timeout_ms) {
    return p_->sendImage(TC::WR_BOOT_DOWN, kPrimarySizeLimit, img, n,
                         p_->boot_chunk_bytes_, timeout_ms);
}
int DCSPProtocol::dcsp_wr_boot_up(const uint8_t* img, size_t n, int timeout_ms) {
    return p_->sendImage(TC::WR_BOOT_UP, kPrimarySizeLimit, img, n,
                         p_->boot_chunk_bytes_, timeout_ms);
}

void DCSPProtocol::setBootChunkBytes(size_t n) {
    if (n < 4)     n = 4;
    if (n > 65535) n = 65535;
    n &= ~size_t(3);            // round down to a multiple of 4
    if (n < 4)     n = 4;
    p_->boot_chunk_bytes_ = n;
}
   ─────────────────────────────────────────────────────────────────────────── */

int DCSPProtocol::dcsp_wr_lut_up(const uint8_t* data, size_t n, int timeout_ms) {
    return p_->sendLut(TC::WR_LUT_UP, data, n, timeout_ms);
}
int DCSPProtocol::dcsp_wr_lut_down(const uint8_t* data, size_t n, int timeout_ms) {
    // Identical to the up-board path except the LUT write command (TC=0x0A).
    return p_->sendLut(TC::WR_LUT_DOWN, data, n, timeout_ms);
}
void DCSPProtocol::setLutChunkBytes(size_t n) {
    // Upper bound is the 16-bit frame LEN minus the 12-byte payload header
    // (65535 - 12 = 65523), rounded down to a multiple of 4 → 65520.
    constexpr size_t kMaxChunk = (65535 - kImgHdrBytes) & ~size_t(3);
    if (n < 4)          n = 4;
    if (n > kMaxChunk)  n = kMaxChunk;
    n &= ~size_t(3);
    if (n < 4)     n = 4;
    p_->lut_chunk_bytes_ = n;
}
void DCSPProtocol::setLutVerifyWindowMs(int ms) {
    if (ms < 0) ms = 0;
    p_->lut_verify_window_ms_ = ms;
}
void DCSPProtocol::setLutVerifyGraceMs(int ms) {
    if (ms < 0) ms = 0;
    p_->lut_verify_grace_ms_ = ms;
}

int DCSPProtocol::dcsp_read_register(uint16_t addr, uint32_t& value_out,
                                      bool down, int timeout_ms) {
    if (!p_->executor || !p_->sampler) return SR18_ERR_NOT_SUPPORTED;
    std::vector<uint8_t> pl;
    sr18::dcsp_encode_rd_reg(addr, pl);
    TC tc = down ? TC::RD_REG_DOWN : TC::RD_REG_UP;

    // ACK and RD_REG are two independent telemetry paths (2026-05-04
    // clarification from protocol team — see spec §3.9.2), but the most
    // common case is that they ride on the same upstream PCD/Status frame.
    // For sampler to capture the ACK frame's RD_REG, arm() must run BEFORE
    // sendCommand returns — otherwise the ACK frame's onChkSt has already
    // fired through RxRouter while the sampler was still un-armed, missing
    // the only RD_REG-bearing frame in single-frame test scenarios.
    //
    // Pre-command streaming frames (in SLOT_1/SLOT_9 production) are
    // harmless: sampler keeps overwriting last_value_ with the latest
    // frame, and by the time sendCommand returns OK the ACK frame (or a
    // post-ACK frame) has the correct RD_REG. collect() blocks for the
    // remainder of the deadline if fewer than target_n samples are seen,
    // returning the latest last_value_ (>=1 sample) or false (0 samples).
    //
    // PREREQUISITE (load-bearing): in lidar_driver.cpp, sampler MUST be
    // registered as a chk_st observer BEFORE monitor — otherwise monitor
    // could fire its cv.notify_all and wake this thread before sampler's
    // onChkSt completes for the ACK frame, causing collect() to read a
    // stale last_value_. See `src/router/sr18_rx_router.h` doc on
    // addChkStObserver for the ordering contract.
    p_->sampler->arm(/*target_n=*/5);
    auto deadline = std::chrono::steady_clock::now()
                  + std::chrono::milliseconds(timeout_ms);

    int rc = p_->sendCommand(tc, pl, timeout_ms, /*rd_reg_out=*/nullptr);
    if (rc != SR18_OK) return rc;

    if (!p_->sampler->collect(value_out, deadline)) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "read_register addr=0x%04x sampler timeout\n",
            static_cast<unsigned>(addr));
        return SR18_TIMEOUT;
    }
    return SR18_OK;
}

int DCSPProtocol::dcsp_write_register(const uint16_t* addrs, const uint32_t* values,
                                       int n, bool save, bool down, int timeout_ms,
                                       int inter_packet_delay_ms) {
    if (n <= 0) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "write_register: n=%d invalid\n", n);
        return SR18_ERR_PARAM;
    }
    auto p0 = sr18::partitionOf(addrs[0]);
    if (p0 == sr18::RegisterPartition::INVALID) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "write_register addr=0x%04x partition=INVALID\n",
            static_cast<unsigned>(addrs[0]));
        return SR18_ERR_PARTITION;
    }
    for (int i = 1; i < n; ++i) {
        if (sr18::partitionOf(addrs[i]) != p0) {
            std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                      << " line: " << __LINE__ << '\n';
            std::fprintf(stderr,
                "write_register addrs cross partition (first=0x%04x, idx=%d at 0x%04x)\n",
                static_cast<unsigned>(addrs[0]),
                i,
                static_cast<unsigned>(addrs[i]));
            return SR18_ERR_PARTITION;
        }
    }
    int limit = sr18::maxRegistersPerPacket(p_->slot_.load());
    TC tc;
    if (down) tc = save ? TC::WR_REG_SAVE_DOWN : TC::WR_REG_TEMP_DOWN;
    else      tc = save ? TC::WR_REG_SAVE_UP   : TC::WR_REG_TEMP_UP;

    // Clamp inter-packet delay to a sane range.
    if (inter_packet_delay_ms < 0)     inter_packet_delay_ms = 0;
    if (inter_packet_delay_ms > 10000) inter_packet_delay_ms = 10000;

    int sent = 0;
    while (sent < n) {
        int chunk = std::min(limit, n - sent);
        std::vector<uint8_t> pl;
        sr18::dcsp_encode_wr_reg(addrs + sent, values + sent, chunk, pl);
        int rc = p_->sendCommand(tc, pl, timeout_ms);
        if (rc != SR18_OK) return rc;
        sent += chunk;
        // After this packet's ACK, wait only if another packet follows.
        // The last packet's ACK is not followed by any delay.
        if (inter_packet_delay_ms > 0 && sent < n) {
            std::this_thread::sleep_for(
                std::chrono::milliseconds(inter_packet_delay_ms));
        }
    }
    return SR18_OK;
}

/* dcsp_download_lut retired 2026-07-07 (see spec 2026-07-07) — superseded by
   the boot-unified dcsp_wr_lut_up.
int DCSPProtocol::dcsp_download_lut(uint8_t id, const uint8_t* data, uint16_t len,
                                     int timeout_ms) {
    if (!data || len == 0) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "download_lut: data null or len=0\n");
        return SR18_ERR_PARAM;
    }
    int budget = sr18::maxPayloadBytes(p_->slot_.load()) - 4;
    if (budget <= 0) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr,
            "download_lut: slot=%d budget=%d (no room)\n",
            static_cast<int>(p_->slot_.load()), budget);
        return SR18_ERR_SLOT;
    }
    uint16_t sent = 0;
    while (sent < len) {
        uint16_t chunk = (uint16_t)std::min((int)(len - sent), budget);
        std::vector<uint8_t> pl;
        sr18::dcsp_encode_wr_lut(id, data + sent, chunk, pl);
        int rc = p_->sendCommand(TC::WR_LUT_UP, pl, timeout_ms);
        if (rc != SR18_OK) return rc;
        sent += chunk;
    }
    return SR18_OK;
}
*/

int DCSPProtocol::dcsp_get_adc_values(uint16_t out[8]) {
    if (!out) {
        std::cerr << "\nError: " << __FILE__ << " : " << __FUNCTION__
                  << " line: " << __LINE__ << '\n';
        std::fprintf(stderr, "get_adc_values: null out\n");
        return SR18_ERR_PARAM;
    }
    if (p_->adc_monitor) p_->adc_monitor->snapshot(out);
    else for (int i = 0; i < 8; ++i) out[i] = 0;
    return SR18_OK;
}

static uint16_t asciiModeData(AsciiMode m) {
    switch (m) {
        case AsciiMode::NORMAL:             return 0x0000;
        case AsciiMode::RECHARGE:           return 0x0002;
        case AsciiMode::RECHARGE_TO_NORMAL: return 0x0003;
        case AsciiMode::DIRTY_REFRESH:      return 0x0007;
        case AsciiMode::ECHO_STRONGEST:     return 0x0008;
        case AsciiMode::ECHO_LAST:          return 0x0009;
    }
    return 0x0000;
}

int DCSPProtocol::dcsp_switch_mode(AsciiMode mode, int timeout_ms) {
    return p_->sendAsciiCmd(/*cmd_id=*/0x03, asciiModeData(mode), timeout_ms);
}

int DCSPProtocol::dcsp_read_angle_file(uint8_t out[72], int timeout_ms) {
    return p_->sendAsciiAngle(out, timeout_ms);
}

int DCSPProtocol::dcsp_enter_upgrade_mode(int timeout_ms) {
    return p_->sendAsciiCmd(/*cmd_id=*/0x03, /*cmd_data=*/0x0004, timeout_ms);
}

int DCSPProtocol::dcsp_request_whole_package(int timeout_ms) {
    return p_->sendAsciiCmd(/*cmd_id=*/0x02, /*cmd_data=*/0x0405, timeout_ms);
}
