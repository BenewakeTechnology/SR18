// src/codec/sr18_fault_codec.h
#pragma once
#include <cstdint>
#include <cstddef>

namespace sr18 {

// Decoded PKT_FAULT (independent EE DD frame, 41 bytes). Field layout per the
// JT16_SR18 integrated manual §4.4:
//   [0..1] EE DD | [2] FS Version | [3..8] Date&Time(6) | [9..12] Timestamp(4us)
//   [13] {LidarState[7:5], Reserved[4:3], RollingCounter[2:0]}
//   [14] {TotalFaultCodes[7:4], FaultCodeId[3:0]} | [15..16] FaultCode(LE)
//   [17..36] Reserved(20) | [37..40] CRC-32/MPEG-2 over [13..36]
// All fields little-endian. time_raw holds the 10 raw header time bytes
// (6 calendar + 4 us) unnormalized.
struct FaultFrame {
    uint8_t  fs_version        = 0;
    uint8_t  time_raw[10]      = {0};
    uint8_t  lidar_state       = 0;   // 0=normal 1=warning 2=shutdown 3=standby
    uint8_t  rolling_counter   = 0;   // 0..7
    uint8_t  total_fault_codes = 0;   // queue size
    uint8_t  fault_code_id     = 0;   // 1-based index in queue
    uint16_t fault_code        = 0;   // raw code (see fault_code_name)
    uint8_t  reserved[20]      = {0};
};

// Total wire length of a PKT_FAULT frame.
constexpr size_t kFaultFrameLen = 41;

// Parse a complete EE DD fault frame. Validates SOP (EE DD), length (41) and
// the CRC-32/MPEG-2 over [13..36] (Lidar State .. Reserved) per manual §4.4.
// Fills out on success. Returns false otherwise.
bool parse_fault_frame(const uint8_t* frame, size_t len, FaultFrame& out);

// Human-readable name for a fault code (manual §7.1). Returns "unknown" for an
// unrecognized code. Names are English to stay MSVC-narrow-literal-safe.
const char* fault_code_name(uint16_t code);

// Human-readable name for the fault-frame Lidar State (manual §7.3):
// 0=normal 1=warning 2=shutdown 3=standby. Returns "unknown" otherwise.
const char* lidar_state_name(uint8_t state);

}  // namespace sr18
