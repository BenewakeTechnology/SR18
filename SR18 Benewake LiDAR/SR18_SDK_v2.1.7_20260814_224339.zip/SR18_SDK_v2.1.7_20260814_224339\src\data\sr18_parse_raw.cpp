// src/data/sr18_parse_raw.cpp
#include "../../include/sr18_parse_raw.h"
#include "../codec/sr18_decoder.h"
#include "../assembler/sr18_frame_assembler.h"
#include "../assembler/sr18_origin_dist_assembler.h"
#include "../data/sr18_timestamp.h"
#include "../../include/sr18_protocol.h"
#include <iostream>

namespace benewake {

namespace {
constexpr size_t kChunk = 64 * 1024;

// 64-bit-safe seek: live recordings exceed 2 GB (268.8 KB/s -> ~15.5 GB/16h),
// past plain fseek(long)'s reach on Windows.
int seek64(std::FILE* f, int64_t offset) {
#ifdef _WIN32
    return _fseeki64(f, (__int64)offset, SEEK_SET);
#else
    return fseeko(f, (off_t)offset, SEEK_SET);
#endif
}

// Device timestamp of a PCD/origin_dist packet (both carry TIME_S calendar
// bytes at offset 6 and TIME_NS microseconds at offset 12).
double packetTimeSeconds(const sr18::DecodedFrame& df) {
    const uint8_t* f = df.full;
    uint32_t ts_us = (uint32_t)f[12] | ((uint32_t)f[13] << 8)
                   | ((uint32_t)f[14] << 16) | ((uint32_t)f[15] << 24);
    const sr18::NormalizedTimestamp ts = sr18::normalizeWireTimestamp(f + 6, ts_us);
    return (double)ts.time_s + (double)ts.time_ns * 1e-9;
}

bool isPointType(uint8_t d_type) {
    return d_type == sr18::DTYPE_PCD || d_type == sr18::DTYPE_ORIGIN_DIST;
}
}  // namespace

ParseRaw::ParseRaw() = default;

ParseRaw::ParseRaw(const char* _file_name)
    : parse_file_(_file_name ? _file_name : "") {}

ParseRaw::~ParseRaw() { closeFile(); }

void ParseRaw::setParseFile(std::string _file_name) {
    closeFile();
    parse_file_ = std::move(_file_name);
}

bool ParseRaw::ensureOpen(const std::string& _file_name) {
    if (!_file_name.empty() && _file_name != parse_file_) setParseFile(_file_name);
    if (in_file_) return true;
    if (parse_file_.empty()) return false;
#ifdef _WIN32
    if (fopen_s(&in_file_, parse_file_.c_str(), "rb") != 0) in_file_ = nullptr;
#else
    in_file_ = std::fopen(parse_file_.c_str(), "rb");
#endif
    if (!in_file_) {
        std::cerr << "[ParseRaw] cannot open file: " << parse_file_ << "\n";
        return false;
    }
    return true;
}

void ParseRaw::closeFile() {
    if (in_file_) {
        std::fclose(in_file_);
        in_file_ = nullptr;
    }
}

void ParseRaw::raw_frame_find(std::string _file_name) {
    frame_offset_list_.clear();
    frame_interval_ = 0.0;
    if (!ensureOpen(_file_name)) return;
    if (seek64(in_file_, 0) != 0) {
        std::cerr << "[ParseRaw] seek failed\n";
        return;
    }

    sr18::FrameAssembler           pcd_asm;
    sr18::OriginDistFrameAssembler od_asm;
    int    curr_type = -1;   // d_type of the current mode; -1 = none seen yet
    double prev_frame_time = 0.0;
    bool   have_prev_time = false;

    auto onFrameStart = [&](const sr18::DecodedFrame& df) {
        frame_offset_list_.push_back((int64_t)df.stream_offset);
        double t = packetTimeSeconds(df);
        if (have_prev_time && t > prev_frame_time)
            frame_interval_ = t - prev_frame_time;
        prev_frame_time = t;
        have_prev_time = true;
    };

    sr18::UpstreamDecoder dec([&](const sr18::DecodedFrame& df) {
        if (!isPointType(df.d_type)) return;
        if (curr_type < 0) {
            curr_type = df.d_type;
            onFrameStart(df);              // first point packet = frame 0 start
        } else if (df.d_type != curr_type) {
            // Mode switch (PCD <-> origin_dist): close the old mode's frame
            // and start a new one at this packet.
            if (curr_type == sr18::DTYPE_PCD) pcd_asm.flush(); else od_asm.flush();
            curr_type = df.d_type;
            onFrameStart(df);
        }
        int fid = 0;
        BwPointCloud::Ptr done =
            (df.d_type == sr18::DTYPE_PCD) ? pcd_asm.feed(df, fid)
                                           : od_asm.feed(df, fid);
        if (done) onFrameStart(df);        // boundary fired: df starts a NEW frame
    });

    std::vector<uint8_t> buf(kChunk);
    size_t n;
    while ((n = std::fread(buf.data(), 1, buf.size(), in_file_)) > 0)
        dec.feed(buf.data(), n);
}

void ParseRaw::parseFrameByOffset(int64_t _offset, BwPointCloud::Ptr& _point_cloud) {
    _point_cloud = nullptr;
    if (_offset < 0 || !ensureOpen(parse_file_)) return;
    if (seek64(in_file_, _offset) != 0) {
        std::cerr << "[ParseRaw] seek failed\n";
        return;
    }

    sr18::FrameAssembler           pcd_asm;
    sr18::OriginDistFrameAssembler od_asm;
    int target_type = -1;   // d_type of the frame at _offset, latched on first point packet

    sr18::UpstreamDecoder dec([&](const sr18::DecodedFrame& df) {
        if (_point_cloud || !isPointType(df.d_type)) return;
        if (target_type < 0) target_type = df.d_type;
        // Known edge: a PCD<->origin_dist mode toggle mid-recording without an
        // azimuth reset makes this frame absorb post-switch-back packets that
        // the scan index attributed to a new frame. Mutually-exclusive modes
        // make this rare; revisit if mixed-mode recordings become a use case.
        else if (df.d_type != target_type) return;   // mode switched mid-file: not this frame
        int fid = 0;
        _point_cloud = (target_type == sr18::DTYPE_PCD)
                           ? pcd_asm.feed(df, fid)
                           : od_asm.feed(df, fid);
    });

    std::vector<uint8_t> buf(kChunk);
    size_t n;
    while (!_point_cloud &&
           (n = std::fread(buf.data(), 1, buf.size(), in_file_)) > 0)
        dec.feed(buf.data(), n);

    if (!_point_cloud && target_type >= 0)   // EOF: last frame, no boundary
        _point_cloud = (target_type == sr18::DTYPE_PCD) ? pcd_asm.flush() : od_asm.flush();
}

double ParseRaw::getIntervalFromRaw() { return frame_interval_; }

}  // namespace benewake
