// src/router/sr18_rx_router.cpp
#include "sr18_rx_router.h"
#include "../data/sr18_adc_monitor.h"
#include "../data/sr18_calibration_collector.h"
#include "../data/sr18_pcd_info_monitor.h"
#include "sr18_ascii_ack_matcher.h"
#include <algorithm>
#include <vector>

namespace sr18 {

RxRouter::RxRouter(ISerial* serial)
    : serial_(serial),
      decoder_([this](const DecodedFrame& df){ onFrame(df); }) {
    decoder_.setAsciiAckCallback([this](const AsciiAck& a){ onAsciiAck(a); });
    decoder_.setAsciiAngleCallback([this](const AsciiAngleFile& a){ onAsciiAngle(a); });
    decoder_.setFaultCallback([this](const FaultFrame& f){ onFault(f); });
}

RxRouter::~RxRouter() { stop(); }

void RxRouter::start() {
    if (running_.exchange(true)) return;
    // Reset the decoder to IDLE before spawning the rx thread so every start()
    // (including the post-OTA restart after a baud switch) begins frame-synced.
    decoder_.reset();
    rx_thread_ = std::thread([this]{ run(); });
}

void RxRouter::stop() {
    if (!running_.exchange(false)) return;
    if (rx_thread_.joinable()) rx_thread_.join();
}

void RxRouter::setMDOPConsumer(FrameConsumer cb) {
    std::lock_guard<std::mutex> lk(consumer_mu_); mdop_ = std::move(cb);
}
void RxRouter::setIDOPConsumer(FrameConsumer cb) {
    std::lock_guard<std::mutex> lk(consumer_mu_); idop_ = std::move(cb);
}
void RxRouter::setDSOPConsumer(FrameConsumer cb) {
    std::lock_guard<std::mutex> lk(consumer_mu_); dsop_ = std::move(cb);
}
void RxRouter::setAdcMonitor(AdcMonitor* m) {
    std::lock_guard<std::mutex> lk(consumer_mu_);
    adc_monitor_ = m;
}
void RxRouter::setPcdInfoMonitor(PcdInfoMonitor* m) {
    std::lock_guard<std::mutex> lk(consumer_mu_);
    pcd_info_monitor_ = m;
}
void RxRouter::setCalibCollector(CalibrationCollector* c) {
    std::lock_guard<std::mutex> lk(consumer_mu_);
    calib_collector_ = c;
}
void RxRouter::setCalibActive(bool active) {
    calib_active_.store(active, std::memory_order_relaxed);
}

void RxRouter::setAsciiAckMatcher(AsciiAckMatcher* m) {
    std::lock_guard<std::mutex> lk(consumer_mu_);
    ascii_matcher_ = m;
}

void RxRouter::onAsciiAck(const AsciiAck& ack) {
    AsciiAckMatcher* m = nullptr;
    {
        std::lock_guard<std::mutex> lk(consumer_mu_);
        m = ascii_matcher_;
    }
    if (m) m->onAsciiAck(ack);
}

void RxRouter::setAsciiAngleMatcher(AsciiAngleMatcher* m) {
    std::lock_guard<std::mutex> lk(consumer_mu_);
    angle_matcher_ = m;
}

void RxRouter::onAsciiAngle(const AsciiAngleFile& file) {
    AsciiAngleMatcher* m = nullptr;
    {
        std::lock_guard<std::mutex> lk(consumer_mu_);
        m = angle_matcher_;
    }
    if (m) m->onAsciiAngle(file);
}

void RxRouter::setFaultConsumer(FaultConsumer cb) {
    std::lock_guard<std::mutex> lk(consumer_mu_); fault_ = std::move(cb);
}

void RxRouter::onFault(const FaultFrame& fault) {
    FaultConsumer cb;
    {
        std::lock_guard<std::mutex> lk(consumer_mu_);
        cb = fault_;
    }
    if (cb) cb(fault);
}

void RxRouter::addChkStObserver(IChkStObserver* obs) {
    std::lock_guard<std::mutex> lk(obs_mu_);
    chkst_observers_.push_back(obs);
}

void RxRouter::removeChkStObserver(IChkStObserver* obs) {
    std::lock_guard<std::mutex> lk(obs_mu_);
    chkst_observers_.erase(
        std::remove(chkst_observers_.begin(), chkst_observers_.end(), obs),
        chkst_observers_.end());
}

void RxRouter::run() {
    // The real device streams ~3200 PCD packets/s x 84 B ≈ 268.8 KB/s
    // (3.125 Mbps link), so 64 KB ≈ 240 ms of stream per read. Steady-state
    // reads return after ~one packet's worth; the large buffer matters when
    // draining the driver/kernel backlog after a host scheduling stall —
    // one syscall instead of sixteen 4 KB reads. Heap-allocated to keep it
    // off the rx-thread stack.
    //
    // 5 ms read timeout only affects stop() latency: the rx thread checks
    // running_ between reads, so stop() takes at most ~5 ms. Steady-state
    // throughput is unchanged because data arrives every ~0.3 ms and the
    // read returns as soon as bytes are buffered.
    std::vector<uint8_t> buf(64 * 1024);
    while (running_.load()) {
        int got = serial_->read(buf.data(), buf.size(), /*timeout_ms=*/5);
        if (got > 0) decoder_.feed(buf.data(), (size_t)got);
        if (got < 0) break;  // serial error; exit
    }
}

void RxRouter::onFrame(const DecodedFrame& df) {
    // b1 new protocol: PCD and origin_dist no longer carry CHK_ST / RD_REG /
    // ADC — byte 4 is Reserved and the frame tail holds contamination/state/
    // TDM/seq. Those roles now live on the Status frame exclusively
    // (2026-07-20 spec items E/F + same-day origin_dist directive), so both
    // telemetry frame types are excluded from the whole chk-st observer chain
    // (ACK edge monitor, RD_REG sampler, LUT bit[5] sampler) — a Reserved-byte
    // residue must not fake a DONE/CRC_ERR edge.
    uint32_t rd_reg = 0;
    if (df.d_type == DTYPE_STATUS && df.full && df.full_len >= 10) {
        rd_reg =   (uint32_t)df.full[6]
                | ((uint32_t)df.full[7] <<  8)
                | ((uint32_t)df.full[8] << 16)
                | ((uint32_t)df.full[9] << 24);
    }

    if (df.d_type != DTYPE_PCD && df.d_type != DTYPE_ORIGIN_DIST) {
        std::lock_guard<std::mutex> lk(obs_mu_);
        for (auto* o : chkst_observers_)  o->onChkSt(df.chk_st, df.d_type, rd_reg);
    }

    FrameConsumer cb;
    {
        std::lock_guard<std::mutex> lk(consumer_mu_);
        switch (df.d_type) {
            case DTYPE_PCD:
            case DTYPE_ORIGIN_DIST: cb = mdop_; break;
            case DTYPE_IMU:         cb = idop_; break;
            // Status frames go to DSOP only. They are NOT forwarded to MDOP:
            // the Status SEQ@14 is an INDEPENDENT counter from the PCD/origin_dist
            // UDP sequence (protocol team, 2026-07-22), so feeding it into the
            // packet-loss gap tracker produced spurious "packet loss" reports on
            // stop and on register read/write (both carried over Status frames).
            // MDOP loss tracking observes point-cloud packets only.
            case DTYPE_STATUS:      cb = dsop_; break;
        }
    }
    if (cb) cb(df);

    // b1 telemetry tail (lidar state / TDM) → PcdInfoMonitor. PCD and
    // origin_dist share the tail layout at different offsets — PCD's sits after
    // its 5-byte contamination region, origin_dist has no such region. (脏污 is
    // not cached here: it rides per-point on BwPoint::contamination, decoded by
    // FrameAssembler from the same frame — PRO-84.)
    if (df.d_type == DTYPE_PCD || df.d_type == DTYPE_ORIGIN_DIST) {
        PcdInfoMonitor* info = nullptr;
        {
            std::lock_guard<std::mutex> lk(consumer_mu_);
            info = pcd_info_monitor_;
        }
        if (info && df.full) {
            if (df.d_type == DTYPE_PCD && df.full_len >= PCD_FRAME_LEN)
                info->pushTail(df.full + PCD_OFF_LIDAR_STATE);
            else if (df.d_type == DTYPE_ORIGIN_DIST &&
                     df.full_len >= ORIGIN_DIST_FRAME_LEN)
                info->pushTail(df.full + OD_OFF_LIDAR_STATE);
        }
    }

    // ADC extraction — the Status frame (offset 10..13) is the only periodic
    // ADC carrier on b1 (PCD and origin_dist no longer have an ADC field).
    // The word encodes one high-channel and one low-channel sample:
    // bit[31:28]=high_ch, bit[27:16]=high_val (12-bit),
    // bit[15:12]=low_ch, bit[11:0]=low_val.
    AdcMonitor* monitor = nullptr;
    {
        std::lock_guard<std::mutex> lk(consumer_mu_);
        monitor = adc_monitor_;
    }
    if (monitor) {
        uint32_t adc_raw = 0;
        bool have_adc = false;
        if (df.d_type == DTYPE_STATUS && df.full && df.full_len >= 14) {
            adc_raw =   (uint32_t)df.full[10]
                    | ((uint32_t)df.full[11] <<  8)
                    | ((uint32_t)df.full[12] << 16)
                    | ((uint32_t)df.full[13] << 24);
            have_adc = true;
        }
        if (have_adc) {
            uint8_t  high_ch  = (uint8_t) ((adc_raw >> 28) & 0x0F);
            uint16_t high_val = (uint16_t)((adc_raw >> 16) & 0x0FFF);
            uint8_t  low_ch   = (uint8_t) ((adc_raw >> 12) & 0x0F);
            uint16_t low_val  = (uint16_t)( adc_raw        & 0x0FFF);
            monitor->pushSample(high_ch, high_val);
            monitor->pushSample(low_ch,  low_val);
        }
    }

    // Calibration mode: reinterpret the RD_REG slot + ADC_VALUE slot as raw
    // 32-bit calibration words. Gated by calib_active_ so normal operation pays
    // only one relaxed atomic load. (Approach A: AdcMonitor/RD_REG sampler above
    // keep running; their output is meaningless during calibration by design.)
    if (calib_active_.load(std::memory_order_relaxed)) {
        CalibrationCollector* coll = nullptr;
        {
            std::lock_guard<std::mutex> lk(consumer_mu_);
            coll = calib_collector_;
        }
        if (coll) {
            // Calibration words ride Status (and origin_dist) frames only —
            // matches the 2026-06-17 bench truth (0x3402=3 makes the device
            // stream Status frames as the calibration carrier); b1 PCD has no
            // RD_REG/ADC slots to reinterpret.
            uint32_t w_adc = 0;
            bool have = false;
            if (df.d_type == DTYPE_STATUS && df.full && df.full_len >= 14) {
                w_adc = (uint32_t)df.full[10] | ((uint32_t)df.full[11] << 8)
                      | ((uint32_t)df.full[12] << 16) | ((uint32_t)df.full[13] << 24);
                have = true;
            }
            if (have) {
                coll->feedWord(rd_reg, CalibrationWordSource::RdReg);
                coll->feedWord(w_adc, CalibrationWordSource::AdcValue);
            }
        }
    }
}

}  // namespace sr18
