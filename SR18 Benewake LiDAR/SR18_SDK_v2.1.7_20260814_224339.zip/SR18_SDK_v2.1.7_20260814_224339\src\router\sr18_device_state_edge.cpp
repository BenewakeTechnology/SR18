// src/router/sr18_device_state_edge.cpp
#include "sr18_device_state_edge.h"
#include "../../include/sr18_protocol.h"

namespace sr18 {

void EdgeDetectingMonitor::armForCompletion() {
    std::lock_guard<std::mutex> lk(mu_);
    armed_         = true;
    done_observed_ = false;
    crc_observed_  = false;
    done_d_type_   = 0;
    done_rd_reg_   = 0;
}

void EdgeDetectingMonitor::onChkSt(uint8_t chk_st, uint8_t d_type, uint32_t rd_reg) {
    // b1 ACKs are carried by Status; IMU traffic must not complete a command.
    if (d_type == DTYPE_IMU) return;
    bool valid = (chk_st & 0x04) != 0;
    if (!valid) return;
    // RD_REG semantics are independent and handled by ChkStRdRegSampler.
    uint8_t status = chk_st & 0x03;

    bool fire = false;
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!armed_) return;

        switch (status) {
            case 0:  // 0x04 DONE
                done_observed_ = true;
                done_d_type_   = d_type;
                done_rd_reg_   = rd_reg;
                fire = true;
                break;
            case 2:  // 0x06 CRC_ERR
                crc_observed_ = true;
                fire = true;
                break;
            default:
                // 0x05 (hold) and 0x07 (reserved) silent
                break;
        }
    }
    if (fire) cv_.notify_all();   // notify outside lock (matches IMUSkipTxGate style)
}

IDeviceStateMonitor::Result EdgeDetectingMonitor::waitForCompletion(
    std::chrono::steady_clock::time_point deadline,
    bool /*need_rd_reg*/)
{
    // ACK completion is carried by a non-IMU CHK_ST DONE. RD_REG availability
    // is orthogonal: sampler handles RD_REG on its own observer chain.
    std::unique_lock<std::mutex> lk(mu_);

    auto pred = [&] { return crc_observed_ || done_observed_; };

    if (!cv_.wait_until(lk, deadline, pred)) {
        armed_ = false;
        return {Status::TIMEOUT, 0};
    }
    armed_ = false;
    if (crc_observed_) return {Status::CRC_ERR, 0};
    return {Status::DONE, done_rd_reg_};
}

}  // namespace sr18
