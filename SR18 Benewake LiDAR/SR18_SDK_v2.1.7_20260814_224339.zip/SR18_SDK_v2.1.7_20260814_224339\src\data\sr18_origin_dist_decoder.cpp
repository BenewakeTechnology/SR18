// src/data/sr18_origin_dist_decoder.cpp
#include "sr18_origin_dist_decoder.h"
#include "sr18_origin_dist_channel_map.h"
#include "sr18_timestamp.h"
#include "../../include/sr18_protocol.h"
#include <cstring>

namespace sr18 {

namespace {

inline uint64_t readU64LE(const uint8_t* p) {
    uint64_t v = 0;
    for (int i = 0; i < 8; ++i) v |= ((uint64_t)p[i]) << (8 * i);
    return v;
}

inline void decodeEcho(const uint8_t* p8, benewake::BwOriginDistEchoInfo& e) {
    uint64_t u = readU64LE(p8);
    e.confidence            = (uint8_t)( u        & 0x0F);
    e.echo_cent             = (uint32_t)((u >> 4)  & 0x3FFFF);
    e.echo_win_sum          = (uint16_t)((u >> 22) & 0x7FF);
    e.echo_win_max          = (uint16_t)((u >> 33) & 0x3FF);
    e.right_large_flag      = (uint8_t)( (u >> 43) & 0x1);
    e.echo_max_add_large    = (uint16_t)((u >> 44) & 0x3FF);
    e.echo_max_add_neighbor = (uint16_t)((u >> 54) & 0x3FF);
}

}  // namespace

void OriginDistDecoder::decode(const DecodedFrame& df, benewake::BwOriginDist& out) {
    const uint8_t* f = df.full;

    // TIME_S = 6 UTC calendar bytes, TIME_NS = microseconds. Normalize to
    // Unix epoch seconds + nanoseconds, same as the PCD / IMU paths.
    // (Benewake's timestamp_s is uint32_t — Unix seconds fit until 2106.)
    const uint32_t raw_us = (uint32_t)f[12] | ((uint32_t)f[13] <<  8)
                          | ((uint32_t)f[14] << 16) | ((uint32_t)f[15] << 24);
    const NormalizedTimestamp ts = normalizeWireTimestamp(f + 6, raw_us);
    out.timestamp_s  = (uint32_t)ts.time_s;
    out.timestamp_ns = ts.time_ns;
    out.time_offset  = 0;
    out.azimuth      = (uint16_t)f[16] | ((uint16_t)f[17] << 8);

    // 18 channels × 28 B starting at offset 18
    for (int i = 0; i < 18; ++i) {
        const uint8_t* p = f + 18 + i * 28;
        out.scan_line[i] = (uint8_t)( p[0]       & 0x03);
        out.spot_loc [i] = (uint8_t)((p[0] >> 2) & 0x0F);
        out.back_mean[i] = p[1];
        out.fram_err [i] = (uint8_t)( p[2]       & 0x01);
        out.err_code [i] = (uint8_t)((p[2] >> 1) & 0x0F);
        // p[3] reserved
        decodeEcho(p +  4, out.echo_0[i]);
        decodeEcho(p + 12, out.echo_1[i]);
        decodeEcho(p + 20, out.echo_2[i]);
        // CHANNEL MAPPING TBD — placeholder: channel[i] = i. Replace once
        // protocol team supplies the 4×16 → 18 channel_map table.
        out.channel[i] = originDistChannelFromScanSpot(out.scan_line[i], out.spot_loc[i]);
    }
}

}  // namespace sr18
