// src/sr18_dsop.cpp
#include "../include/sr18_dsop.h"
#include "router/sr18_rx_router.h"
#include <cstdio>
#include <deque>
#include <mutex>
#include <condition_variable>
#include <atomic>

using namespace sr18;
using namespace benewake;

struct DSOPProtocol::Impl {
    RxRouter* router;
    std::mutex mu_;
    std::condition_variable cv_;
    // Capacity 1000 ≈ 2.5 s of buffer at 400 Hz heartbeat rate (idle SLOT_9).
    // 200 was tight (0.5 s) for slow polling consumers; 1000 gives breathing
    // room while staying under 30 KB of memory (1000 × ~28 B per SYS_INFO).
    std::deque<SYS_INFO> queue_;
    static constexpr size_t kQueueCap = 1000;
    std::atomic<bool> cb_enabled_{false};
    HeartBeatCallbackFunc cb_ = nullptr;
    void* cb_user_ = nullptr;

    void onFrame(const DecodedFrame& df) {
        SYS_INFO info;
        info.up_ver = df.up_ver;
        info.dw_ver = df.dw_ver;
        info.chk_st = df.chk_st;
        info.adc_value = (uint32_t)df.full[10] | ((uint32_t)df.full[11]<<8)
                       | ((uint32_t)df.full[12]<<16) | ((uint32_t)df.full[13]<<24);
        info.last_seq  = (uint16_t)df.full[14] | ((uint16_t)df.full[15]<<8);
        // Format the up/down board versions reported by the device into the
        // human-readable strings that getDeviceInformation() returns. SR18
        // status packets carry only single-byte versions (UP_VER, DW_VER) —
        // these are NOT the firmware version strings Benewake heartbeats
        // would return; richer info needs readRegister with addresses TBD.
        char vbuf[32], fvbuf[32];
        std::snprintf(vbuf,  sizeof(vbuf),  "SR18 UP=v%u",   (unsigned)df.up_ver);
        std::snprintf(fvbuf, sizeof(fvbuf), "SR18 DOWN=v%u", (unsigned)df.dw_ver);
        info.version      = vbuf;
        info.fpga_version = fvbuf;
        HeartBeatCallbackFunc cb_local = nullptr;
        void* user_local = nullptr;
        {
            std::lock_guard<std::mutex> lk(mu_);
            queue_.push_back(info);
            if (queue_.size() > kQueueCap) queue_.pop_front();
            if (cb_enabled_.load()) { cb_local = cb_; user_local = cb_user_; }
        }
        cv_.notify_one();
        if (cb_local) cb_local(info, user_local);
    }
};

DSOPProtocol::DSOPProtocol(RxRouter* router) : p_(std::make_unique<Impl>()) {
    p_->router = router;
    router->setDSOPConsumer([this](const DecodedFrame& df){ p_->onFrame(df); });
}
DSOPProtocol::~DSOPProtocol() {
    if (p_->router) p_->router->setDSOPConsumer(nullptr);
}

SYS_INFO DSOPProtocol::dsop_get_system_information() {
    std::unique_lock<std::mutex> lk(p_->mu_);
    p_->cv_.wait(lk, [&]{ return !p_->queue_.empty(); });
    SYS_INFO out = p_->queue_.back();
    return out;
}
SYS_INFO DSOPProtocol::dsop_get_system_information_no_wait() {
    std::lock_guard<std::mutex> lk(p_->mu_);
    if (p_->queue_.empty()) return SYS_INFO{};
    return p_->queue_.back();
}
void DSOPProtocol::dsop_regist_heart_beat_callback(HeartBeatCallbackFunc cb, void* user) {
    std::lock_guard<std::mutex> lk(p_->mu_);
    p_->cb_      = cb;
    p_->cb_user_ = user;
    p_->cb_enabled_.store(cb != nullptr);
}
void DSOPProtocol::dsop_cancel_heart_beat_callback() {
    std::lock_guard<std::mutex> lk(p_->mu_);
    p_->cb_enabled_.store(false);
    p_->cb_ = nullptr;
}
