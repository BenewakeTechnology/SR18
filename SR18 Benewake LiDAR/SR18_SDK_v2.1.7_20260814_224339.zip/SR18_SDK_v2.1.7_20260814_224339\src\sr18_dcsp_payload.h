// src/sr18_dcsp_payload.h
#pragma once
#include <cstdint>
#include <vector>

namespace sr18 {

// All multi-byte fields are little-endian on wire.

// reg_num(2 LE) + N x [addr(2 LE) + value(4 LE)]
void dcsp_encode_wr_reg(const uint16_t* addrs, const uint32_t* values, int n,
                        std::vector<uint8_t>& out);

// addr(2 LE) + value=0(4 LE) — single-register read per spec.
// NOTE: read register has NO reg_num prefix. Only the write variant carries
// reg_num. (Verified on hardware 2026-05-03 — see dcsp_encode_rd_reg impl.)
void dcsp_encode_rd_reg(uint16_t addr, std::vector<uint8_t>& out);

// dcsp_encode_wr_lut retired 2026-07-07 (see spec 2026-07-07) — superseded by
// the boot-unified LUT download path.
// lut_num=1 + id(1) + len(2 LE) + value(len)
// void dcsp_encode_wr_lut(uint8_t id, const uint8_t* value, uint16_t len,
//                         std::vector<uint8_t>& out);

// s(6 LE) + ns(4 LE)
void dcsp_encode_timestamp(const uint8_t s[6], uint32_t ns,
                           std::vector<uint8_t>& out);

}  // namespace sr18
