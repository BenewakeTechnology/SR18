// src/data/sr18_calibration_collector.cpp
#include "sr18_calibration_collector.h"
#include <algorithm>

namespace sr18 {

void CalibrationCollector::resetSource(SourceState& s) {
    s.rev_count = 0;
    s.started = false;
    s.prev_tooth = -1;
    s.max_tooth = -1;
    s.seen_this_rev.assign(kMaxTeeth, char{0});
    s.samples.assign(kMaxTeeth, {});
}

void CalibrationCollector::arm(int target_revs) {
    std::lock_guard<std::mutex> lk(mu_);
    armed_       = true;
    target_revs_ = target_revs;
    resetSource(rd_reg_);
    resetSource(adc_value_);
}

bool CalibrationCollector::feedSource(SourceState& s, uint32_t word) {
    const bool     valid = (word >> 31) & 0x1u;
    if (!valid) return false;                             // drop at insertion
    const int      tooth = (int)((word >> 24) & 0x7F);
    const uint32_t count = word & 0x00FFFFFFu;
    if (tooth >= kMaxTeeth) return false;                 // range guard

    bool fire = false;

    // Revolution boundary: tooth wrapped to a lower number.
    if (s.prev_tooth >= 0 && tooth < s.prev_tooth) {
        if (!s.started) {
            s.started   = true;     // first clean rev starts; discard partial
            s.rev_count = 0;
        } else {
            ++s.rev_count;          // a clean rev just completed
            if (s.rev_count >= target_revs_) fire = true;
        }
        std::fill(s.seen_this_rev.begin(), s.seen_this_rev.end(), char{0});
    }
    s.prev_tooth = tooth;

    if (s.started && s.rev_count < target_revs_ && !s.seen_this_rev[tooth]) {
        s.seen_this_rev[tooth] = char{1};
        s.samples[tooth].push_back(count);
        if (tooth > s.max_tooth) s.max_tooth = tooth;
    }
    return fire;
}

void CalibrationCollector::feedWord(uint32_t word, CalibrationWordSource source) {
    bool fire = false;
    {
        std::lock_guard<std::mutex> lk(mu_);
        if (!armed_) return;

        SourceState& state =
            (source == CalibrationWordSource::AdcValue) ? adc_value_ : rd_reg_;
        fire = feedSource(state, word);
    }
    if (fire) cv_.notify_all();
}

void CalibrationCollector::fillResult(const SourceState& s,
                                      benewake::CalibrationTableResult& out) {
    out.n_teeth = s.max_tooth + 1;          // 0 if nothing collected
    out.samples.assign(out.n_teeth, {});
    out.mean.assign(out.n_teeth, 0.0);
    for (int t = 0; t < out.n_teeth; ++t) {
        out.samples[t] = s.samples[t];
        if (!s.samples[t].empty()) {
            uint64_t sum = 0;
            for (uint32_t v : s.samples[t]) sum += v;
            out.mean[t] = (double)sum / (double)s.samples[t].size();
        }
    }
}

bool CalibrationCollector::collect(benewake::CalibrationResult& out,
                                   std::chrono::steady_clock::time_point deadline) {
    std::unique_lock<std::mutex> lk(mu_);
    cv_.wait_until(lk, deadline, [&]{ return rd_reg_.rev_count >= target_revs_; });
    // target_revs <= 0 is a caller error (see arm precondition): report
    // not-reached rather than a misleading vacuous success.
    const bool reached = (target_revs_ >= 1) && (rd_reg_.rev_count >= target_revs_);
    armed_ = false;

    out.target_revs = target_revs_;
    fillResult(rd_reg_, out.rd_reg);
    fillResult(adc_value_, out.adc_value);

    // Backward-compatible view follows the RD_REG table.
    out.n_teeth = out.rd_reg.n_teeth;
    out.samples = out.rd_reg.samples;
    out.mean = out.rd_reg.mean;
    return reached;
}

}  // namespace sr18
